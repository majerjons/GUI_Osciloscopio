import tkinter as tk
from tkinter import filedialog, messagebox, ttk, colorchooser
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import re
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.collections import LineCollection


# --- CONSTANTES DE CONFIGURACIÓN ---
# Constantes para los tipos de archivo CSV
CSV_FILE_TYPES_DESCRIPTION = "Archivos CSV"
CSV_FILE_EXTENSION_PATTERN = "*.csv"
DEFAULT_FILE_TYPES = [(CSV_FILE_TYPES_DESCRIPTION, CSV_FILE_EXTENSION_PATTERN)]

# Dimensiones de la pantalla del osciloscopio (en cm)
OSCILLOSCOPE_SCREEN_WIDTH_CM = 32
OSCILLOSCOPE_SCREEN_HEIGHT_CM = 12
SCREEN_DIVISIONS_X = 10
SCREEN_DIVISIONS_Y = 8

# Colores para el modo oscuro/claro
LIGHT_MODE_COLORS = {
    "bg": "lightgray",
    "fg": "black",
    "plot_bg": "#F0F0F0",
    "grid": "gray",
    "line_colors": ['blue', 'orange', 'green', 'red', 'purple', 'brown', 'pink', 'gray'],
    "cursor_x": "darkgreen",
    "cursor_y": "darkmagenta",
    "frame_bg": "lightgray",
    "label_fg": "black",
    "button_bg": "SystemButtonFace",
    "button_fg": "black"
}

DARK_MODE_COLORS = {
    "bg": "#2e2e2e",
    "fg": "white",
    "plot_bg": "#1e1e1e",
    "grid": "#444444",
    "line_colors": ['cyan', 'lime', 'magenta', 'yellow', 'orange', 'white', 'purple', 'lightgray'],
    "cursor_x": "lightblue",
    "cursor_y": "lightcoral",
    "frame_bg": "#3c3c3c",
    "label_fg": "white",
    "button_bg": "#4a4a4a",
    "button_fg": "white"
}


class TC1ScopeApp:
    def __init__(self, root):
        self.is_bode = False     
        self.root = root
        self.df = None
        self.primera_grafica = True
        self.df = None
        self.primera_grafica = True
        self.unidad_tiempo = "s"
        self.unidad_valor = "V"
        self.lineas = []
        self._canal_visible_data = {}
        self.selected_cursor = None
        self._selected_cursor_name = None  # 'cursor_x1' / 'cursor_x2' / 'cursor_y1' / 'cursor_y2'
        self._drag_inicio = None           # posiciones iniciales de los 4 cursores al empezar a arrastrar
        self.cursor_marker1 = None         # marca sobre la curva cuando el tracking está activo
        self.cursor_marker2 = None
        # Mediciones superpuestas en la gráfica V(t): posición (arrastrable) por canal
        self._medicion_pos = {}              # {canal_idx: (x_frac, y_frac)} posiciones elegidas a mano
        self._medicion_text_artists = {}     # {canal_idx: Text} artistas del último redibujado
        self._dragging_medicion_idx = None   # canal cuyo bloque de mediciones se está arrastrando
        self.cursor_x1 = None
        self.cursor_x2 = None
        self.cursor_y1 = None
        self.cursor_y2 = None
        self.ymin_global = None
        self.ymax_global = None
        self._actualizando_slider = False # Flag para evitar recursión en sliders
        self.offset_divisiones = 0.0 # Offset de tiempo en número de divisiones
        self.offset_tension_ch1 = 0.0
        self.offset_tension_ch2 = 0.0
        self.canal_offset = tk.IntVar(value=1) 
        self.canal_cursores = tk.IntVar(value=1)  # (legado, ya no se usa para elegir un único canal de ΔY)
        self.var_cursores = tk.BooleanVar(value=False) 
        # Tracking independiente por par de cursores: Y1 (junto a X1) puede
        # seguir una señal mientras Y2 (junto a X2) queda fijo, o viceversa,
        # para poder usarlo como referencia manual (x0, y0).
        self.var_cursor_track_y1 = tk.BooleanVar(value=False)
        self.var_cursor_track_y2 = tk.BooleanVar(value=False)
        self.canal_track_y1 = tk.IntVar(value=1)  # Canal de referencia (volts/div) para Y1
        self.canal_track_y2 = tk.IntVar(value=1)  # Canal de referencia (volts/div) para Y2
        self.var_cursor_link = tk.BooleanVar(value=False)      # Mover X1+X2 / Y1+Y2 en par
        self.var_offset_tiempo = tk.DoubleVar(value=0.0) 
        self.var_modo_oscuro = tk.BooleanVar(value=False) 
        self.current_colors = LIGHT_MODE_COLORS # Colores actuales
        # Variables de control de visibilidad
        self.mostrar_ch1 = tk.BooleanVar(value=True)
        self.mostrar_ch2 = tk.BooleanVar(value=True)

        # Checkboxes para mostrar/ocultar canales
        self.chk_ch1 = tk.Checkbutton(self.root, text="View Channel 1", variable=self.mostrar_ch1,
                              command=self.actualizar_grafica)
        self.chk_ch2 = tk.Checkbutton(self.root, text="View Channel 2", variable=self.mostrar_ch2,
                                    command=self.actualizar_grafica)
        self.chk_ch1.pack()
        self.chk_ch2.pack()



        self.root.title("LSG GUI")

        # Ajuste de resolución de la ventana
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        width = int(screen_width * 0.9)
        height = int(screen_height * 0.9)
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        self.root.geometry(f"{width}x{height}+{x}+{y}")

        # Configuración de los estilos para ttk (para modo oscuro)
        self.style = ttk.Style()
        self.apply_theme()

        self.create_widgets()
        self.setup_plot()

        # Conectar eventos de Matplotlib para los cursores
        self.canvas.mpl_connect('button_press_event', self.on_press)
        self.canvas.mpl_connect('button_release_event', self.on_release)
        self.canvas.mpl_connect('motion_notify_event', self.on_motion)
        self.canvas.mpl_connect('resize_event', self.on_resize) # Capturar evento de redimensionado de figura

    def apply_theme(self):
        """Aplica el tema (claro/oscuro) a la interfaz y el gráfico."""
        self.current_colors = DARK_MODE_COLORS if self.var_modo_oscuro.get() else LIGHT_MODE_COLORS

        # Configurar estilo de ttk
        self.style.theme_use("clam") # Un tema base que se puede personalizar

        # Configurar colores de fondo de Tkinter y ttk frames/widgets
        self.root.configure(bg=self.current_colors["bg"])
        self.style.configure("TFrame", background=self.current_colors["frame_bg"])
        self.style.configure("TLabelframe", background=self.current_colors["frame_bg"],
                             foreground=self.current_colors["label_fg"])
        self.style.configure("TLabelframe.Label", background=self.current_colors["frame_bg"],
                     foreground=self.current_colors["label_fg"])

        self.style.configure("TLabel", background=self.current_colors["frame_bg"],
                             foreground=self.current_colors["label_fg"])
        self.style.configure("TButton", background=self.current_colors["button_bg"],
                             foreground=self.current_colors["button_fg"])
        self.style.map("TButton",
                       background=[('active', self.current_colors["button_bg"])]
                       )
        self.style.configure("TCheckbutton", background=self.current_colors["frame_bg"],
                             foreground=self.current_colors["label_fg"])
        self.style.configure("TRadiobutton", background=self.current_colors["frame_bg"],
                             foreground=self.current_colors["label_fg"])
        texto_color_combo = "white" if self.var_modo_oscuro.get() else "black"
        fondo_combo = self.current_colors["plot_bg"]

        combo_text_color = "white" if self.var_modo_oscuro.get() else "black"
        combo_bg_color = "#2e2e2e" if self.var_modo_oscuro.get() else "white"
        combo_field_bg = "#3c3c3c" if self.var_modo_oscuro.get() else "white"

        self.style.configure("TCombobox",
            background=combo_bg_color,
            fieldbackground=combo_field_bg,
            foreground=combo_text_color,
            arrowcolor=combo_text_color
        )

        self.style.map("TCombobox",
            fieldbackground=[("readonly", combo_field_bg)],
            foreground=[("readonly", combo_text_color)],
            background=[("readonly", combo_bg_color)],
            arrowcolor=[("readonly", combo_text_color)]
        )

        # Estilo para los Entry de etiquetas de canal (nombre editable)
        self.style.configure("TEntry",
            fieldbackground=combo_field_bg,
            foreground=combo_text_color,
            insertcolor=combo_text_color
        )


        



        # Configurar colores de Matplotlib
        if hasattr(self, 'ax') and hasattr(self, 'fig'):
            self.fig.set_facecolor(self.current_colors["plot_bg"])
            self.ax.set_facecolor(self.current_colors["plot_bg"])
            self.ax.spines['bottom'].set_color(self.current_colors["fg"])
            self.ax.spines['top'].set_color(self.current_colors["fg"])
            self.ax.spines['right'].set_color(self.current_colors["fg"])
            self.ax.spines['left'].set_color(self.current_colors["fg"])
            self.ax.tick_params(axis='x', colors=self.current_colors["fg"])
            self.ax.tick_params(axis='y', colors=self.current_colors["fg"])
            self.ax.xaxis.label.set_color(self.current_colors["fg"])
            self.ax.yaxis.label.set_color(self.current_colors["fg"])
            self.ax.title.set_color(self.current_colors["fg"])

            # Actualiza el grid si ya existe
            for line in self.ax.get_xgridlines() + self.ax.get_ygridlines():
                line.set_color(self.current_colors["grid"])
            
            # Re-dibuja líneas de datos y cursores con los nuevos colores si ya existen
            self.actualizar_grafica() 

        # Actualiza el estilo de los checkboxes personalizados según el modo
        if hasattr(self, 'chk_ch1') and hasattr(self, 'chk_ch2'):
            texto_color = "white" if self.var_modo_oscuro.get() else "black"
            self.chk_ch1.config(
                bg=self.current_colors["bg"],
                fg=texto_color,
                selectcolor=self.current_colors["bg"],
                activebackground=self.current_colors["bg"],
                activeforeground=texto_color
            )
            self.chk_ch2.config(
                bg=self.current_colors["bg"],
                fg=texto_color,
                selectcolor=self.current_colors["bg"],
                activebackground=self.current_colors["bg"],
                activeforeground=texto_color
            )



    def toggle_dark_mode(self):
        """Cambia entre modo claro y oscuro."""
        self.var_modo_oscuro.set(not self.var_modo_oscuro.get())
        self.apply_theme()

    def create_widgets(self):
        """Crea y organiza todos los widgets de la interfaz."""
        # Frame superior para botones principales y cursores
        top_frame = ttk.Frame(self.root)
        top_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=5)

        # Botón Abrir CSV
        self.btn_abrir = ttk.Button(top_frame, text="Open CSV", command=self.abrir_csv)
        self.btn_abrir.pack(side=tk.LEFT, padx=5)

        # Botón Exportar a PDF
        self.btn_exportar_pdf = ttk.Button(top_frame, text="Export to PDF", command=self.exportar_pdf)
        self.btn_exportar_pdf.pack(side=tk.LEFT, padx=5)

        # Botón para resetear la posición de los bloques de mediciones
        # arrastrados sobre la gráfica V(t) (vuelven a las 2 columnas por defecto)
        self.btn_reset_medidas_pos = ttk.Button(
            top_frame, text="Reset Measurement Pos.", command=self.resetear_posicion_mediciones
        )
        self.btn_reset_medidas_pos.pack(side=tk.LEFT, padx=5)

        # Checkbox Usar Cursores
        self.chk_cursores = ttk.Checkbutton(top_frame, text="Use cursors", variable=self.var_cursores, command=self.actualizar_grafica)
        self.chk_cursores.pack(side=tk.LEFT, padx=10)

        # Checkbox Mover cursores en par (X1+X2 juntos, Y1+Y2 juntos)
        self.chk_cursor_link = ttk.Checkbutton(
            top_frame, text="Move cursors together", variable=self.var_cursor_link
        )
        self.chk_cursor_link.pack(side=tk.LEFT, padx=5)

        # Botón Default Setup y Modo Oscuro
        self.btn_default_setup = ttk.Button(top_frame, text="Default Setup", command=self.default_setup)
        self.btn_default_setup.pack(side=tk.RIGHT, padx=5)
        
        self.btn_toggle_mode = ttk.Button(top_frame, text="Dark Mode", command=self.toggle_dark_mode)
        self.btn_toggle_mode.pack(side=tk.RIGHT, padx=5)

        # --- Frame de Tracking independiente por cursor + posiciones/deltas ---
        cursor_frame = ttk.Frame(self.root)
        cursor_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=(0, 5))

        # Tracking de Y1 (sigue a X1) en un canal elegido
        frame_track_y1 = ttk.Frame(cursor_frame)
        frame_track_y1.pack(side=tk.LEFT, padx=(0, 10))
        self.chk_cursor_track_y1 = ttk.Checkbutton(
            frame_track_y1, text="Track Y1 on:", variable=self.var_cursor_track_y1,
            command=self.actualizar_grafica
        )
        self.chk_cursor_track_y1.pack(side="left")
        ttk.Radiobutton(frame_track_y1, text="Ch1", variable=self.canal_track_y1, value=1, command=self.actualizar_grafica).pack(side="left")
        ttk.Radiobutton(frame_track_y1, text="Ch2", variable=self.canal_track_y1, value=2, command=self.actualizar_grafica).pack(side="left")

        # Tracking de Y2 (sigue a X2), totalmente independiente del de Y1:
        # se puede dejar sin marcar para usar Y2 (junto con X2) como una
        # referencia fija (x0, y0) mientras Y1 sigue una señal.
        frame_track_y2 = ttk.Frame(cursor_frame)
        frame_track_y2.pack(side=tk.LEFT, padx=(0, 10))
        self.chk_cursor_track_y2 = ttk.Checkbutton(
            frame_track_y2, text="Track Y2 on:", variable=self.var_cursor_track_y2,
            command=self.actualizar_grafica
        )
        self.chk_cursor_track_y2.pack(side="left")
        ttk.Radiobutton(frame_track_y2, text="Ch1", variable=self.canal_track_y2, value=1, command=self.actualizar_grafica).pack(side="left")
        ttk.Radiobutton(frame_track_y2, text="Ch2", variable=self.canal_track_y2, value=2, command=self.actualizar_grafica).pack(side="left")

        # Etiqueta con la posición absoluta de cada uno de los 4 cursores
        self.label_cursor_pos = ttk.Label(cursor_frame, text="X1 = —   X2 = —   Y1 = —   Y2 = —")
        self.label_cursor_pos.pack(side=tk.LEFT, padx=15)

        # Etiqueta de Deltas
        self.label_deltas = ttk.Label(cursor_frame, text="ΔX = 0, ΔY = 0")
        self.label_deltas.pack(side=tk.RIGHT, padx=5)


        # Frame para controles de tiempo (Time/div y Offset de tiempo)
        time_control_frame = ttk.Frame(self.root)
        time_control_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=5)

        ttk.Label(time_control_frame, text="Time/div:").pack(side=tk.LEFT)
        # --- Escala en progresión 1-2-5 por década (estándar de osciloscopio: 1,2,5,10,20,50...) ---
        # Pasos mucho más finos que una lista fija, de 1 ns/div a 1 s/div.
        self.tiempos_por_div = self._generar_escala_tiempo()
        self.var_tiempo_div = tk.StringVar()
        self.combo_tiempo_div = ttk.Combobox(
            time_control_frame, values=[v[0] for v in self.tiempos_por_div],
            state="normal", width=12, textvariable=self.var_tiempo_div
        )
        # Default a 1 ms/div (busca el índice más cercano, ya que la lista es generada)
        self.combo_tiempo_div.current(self._indice_mas_cercano(self.tiempos_por_div, 1e-3))
        self.combo_tiempo_div.pack(side=tk.LEFT, padx=5)
        self.combo_tiempo_div.bind("<<ComboboxSelected>>", self.actualizar_grafica)
        # --- FIX: además de elegir un preset, el usuario puede escribir su
        # propio valor a mano (ej. "3.3 ms/div") y confirmarlo con Enter ---
        self.combo_tiempo_div.bind("<Return>", self.actualizar_grafica)
        self.combo_tiempo_div.bind("<FocusOut>", self.actualizar_grafica)

        # Slider de Offset de Tiempo
        self.scl_toffset = ttk.Scale(
            master=time_control_frame,
            from_=-SCREEN_DIVISIONS_X, # Rango inicial; se reajusta al cargar un CSV
            to=SCREEN_DIVISIONS_X,
            orient='horizontal',
            command=self.on_slider_offset,
            variable=self.var_offset_tiempo
        )
        self.scl_toffset.set(0)
        self.scl_toffset.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Label(time_control_frame, text="Time Offset").pack(side=tk.LEFT)

        self.btn_reset_toffset = ttk.Button(time_control_frame, text="Reset", command=self.reset_offset)
        self.btn_reset_toffset.pack(side=tk.LEFT, padx=5)


        # Frame para controles de voltaje (Volt/div y Offset de tensión)
        volt_control_frame = ttk.Frame(self.root)
        volt_control_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=5)

        # Selector de canal para offset
        ttk.Label(volt_control_frame, text="Voltage Offset Ch:").pack(side="left")
        ttk.Radiobutton(volt_control_frame, text="Ch1", variable=self.canal_offset, value=1, command=self.actualizar_slider_offset).pack(side="left")
        ttk.Radiobutton(volt_control_frame, text="Ch2", variable=self.canal_offset, value=2, command=self.actualizar_slider_offset).pack(side="left")

        # Slider de Offset de Tensión
        self.scl_tension_offset = ttk.Scale(
            master=volt_control_frame,
            from_=-5 * SCREEN_DIVISIONS_Y, # Offset de 5 divisiones hacia abajo
            to=5 * SCREEN_DIVISIONS_Y,     # Offset de 5 divisiones hacia arriba
            orient='horizontal',
            command=self.on_slider_offset_volt
        )
        self.scl_tension_offset.set(0)
        self.scl_tension_offset.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Label(volt_control_frame, text="Voltage Offset").pack(side=tk.LEFT)

        self.btn_reset_voffset = ttk.Button(volt_control_frame, text="Reset", command=self.reset_offset_volt)
        self.btn_reset_voffset.pack(side=tk.LEFT, padx=5)


        # Frame combinado: personalización de canal (etiqueta/volt-div/color)
        # + mediciones automáticas, lado a lado por canal, para no restarle
        # altura al gráfico V(t) (antes eran dos LabelFrames apilados).
        self.frame_voltdiv = ttk.LabelFrame(self.root, text="Channels & Measurements")
        self.frame_voltdiv.pack(side=tk.TOP, fill=tk.X, padx=10, pady=5)

        self.voltajes_por_div = self._generar_escala_voltaje()

        self.channel_frames = []
        self.channel_label_vars = []
        self.volt_div_vars = []
        self.volt_div_combos = []
        self.channel_color_buttons = []
        self.canal_colores = []  # color hex elegido por el usuario (None = usa color del tema)
        self.measurement_vars = []  # lista de dicts {clave: StringVar} de mediciones, por canal
        self.measurement_show_vars = []  # lista de dicts {clave: BooleanVar}: qué mediciones mostrar como label en la gráfica

        # Inicialmente, crea el bloque para los 2 canales más comunes.
        # Se recrea dinámicamente en inicializar_volt_div si se carga un CSV con más/menos canales.
        for i in range(2):
            self._crear_bloque_canal(i, f"CH{i + 1}")

    def _color_actual_canal(self, index):
        """Devuelve el color hex a usar para el canal 'index': el elegido por el usuario, o si no eligió ninguno, el del tema actual."""
        if index < len(self.canal_colores) and self.canal_colores[index]:
            return self.canal_colores[index]
        colores_tema = self.current_colors["line_colors"]
        return colores_tema[index % len(colores_tema)]

    def _actualizar_swatch_boton(self, index):
        """Pinta el botón de color del canal con el color que está usando actualmente."""
        if index < len(self.channel_color_buttons):
            try:
                self.channel_color_buttons[index].config(bg=self._color_actual_canal(index))
            except Exception:
                pass

    def elegir_color_canal(self, index):
        """Abre el selector de color de Tk y asigna el color elegido a la curva del canal."""
        color_inicial = self._color_actual_canal(index)
        try:
            resultado = colorchooser.askcolor(color=color_inicial, title=f"Color del Canal {index + 1}")
        except Exception:
            resultado = colorchooser.askcolor(title=f"Color del Canal {index + 1}")
        if resultado and resultado[1] and index < len(self.canal_colores):
            self.canal_colores[index] = resultado[1]
            self._actualizar_swatch_boton(index)
            self.actualizar_grafica()

    def _crear_bloque_canal(self, index, nombre_default):
        """
        Crea, para un canal, un único bloque horizontal que combina:
        - a la izquierda: personalización (etiqueta editable, Volt/div, color)
        - a la derecha: mediciones automáticas (Max, Min, Pk-Pk, Mean, RMS, Freq, Period)
        en una grilla compacta de 2 filas, para aprovechar mejor el espacio
        vertical y dejarle más lugar al gráfico V(t).
        """
        bloque = ttk.LabelFrame(self.frame_voltdiv, text=nombre_default)
        bloque.pack(side=tk.LEFT, padx=8, pady=5, fill=tk.Y)

        # --- Izquierda: etiqueta / Volt-div / color ---
        subframe = ttk.Frame(bloque)
        subframe.pack(side=tk.LEFT, padx=(6, 6), pady=4)

        label_var = tk.StringVar(value=nombre_default)
        entry = ttk.Entry(subframe, textvariable=label_var, width=10, justify="center")
        entry.pack(side=tk.TOP)
        entry.bind("<Return>", self.actualizar_grafica)
        entry.bind("<FocusOut>", self.actualizar_grafica)

        volt_var = tk.StringVar(value="1 V/div")
        combo = ttk.Combobox(
            subframe, values=[v[0] for v in self.voltajes_por_div],
            textvariable=volt_var, state="normal", width=10
        )
        combo.pack(side=tk.TOP, pady=2)
        combo.bind("<<ComboboxSelected>>", self.actualizar_grafica)
        # --- FIX: permite escribir un Volt/div a mano (ej. "0.3 V/div") ---
        combo.bind("<Return>", self.actualizar_grafica)
        combo.bind("<FocusOut>", self.actualizar_grafica)

        color_btn = tk.Button(subframe, text="Color", width=9, command=lambda idx=index: self.elegir_color_canal(idx))
        color_btn.pack(side=tk.TOP)

        self.channel_frames.append(bloque)
        self.channel_label_vars.append(label_var)
        self.volt_div_vars.append(volt_var)
        self.volt_div_combos.append(combo)
        self.channel_color_buttons.append(color_btn)
        self.canal_colores.append(None)
        self._actualizar_swatch_boton(index)

        # --- Separador vertical ---
        ttk.Separator(bloque, orient='vertical').pack(side=tk.LEFT, fill='y', padx=4, pady=2)

        # --- Derecha: mediciones automáticas, en grilla compacta 2x4 ---
        stats_frame = ttk.Frame(bloque)
        stats_frame.pack(side=tk.LEFT, padx=(4, 8), pady=4)

        etiquetas_stats = [
            ('max', 'Max'), ('min', 'Min'), ('pkpk', 'Pk-Pk'), ('mean', 'Mean'),
            ('rms', 'RMS'), ('freq', 'Freq'), ('period', 'Period')
        ]
        stats_vars = {}
        show_vars = {}
        columnas = 4  # 4 mediciones por fila (2 filas: 4 + 3)
        for idx_stat, (clave, texto) in enumerate(etiquetas_stats):
            fila = idx_stat // columnas
            col = (idx_stat % columnas) * 3

            # Checkbox para elegir si esta medición se muestra como label en la gráfica V(t)
            show_var = tk.BooleanVar(value=False)
            chk = ttk.Checkbutton(
                stats_frame, variable=show_var, command=self.actualizar_grafica
            )
            chk.grid(row=fila, column=col, sticky='e', padx=(4, 0), pady=1)

            ttk.Label(stats_frame, text=f"{texto}:", font=('TkDefaultFont', 8)).grid(
                row=fila, column=col + 1, sticky='e', padx=(0, 2), pady=1
            )
            var = tk.StringVar(value="—")
            ttk.Label(stats_frame, textvariable=var, font=('TkDefaultFont', 8)).grid(
                row=fila, column=col + 2, sticky='w', padx=(0, 10), pady=1
            )
            stats_vars[clave] = var
            show_vars[clave] = show_var

        self.measurement_vars.append(stats_vars)
        self.measurement_show_vars.append(show_vars)

    def setup_plot(self):
        """Configura el área de trazado de Matplotlib."""
        ancho_in = OSCILLOSCOPE_SCREEN_WIDTH_CM / 2.54
        alto_in = OSCILLOSCOPE_SCREEN_HEIGHT_CM / 2.54
        self.fig, self.ax = plt.subplots(figsize=(ancho_in, alto_in))
        self.fig.subplots_adjust(left=0.05, right=0.95, top=0.9, bottom=0.1) # Ajustar para título y labels
        
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.root)
        canvas_widget = self.canvas.get_tk_widget()
        canvas_widget.pack(fill=tk.BOTH, expand=True)

        # Agrega la barra de herramientas de navegación de Matplotlib (zoom, pan, save)
        self.toolbar = NavigationToolbar2Tk(self.canvas, self.root)
        self.toolbar.update()
        self.canvas._tkcanvas.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        self.ax.set_title("Load a CSV file", color=self.current_colors["fg"])
        self.ax.set_xlabel("Time", color=self.current_colors["fg"])
        self.ax.set_ylabel("Voltage", color=self.current_colors["fg"])
        self.ax.legend()
        self.ax.grid(True)
        self.apply_theme() # Aplicar el tema inicial
        self.canvas.draw()

    def default_setup(self):
        """Restablece la configuración de visualización a valores por defecto."""
        # Restablecer sliders de offset
        self.scl_toffset.set(0.0)
        self.offset_divisiones = 0.0
        self.scl_tension_offset.set(0.0)
        self.offset_tension_ch1 = 0.0
        self.offset_tension_ch2 = 0.0
        self.canal_offset.set(1) # Canal de offset por defecto

        # Restablecer combobox de tiempo/div
        self.combo_tiempo_div.current(self._indice_mas_cercano(self.tiempos_por_div, 1e-3)) # Default a 1ms/div

        # Restablecer comboboxes de volt/div
        for var in self.volt_div_vars:
            var.set("1 V/div") 

        # Desactiva cursores y tracking
        self.var_cursores.set(False)
        self.var_cursor_track_y1.set(False)
        self.var_cursor_track_y2.set(False)

        # Actualiza la gráfica con la nueva configuración
        self.actualizar_grafica()


    def inicializar_volt_div(self):
        """
        Destruye y recrea los bloques por canal (personalización + mediciones,
        combinados en un solo bloque horizontal) según el número de columnas
        de datos del CSV cargado.
        """
        # Elimina los bloques existentes (cada uno agrupa personalización + mediciones)
        for frame in self.channel_frames:
            frame.destroy()
        self.channel_frames = []
        self.channel_label_vars = []
        self.volt_div_vars = []
        self.volt_div_combos = []
        self.channel_color_buttons = []
        self.canal_colores = []
        self.measurement_vars = []
        self.measurement_show_vars = []

        if self.df is None or self.df.shape[1] < 2:
            return # No hay datos o solo columna de tiempo

        # Crea un bloque por cada columna de datos (excluyendo la primera de tiempo)
        for i in range(self.df.shape[1] - 1):
            nombre_col = str(self.df.columns[i + 1])
            self._crear_bloque_canal(i, nombre_col)

        self.apply_theme() # Reaplica el tema a los nuevos controles
        self.actualizar_mediciones()

    # --- Helpers de escala (tiempo/tensión) ---

    def _generar_escala_tiempo(self):
        """
        Genera la lista de Time/div en progresión 1-2-5 por década (1, 2, 5,
        10, 20, 50, 100...), el estándar de los osciloscopios reales. Da pasos
        mucho más finos que una lista fija, de 1 ns/div a 1 s/div.
        """
        valores = set()
        for exp in range(-9, 1):  # 1e-9 s (1 ns) a 1e0 s (1 s)
            for mult in (1, 2, 5):
                v = round(mult * (10 ** exp), 15)
                if v <= 1.0 + 1e-12:
                    valores.add(v)
        return [(self._formatear_escala_tiempo(v), v) for v in sorted(valores)]

    def _generar_escala_voltaje(self):
        """
        Genera la lista de Volt/div en progresión 1-2-5 por década, de
        1 mV/div a 10 V/div (el rango típico de un osciloscopio de banco).
        """
        valores = set()
        for exp in range(-3, 2):  # 1e-3 V (1 mV) a 1e1 V (10 V)
            for mult in (1, 2, 5):
                v = round(mult * (10 ** exp), 12)
                if v <= 10.0 + 1e-9:
                    valores.add(v)
        return [(self._formatear_escala_voltaje(v), v) for v in sorted(valores)]

    @staticmethod
    def _formatear_escala_tiempo(v_segundos):
        if v_segundos < 1e-6 - 1e-18:
            return f"{v_segundos * 1e9:.3g} ns/div"
        elif v_segundos < 1e-3 - 1e-18:
            return f"{v_segundos * 1e6:.3g} μs/div"
        elif v_segundos < 1 - 1e-18:
            return f"{v_segundos * 1e3:.3g} ms/div"
        else:
            return f"{v_segundos:.3g} s/div"

    @staticmethod
    def _formatear_escala_voltaje(v_volts):
        if v_volts < 1 - 1e-9:
            return f"{v_volts * 1e3:.3g} mV/div"
        else:
            return f"{v_volts:.3g} V/div"

    @staticmethod
    def _indice_mas_cercano(lista_pares, valor_objetivo):
        """Devuelve el índice de 'lista_pares' (lista de (texto, valor)) cuyo valor está más cerca de valor_objetivo."""
        mejor_idx, mejor_diff = 0, float('inf')
        for i, (_, v) in enumerate(lista_pares):
            diff = abs(v - valor_objetivo)
            if diff < mejor_diff:
                mejor_diff, mejor_idx = diff, i
        return mejor_idx

    def _parsear_escala_manual(self, texto, tipo):
        """
        Interpreta un valor de escala escrito a mano por el usuario, ej.
        '3.3 ms/div', '3.3ms', '250 mV', '0.5' (usa la unidad por defecto).
        tipo: 'tiempo' -> devuelve segundos; 'voltaje' -> devuelve volts.
        Devuelve (valor_base, unidad_texto) o None si no se pudo interpretar.
        """
        if not texto:
            return None
        texto = texto.strip()
        m = re.match(r'^([0-9]*\.?[0-9]+)\s*([a-zA-Zµμ]*)', texto)
        if not m or not m.group(1):
            return None
        try:
            numero = float(m.group(1))
        except ValueError:
            return None

        unidad = m.group(2).replace("/div", "").replace("/Div", "").strip()

        if tipo == "tiempo":
            factores = {"ns": 1e-9, "μs": 1e-6, "µs": 1e-6, "us": 1e-6, "ms": 1e-3, "s": 1.0}
            if not unidad:
                unidad = "ms"  # unidad por defecto razonable si el usuario solo escribe un número
        else:
            factores = {"mv": 1e-3, "v": 1.0}
            if not unidad:
                unidad = "V"

        factor = factores.get(unidad) if tipo == "tiempo" else factores.get(unidad.lower())
        if factor is None or numero <= 0:
            return None
        if tipo == "voltaje":
            unidad = "mV" if unidad.lower() == "mv" else "V"
        return numero * factor, unidad

    def obtener_factor_tiempo_div(self):
        """Devuelve el valor en segundos correspondiente al Time/div seleccionado (preset o escrito a mano)."""
        tiempo_div_str = self.var_tiempo_div.get()
        preset = dict(self.tiempos_por_div).get(tiempo_div_str)
        if preset is not None:
            return preset
        manual = self._parsear_escala_manual(tiempo_div_str, "tiempo")
        if manual is not None:
            return manual[0]
        return 1e-3

    def obtener_unidad_tiempo_actual(self):
        """Devuelve (unidad, factor_de_escala) según el Time/div seleccionado, ej. ('ms', 1e3)."""
        tiempo_div_str = self.var_tiempo_div.get()
        if dict(self.tiempos_por_div).get(tiempo_div_str) is not None:
            try:
                unidad = tiempo_div_str.split()[1].replace("/div", "")
            except IndexError:
                unidad = "s"
        else:
            manual = self._parsear_escala_manual(tiempo_div_str, "tiempo")
            unidad = manual[1] if manual is not None else "ms"
        factores = {"ns": 1e9, "μs": 1e6, "µs": 1e6, "us": 1e6, "ms": 1e3, "s": 1}
        return unidad, factores.get(unidad, 1)

    def obtener_factor_volt_div(self, canal_idx):
        """Devuelve el valor en volts correspondiente al Volt/div del canal dado (0-based; preset o escrito a mano)."""
        if 0 <= canal_idx < len(self.volt_div_vars):
            volt_div_str = self.volt_div_vars[canal_idx].get()
        else:
            volt_div_str = "1 V/div"
        preset = dict(self.voltajes_por_div).get(volt_div_str)
        if preset is not None:
            return preset
        manual = self._parsear_escala_manual(volt_div_str, "voltaje")
        if manual is not None:
            return manual[0]
        return 1

    def _tiempo_real_desde_div(self, x_div):
        """Convierte una posición X de cursor (divisiones de pantalla) al tiempo real de la señal (segundos)."""
        tiempo_div_segs = self.obtener_factor_tiempo_div()
        return (x_div - self.offset_divisiones) * tiempo_div_segs

    def _valor_real_desde_div(self, y_div, canal_idx):
        """Convierte una posición Y de cursor (divisiones de pantalla del canal dado) al valor real en volts."""
        factor_volt_div = self.obtener_factor_volt_div(canal_idx)
        offset = 0.0
        if canal_idx == 0:
            offset = self.offset_tension_ch1
        elif canal_idx == 1:
            offset = self.offset_tension_ch2
        return y_div * factor_volt_div - offset

    def obtener_unidad_valor(self, canal_idx):
        """Devuelve (unidad, factor_de_escala) según el Volt/div del canal dado (preset o escrito a mano)."""
        if 0 <= canal_idx < len(self.volt_div_vars):
            volt_div_str = self.volt_div_vars[canal_idx].get()
        else:
            volt_div_str = "1 V/div"
        if dict(self.voltajes_por_div).get(volt_div_str) is not None:
            try:
                unidad = volt_div_str.split()[1].replace("/div", "")
            except IndexError:
                unidad = "V"
        else:
            manual = self._parsear_escala_manual(volt_div_str, "voltaje")
            unidad = manual[1] if manual is not None else "V"
        factores = {"mV": 1e3, "V": 1}
        return unidad, factores.get(unidad, 1)

    def obtener_canal_referencia(self):
        """Índice (0-based) del primer canal visible; se usa para calibrar el eje Y en volts."""
        if self.mostrar_ch1.get():
            return 0
        elif self.mostrar_ch2.get():
            return 1
        return 0

    def _segmentos_grilla(self):
        """
        Calcula (una sola vez, y los cachea) los segmentos geométricos de la
        cuadrícula principal y de subdivisión. Como el sistema de coordenadas
        de pantalla es siempre fijo (-N/2 a +N/2 divisiones), esta geometría
        nunca cambia entre redibujados: solo cambian los colores/etiquetas.
        """
        if getattr(self, '_grid_segments_cache', None) is not None:
            return self._grid_segments_cache

        x_half = SCREEN_DIVISIONS_X / 2.0
        y_half = SCREEN_DIVISIONS_Y / 2.0

        x_major = np.arange(-x_half, x_half + 1e-9, 1.0)
        y_major = np.arange(-y_half, y_half + 1e-9, 1.0)
        x_minor = np.arange(-x_half, x_half + 1e-9, 0.2)
        y_minor = np.arange(-y_half, y_half + 1e-9, 0.2)

        seg_major = [[(x, -y_half), (x, y_half)] for x in x_major] + \
                    [[(-x_half, y), (x_half, y)] for y in y_major]
        seg_minor = [[(x, -y_half), (x, y_half)] for x in x_minor] + \
                    [[(-x_half, y), (x_half, y)] for y in y_minor]

        self._grid_segments_cache = (seg_major, seg_minor)
        return self._grid_segments_cache

    def dibujar_divisiones(self):
        """
        Dibuja la cuadrícula del osciloscopio en un sistema de coordenadas FIJO
        (en divisiones de pantalla, -N/2 a +N/2), y agrega las etiquetas de
        escala de tiempo (eje X) y tensión (eje Y).

        La cuadrícula NUNCA se mueve: lo único que cambia con los offsets es
        la posición de las señales dentro de ella (igual que en un osciloscopio real).

        Nota de rendimiento: en vez de dibujar cada línea de la grilla como un
        objeto Line2D individual (~100 objetos por frame), se agrupan en dos
        LineCollection (principal y subdivisión), mucho más livianas de crear
        y redibujar en cada actualización.
        """
        self.ax.grid(False)  # Desactiva la cuadrícula automática de Matplotlib

        x_half = SCREEN_DIVISIONS_X / 2.0
        y_half = SCREEN_DIVISIONS_Y / 2.0

        # La cuadrícula (y los límites del gráfico) son siempre fijos
        self.ax.set_xlim(-x_half, x_half)
        self.ax.set_ylim(-y_half, y_half)

        seg_major, seg_minor = self._segmentos_grilla()
        grid_color = self.current_colors["grid"]

        self.ax.add_collection(LineCollection(seg_minor, colors=grid_color, linestyles=':', linewidths=0.4, zorder=0))
        self.ax.add_collection(LineCollection(seg_major, colors=grid_color, linestyles='-', linewidths=0.8, zorder=0))

        # Ejes centrales (referencia de disparo t=0 y GND)
        self.ax.axvline(x=0, color=self.current_colors["fg"], linewidth=1.2, zorder=1)
        self.ax.axhline(y=0, color=self.current_colors["fg"], linewidth=1.2, zorder=1)

        if self.df is None or self.is_bode:
            self.ax.set_xticks([])
            self.ax.set_yticks([])
            return

        # --- FIX: escala de TIEMPO visible en el eje X ---
        tiempo_div_segs = self.obtener_factor_tiempo_div()
        unidad_t, factor_t = self.obtener_unidad_tiempo_actual()
        self.unidad_tiempo = unidad_t

        xticks = np.arange(-x_half, x_half + 1e-9, 1.0)
        xlabels = []
        for xv in xticks:
            # El valor de tiempo real en cada línea de la cuadrícula depende del offset:
            # la cuadrícula no se mueve, pero el "cero" de tiempo sí, según el offset.
            t_real = (xv - self.offset_divisiones) * tiempo_div_segs
            xlabels.append(f"{t_real * factor_t:.3g}")
        self.ax.set_xticks(xticks)
        self.ax.set_xticklabels(xlabels, color=self.current_colors["fg"], fontsize=8)

        # --- FIX: escala de TENSIÓN visible en el eje Y (según canal de referencia) ---
        canal_ref = self.obtener_canal_referencia()
        unidad_v, factor_v = self.obtener_unidad_valor(canal_ref)
        volt_div_ref = self.obtener_factor_volt_div(canal_ref)
        self.unidad_valor = unidad_v

        yticks = np.arange(-y_half, y_half + 1e-9, 1.0)
        ylabels = [f"{(yv * volt_div_ref) * factor_v:.3g}" for yv in yticks]
        self.ax.set_yticks(yticks)
        self.ax.set_yticklabels(ylabels, color=self.current_colors["fg"], fontsize=8)


    def abrir_csv(self):
        """
        Abre un CSV, limpia nombres de columna de símbolos no ASCII (°, θ, etc.),
        convierte todo a numérico descartando columnas vacías, detecta Bode
        por regex y renombra sus columnas, o inicializa osciloscopio en caso contrario.
        """
        ruta = filedialog.askopenfilename(filetypes=DEFAULT_FILE_TYPES)
        if not ruta:
            return

        try:
            # 1) detecta separador
            with open(ruta, 'r', encoding='latin1', errors='ignore') as f:
                primera = f.readline()
            sep = '\t' if '\t' in primera else ','

            # 2) lee CSV (saltando líneas malformadas)
            df = pd.read_csv(ruta,
                             sep=sep,
                             encoding='latin1',
                             engine='python',
                             on_bad_lines='skip')

            # 3) limpia caracteres: quitar todo lo que no sea ASCII
            df.columns = [
                re.sub(r'[^\x20-\x7E]+', '', col).strip()
                for col in df.columns
            ]

            # 4) convertie todo a numérico (coerce), luego descarta columnas totalmente
            df = df.apply(pd.to_numeric, errors='coerce')
            df = df.loc[:, df.notna().any(axis=0)]
            if df.shape[1] < 2:
                messagebox.showwarning(
                    "Formato Inválido",
                    "No quedan al menos dos columnas numéricas tras la limpieza."
                )
                return

            # 5) elimina filas con cualquier
            df = df.dropna()
            if df.empty:
                messagebox.showwarning(
                    "Archivo Vacío",
                    "No quedan filas con datos completos tras la limpieza."
                )
                return

            
            self.df = df

            # Detectar si es Bode por regex sobre nombres
            freq = next((c for c in df.columns
                         if re.search(r'frequency', c, re.I) and re.search(r'hz', c, re.I)), None)
            gain = next((c for c in df.columns
                         if re.search(r'gain', c, re.I) and re.search(r'db', c, re.I)), None)
            phase = next((c for c in df.columns
                          if re.search(r'phase', c, re.I)), None)

            if freq and gain and phase:
                self.is_bode = True
                # renombra para plot_bode
                self.df = df.rename(columns={
                    freq: 'Frequency (Hz)',
                    gain: 'Gain (dB)',
                    phase: 'Phase ()'
                })
            else:
                self.is_bode = False

                # --- FIX: la señal siempre debe empezar en t=0s ---
                tcol = self.df.columns[0]
                self.df = self.df.sort_values(by=tcol).reset_index(drop=True)
                self.df[tcol] = self.df[tcol] - self.df[tcol].min()

                # Resetea offsets de un archivo previamente cargado
                self.offset_tension_ch1 = 0.0
                self.offset_tension_ch2 = 0.0
                self.scl_tension_offset.set(0)

                # Prepara la vista como un osciloscopio.
                self.inicializar_volt_div()
                self.actualizar_rango_y_global()
                self.update_voltage_offset_range()
                self.t_min = self.df.iloc[:, 0].min()
                self.t_max = self.df.iloc[:, 0].max()
                self.ajustar_escala_tiempo()

            # 7) refresca la gráfica
            self.actualizar_grafica()

        except pd.errors.EmptyDataError:
            messagebox.showwarning("Error de Lectura", "El archivo CSV está vacío.")
        except Exception as e:
            messagebox.showerror(
                "Error Inesperado",
                f"Ocurrió un error al procesar el CSV:\n{e}"
            )

    def exportar_pdf(self):
        """Exporta la gráfica tal como se ve en pantalla (grilla, señales, cursores) a un PDF."""
        if self.df is None:
            messagebox.showwarning(
                "Sin datos",
                "Primero abrí un archivo CSV para poder exportar la gráfica."
            )
            return

        ruta = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("Archivo PDF", "*.pdf")],
            title="Guardar gráfica como PDF"
        )
        if not ruta:
            return

        try:
            self.fig.savefig(
                ruta,
                format="pdf",
                facecolor=self.fig.get_facecolor(),
                edgecolor="none",
                bbox_inches="tight"
            )
            messagebox.showinfo("Exportado", f"Gráfica guardada correctamente en:\n{ruta}")
        except Exception as e:
            messagebox.showerror("Error al exportar", f"No se pudo guardar el PDF:\n{e}")

    def actualizar_rango_y_global(self):
        """
        Calcula el rango global Y (min y max) de todos los datos
        sin considerar offset ni escala por división, para el auto-escalado inicial.
        """
        if self.df is None:
            self.ymin_global = None
            self.ymax_global = None
            return
        
        columnas_datos = self.df.columns[1:] 
        if not columnas_datos.empty:
            self.ymin_global = self.df[columnas_datos].min().min()
            self.ymax_global = self.df[columnas_datos].max().max()
        else:
            self.ymin_global = None
            self.ymax_global = None


    def on_slider_offset(self, valor_offset):
        """Maneja el evento del slider de offset de tiempo."""
        if self.df is None:
            return
        # El valor del slider es el número de divisiones que se quiere mover.
        self.offset_divisiones = float(valor_offset)
        self.actualizar_grafica(preservar_cursores=True)
        

    def reset_offset(self):
        self.var_offset_tiempo.set(0.0)
        self.offset_divisiones = 0.0
        self.actualizar_grafica(preservar_cursores=True)

    def on_slider_offset_volt(self, valor_offset_entero):
        """Maneja el evento del slider de offset de tensión para el canal seleccionado."""
        # No hacemos nada si todavía estamos actualizando o no hay datos
        if self._actualizando_slider or self.df is None:
            return
        # Ignorar el slider si el canal está oculto
        canal = self.canal_offset.get()
        if (canal == 1 and not self.mostrar_ch1.get()) or (canal == 2 and not self.mostrar_ch2.get()):
            return
        self._actualizando_slider = True
        try:
            # Obteniene factor de volt/div del canal
            volt_div_str = self.volt_div_vars[canal-1].get() if canal-1 < len(self.volt_div_vars) else "1 V/div"
            volt_div_value = dict(self.voltajes_por_div).get(volt_div_str, 1)
            # Convertierte divisiones a volts
            offset_real = float(valor_offset_entero) * volt_div_value
            # Asigna al atributo correcto
            if canal == 1:
                self.offset_tension_ch1 = offset_real
            else:
                self.offset_tension_ch2 = offset_real
            self.actualizar_grafica(preservar_cursores=True)
        finally:
            self._actualizando_slider = False
    
    def actualizar_slider_offset(self):
        """
        Sincroniza la posición del slider con el valor real de offset de tensión
        solo si el canal está visible.
        """
        if self._actualizando_slider:  # Evita recursión
            return
        canal = self.canal_offset.get()
        # Si el canal está oculto, ponemos slider en cero y no hacemos nada
        if (canal == 1 and not self.mostrar_ch1.get()) or (canal == 2 and not self.mostrar_ch2.get()):
            self.scl_tension_offset.set(0)
            return
        self._actualizando_slider = True
        try:
            # Convertierte el offset real a divisiones
            if canal == 1:
                volt_div_str = self.volt_div_vars[0].get() if len(self.volt_div_vars) > 0 else "1 V/div"
                factor = dict(self.voltajes_por_div).get(volt_div_str, 1)
                self.scl_tension_offset.set(self.offset_tension_ch1 / factor if factor else 0)
            else:
                volt_div_str = self.volt_div_vars[1].get() if len(self.volt_div_vars) > 1 else "1 V/div"
                factor = dict(self.voltajes_por_div).get(volt_div_str, 1)
                self.scl_tension_offset.set(self.offset_tension_ch2 / factor if factor else 0)
        finally:
            self._actualizando_slider = False
            self.update_voltage_offset_range()

    def reset_offset_volt(self):
        """Restablece los offsets de tensión de ambos canales a cero."""
        self.scl_tension_offset.set(0) # Reinicia el slider visualmente
        self.offset_tension_ch1 = 0.0
        self.offset_tension_ch2 = 0.0
        self.actualizar_grafica(preservar_cursores=True)

    def ajustar_escala_tiempo(self):
        """
        Ajusta el combobox de tiempo/div para que muestre una escala
        apropiada para la duración total de los datos.
        """
        if self.df is None:
            return

        t_min_data = self.df.iloc[:, 0].min()
        t_max_data = self.df.iloc[:, 0].max()
        duracion_total = t_max_data - t_min_data

        # Si el rango de tiempo es 0 (ej. un solo punto o datos inválidos)
        if duracion_total == 0:
            self.var_tiempo_div.set(self.tiempos_por_div[self._indice_mas_cercano(self.tiempos_por_div, 1e-3)][0]) # Default a 1ms/div
            self.var_offset_tiempo.set(0.0)
            self.offset_divisiones = 0.0
            self.scl_toffset.config(from_=-SCREEN_DIVISIONS_X, to=SCREEN_DIVISIONS_X)
            return

        # Calcula el tiempo por división necesario para mostrar toda la duración en 10 divisiones
        # Usamos 8 divisiones para que la señal no ocupe todo el ancho
        tiempo_por_div_necesario = duracion_total / (SCREEN_DIVISIONS_X * 0.8) # Deja un poco de margen

        # Encuentra la mejor escala de tiempo por división
        best_match_idx = 0
        min_diff = float('inf')
        for i, (label, val) in enumerate(self.tiempos_por_div):
            diff = abs(val - tiempo_por_div_necesario)
            if diff < min_diff:
                min_diff = diff
                best_match_idx = i

        self.var_tiempo_div.set(self.tiempos_por_div[best_match_idx][0])
        tiempo_div_segs_elegido = self.tiempos_por_div[best_match_idx][1]

        # --- FIX: rango del slider de offset de tiempo ---
        # Debe permitir recorrer (pan) toda la duración de la señal, además de
        # poder llevarla completamente fuera de pantalla en cualquier dirección.
        duracion_en_divisiones = duracion_total / tiempo_div_segs_elegido if tiempo_div_segs_elegido else 0
        margen = max(duracion_en_divisiones, SCREEN_DIVISIONS_X) + SCREEN_DIVISIONS_X
        self.scl_toffset.config(from_=-margen, to=margen)

        # --- FIX: offset por defecto para centrar toda la señal en pantalla ---
        # (con offset=0 el t=0 de la señal queda en el centro de la pantalla,
        # igual que la referencia de disparo/trigger de un osciloscopio real)
        offset_defecto = -(duracion_en_divisiones / 2.0)
        self.var_offset_tiempo.set(offset_defecto)
        self.offset_divisiones = offset_defecto


    def ajustar_unidades_tiempo(self, tiempo_s):
        """Ajusta la escala y unidad de tiempo para visualización (ns, us, ms, s)."""
        max_abs = np.max(np.abs(tiempo_s))
        if max_abs < 1e-8: # Si los valores son extremadamente pequeños, usar ns
            return tiempo_s * 1e9, "ns"
        elif max_abs < 1e-5: # < 10 us
            return tiempo_s * 1e6, "µs"
        elif max_abs < 1e-2: # < 10 ms
            return tiempo_s * 1e3, "ms"
        else:
            return tiempo_s, "s"

    def ajustar_unidades_valor(self, valores):
        """Ajusta la escala y unidad de valor para visualización (µV, mV, V)."""
        max_abs = np.max(np.abs(valores))
        if max_abs < 1e-4: # < 100 µV
            return valores * 1e6, "µV"
        elif max_abs < 1: # < 1 V
            return valores * 1e3, "mV"
        else:
            return valores, "V"

    def on_resize(self, event):
        """Maneja el evento de redimensionamiento de la figura para actualizar la cuadrícula."""
        self.actualizar_grafica()


    def actualizar_grafica(self, event=None, preservar_cursores=False):
        self.update_voltage_offset_range()
        """
        Limpia y redibuja el gráfico, aplicando offsets, escalas,
        y actualizando cursores y cuadrícula.

        preservar_cursores: cuando es True (usado por los sliders/reset de
        offset de tiempo y de tensión), los cursores -incluyendo el punto
        marcador de un cursor en modo tracking- se dejan EXACTAMENTE donde
        estaban antes de mover el offset, en vez de recalcularse sobre la
        curva ya desplazada. El offset es un ajuste puramente de
        visualización y no debe mover los cursores.
        """
        # Si es CSV de Bode, plot_bode()
        if self.is_bode:
            self.plot_bode()
            return
        # Guardado de las posiciones de los cursores (para no perderlas al redibujar)
        abs_pos = self.obtener_posiciones_absolutas()

        # Si vamos a preservar los cursores tal cual, también recordamos la
        # posición actual de los marcadores de tracking (si los hay), para
        # restaurarlos sin recalcularlos a partir de la curva desplazada.
        marcadores_previos = None
        if preservar_cursores:
            marcadores_previos = {}
            if self.cursor_marker1 is not None:
                try:
                    marcadores_previos[1] = (self.cursor_marker1.get_xdata()[0], self.cursor_marker1.get_ydata()[0])
                except Exception:
                    pass
            if self.cursor_marker2 is not None:
                try:
                    marcadores_previos[2] = (self.cursor_marker2.get_xdata()[0], self.cursor_marker2.get_ydata()[0])
                except Exception:
                    pass

        # --- FIX de rendimiento: antes se hacía fig.clear()+add_subplot DOS veces
        # (y encima un ax.clear() extra) en cada redibujado. Con una sola vez alcanza.
        self.fig.clear()
        self.ax = self.fig.add_subplot(1, 1, 1)
        self.lineas.clear() # Limpia las referencias a las líneas antiguas

        # Establece el color de fondo del eje y la figura
        self.fig.set_facecolor(self.current_colors["plot_bg"])
        self.ax.set_facecolor(self.current_colors["plot_bg"])
        
        # Configura colores de los bordes del grafico y ticks
        for spine in self.ax.spines.values():
            spine.set_edgecolor(self.current_colors["fg"])
        self.ax.tick_params(axis='x', colors=self.current_colors["fg"])
        self.ax.tick_params(axis='y', colors=self.current_colors["fg"])
        self.ax.xaxis.label.set_color(self.current_colors["fg"])
        self.ax.yaxis.label.set_color(self.current_colors["fg"])
        self.ax.title.set_color(self.current_colors["fg"])
        
        if self.df is None:
            self._canal_visible_data = {}
            self.ax.set_title("Load a CSV file", color=self.current_colors["fg"])
            self.ax.set_xlabel("Time", color=self.current_colors["fg"])
            self.ax.set_ylabel("Voltage", color=self.current_colors["fg"])
            self.canvas.draw_idle()
            return

        tiempo_col = self.df.columns[0]
        tiempo_original = self.df[tiempo_col].values

        tiempo_div_segs = self.obtener_factor_tiempo_div()

        # --- FIX: sistema de coordenadas de pantalla FIJO (en divisiones) ---
        # La cuadrícula siempre ocupa de -x_half a +x_half divisiones; lo único
        # que cambia con el offset de tiempo es DÓNDE cae cada muestra dentro
        # de esa cuadrícula fija (igual que en un osciloscopio real).
        x_half = SCREEN_DIVISIONS_X / 2.0
        y_half = SCREEN_DIVISIONS_Y / 2.0

        # Rango de tiempo (en segundos, coordenadas originales del CSV) que
        # cae dentro de la ventana visible, dado el offset actual.
        t_start_visible = (-x_half - self.offset_divisiones) * tiempo_div_segs
        t_end_visible = (x_half - self.offset_divisiones) * tiempo_div_segs

        # Filtra los datos para la ventana de tiempo actual
        idx_visible = np.where((tiempo_original >= t_start_visible) & (tiempo_original <= t_end_visible))[0]

        num_canales = len(self.df.columns) - 1

        # Actualiza el panel de mediciones automáticas (usa toda la señal
        # cargada, no solo la ventana visible en pantalla)
        self.actualizar_mediciones()

        if len(idx_visible) < 2 and num_canales > 0:
            self._canal_visible_data = {}
            self.ax.set_title("No hay suficientes datos en el rango visible.", color=self.current_colors["fg"])
            self.dibujar_divisiones()
            self.ax.set_xlabel(f"Time ({self.unidad_tiempo})", color=self.current_colors["fg"])
            self.ax.set_ylabel(f"Voltage ({self.unidad_valor})", color=self.current_colors["fg"])
            self.canvas.draw_idle()
            return

        # Convierte el tiempo real a coordenadas de pantalla (divisiones),
        # aplicando el offset de tiempo directamente a la señal (no a la cuadrícula)
        tiempo_screen = tiempo_original[idx_visible] / tiempo_div_segs + self.offset_divisiones

        # Límites del gráfico: SIEMPRE fijos (la cuadrícula nunca se mueve)
        self.ax.set_xlim(-x_half, x_half)
        self.ax.set_ylim(-y_half, y_half)

        # Dibujar las líneas de datos (sin duplicación y con visibilidad controlada)
        # Guarda los datos visibles de cada canal para poder usarlos en el
        # tracking de cursores (interpolar el valor de la señal en un x dado).
        self._canal_visible_data = {}

        for i in range(num_canales):
            # Chequea si el canal está habilitado por los checkboxes
            if (i == 0 and not self.mostrar_ch1.get()) or (i == 1 and not self.mostrar_ch2.get()):
                continue  # Salta canal oculto

            datos_originales = self.df[self.df.columns[i + 1]].values[idx_visible]

            volt_div_str = self.volt_div_vars[i].get() if i < len(self.volt_div_vars) else "1 V/div"
            factor_volt_div = self.obtener_factor_volt_div(i)

            # --- FIX: cada canal se expresa en SUS PROPIAS divisiones ---
            # (valor / volts_por_div), y el offset de tensión de ESE canal
            # se le suma en esas mismas divisiones. La cuadrícula (fija) y el
            # otro canal no se ven afectados por este offset.
            datos_div = datos_originales / factor_volt_div
            if i == 0:
                datos_div = datos_div + (self.offset_tension_ch1 / factor_volt_div)
            elif i == 1:
                datos_div = datos_div + (self.offset_tension_ch2 / factor_volt_div)

            etiqueta = self.channel_label_vars[i].get() if i < len(self.channel_label_vars) else self.df.columns[i + 1]
            if not etiqueta.strip():
                etiqueta = str(self.df.columns[i + 1])

            linea, = self.ax.plot(
                tiempo_screen, datos_div,
                color=self._color_actual_canal(i),
                label=f"{etiqueta} ({volt_div_str})"
            )
            self.lineas.append(linea)
            self._canal_visible_data[i] = (tiempo_screen, datos_div, datos_originales)


        # Redibuja las divisiones de la cuadrícula (y actualiza self.unidad_tiempo/self.unidad_valor)
        self.dibujar_divisiones()

        self.ax.set_xlabel(f"Time ({self.unidad_tiempo})", color=self.current_colors["fg"])
        self.ax.set_ylabel(f"Voltage ({self.unidad_valor})", color=self.current_colors["fg"])
        if self.lineas:
            self.ax.legend(loc='upper right', facecolor=self.current_colors["plot_bg"], edgecolor=self.current_colors["fg"], labelcolor=self.current_colors["fg"])

        # Dibuja como texto, sobre la propia gráfica, las mediciones que el
        # usuario haya elegido mostrar (checkboxes junto a cada medición) —
        # así quedan visibles también al exportar a PDF.
        self._dibujar_medidas_en_grafica()

        # Actualiza cursores si están activados
        if self.var_cursores.get() and abs_pos:
            self.crear_cursores_absoluto(
                abs_pos,
                recomputar_tracking=not preservar_cursores,
                marcadores_previos=marcadores_previos
            )
        elif self.var_cursores.get():
            self.crear_cursores()  # posiciones por defecto
        else:
            # remover cursores
            for attr in ['cursor_x1','cursor_x2','cursor_y1','cursor_y2']:
                cur = getattr(self, attr)
                if cur and cur in self.ax.lines:
                    self.ax.lines.remove(cur)
                    setattr(self, attr, None)
        self.canvas.draw_idle()


    def obtener_posiciones_relativas(self):
        """
        Calcula las posiciones relativas (0 a 1) de los cursores
        dentro de los límites actuales del gráfico.
        """
        posiciones = {}
        # Solo si todos los cursores están instanciados
        if not all([self.cursor_x1, self.cursor_x2, self.cursor_y1, self.cursor_y2]):
            return None

        x_min, x_max = self.ax.get_xlim()
        y_min, y_max = self.ax.get_ylim()

        if (x_max - x_min) == 0 or (y_max - y_min) == 0:
            return None

        try:
            posiciones['x1'] = (self.cursor_x1.get_xdata()[0] - x_min) / (x_max - x_min)
            posiciones['x2'] = (self.cursor_x2.get_xdata()[0] - x_min) / (x_max - x_min)
            posiciones['y1'] = (self.cursor_y1.get_ydata()[0] - y_min) / (y_max - y_min)
            posiciones['y2'] = (self.cursor_y2.get_ydata()[0] - y_min) / (y_max - y_min)
            return posiciones
        except Exception:
            return None

    def _valor_interpolado_canal(self, canal_idx, x_screen):
        """
        Interpola el valor (en divisiones de pantalla del canal) de la señal
        graficada en la posición x_screen (coordenadas de pantalla/divisiones).
        Devuelve None si no hay datos visibles de ese canal.
        """
        datos = self._canal_visible_data.get(canal_idx)
        if not datos:
            return None
        tiempo_screen, datos_div, _ = datos
        if len(tiempo_screen) < 2:
            return None
        orden = np.argsort(tiempo_screen)
        return float(np.interp(x_screen, tiempo_screen[orden], datos_div[orden]))

    def _actualizar_tracking_cursores(self):
        """
        Modo 'Track': reubica Y1 y/o Y2 automáticamente sobre la curva del
        canal elegido para CADA cursor, en la posición X actual del cursor
        correspondiente (X1 para Y1, X2 para Y2) — igual que el modo de
        cursores de seguimiento ('tracking cursors') de un osciloscopio real.
        El tracking de Y1 y de Y2 es completamente independiente: se puede
        dejar uno de los dos sin marcar para usarlo como referencia manual
        fija (x0, y0) mientras el otro sigue una señal.
        """
        if not all([self.cursor_x1, self.cursor_x2, self.cursor_y1, self.cursor_y2]):
            return

        x1 = self.cursor_x1.get_xdata()[0]
        x2 = self.cursor_x2.get_xdata()[0]

        # --- Y1 (sigue a X1) ---
        if self.var_cursor_track_y1.get():
            canal_idx1 = self.canal_track_y1.get() - 1
            y1 = self._valor_interpolado_canal(canal_idx1, x1)
            if y1 is not None:
                self.cursor_y1.set_ydata([y1, y1])
                self._dibujar_marcador_cursor(1, x1, y1, canal_idx1)
        else:
            self._quitar_marcador_cursor(1)

        # --- Y2 (sigue a X2), independiente de Y1 ---
        if self.var_cursor_track_y2.get():
            canal_idx2 = self.canal_track_y2.get() - 1
            y2 = self._valor_interpolado_canal(canal_idx2, x2)
            if y2 is not None:
                self.cursor_y2.set_ydata([y2, y2])
                self._dibujar_marcador_cursor(2, x2, y2, canal_idx2)
        else:
            self._quitar_marcador_cursor(2)

    def _dibujar_marcador_cursor(self, indice, x, y, canal_idx):
        """
        Crea o reubica el punto marcador (círculo) del cursor Y1 (indice=1) o
        Y2 (indice=2) exactamente en (x, y), SIN recalcular nada. Se usa tanto
        desde el tracking automático (que sí recalcula y luego llama a esto)
        como para restaurar un marcador tal cual estaba, sin re-trackearlo
        (p. ej. al mover un offset, para que el cursor no "salte").
        """
        color_marca = self._color_actual_canal(canal_idx) if canal_idx is not None and canal_idx >= 0 else self.current_colors["cursor_y"]
        attr = 'cursor_marker1' if indice == 1 else 'cursor_marker2'
        marcador = getattr(self, attr)
        if marcador is not None and marcador in self.ax.lines:
            marcador.set_data([x], [y])
        else:
            marcador, = self.ax.plot(
                [x], [y], marker='o', markersize=6, linestyle='None',
                markerfacecolor=color_marca, markeredgecolor=self.current_colors["fg"], zorder=5
            )
            setattr(self, attr, marcador)

    def _quitar_marcador_cursor(self, indice):
        """Elimina el marcador visual de tracking (círculo) del cursor Y1 (1) o Y2 (2), si existe."""
        attr = 'cursor_marker1' if indice == 1 else 'cursor_marker2'
        marcador = getattr(self, attr)
        if marcador is not None:
            try:
                if marcador in self.ax.lines:
                    self.ax.lines.remove(marcador)
            except Exception:
                pass
            setattr(self, attr, None)

    def crear_cursores(self, posiciones=None):
        """
        Crea o actualiza los cursores X e Y.
        Si 'posiciones' es None, los inicializa en el centro de la vista actual.
        """
        x_min, x_max = self.ax.get_xlim()
        y_min, y_max = self.ax.get_ylim()

        # Eliminar cursores existentes antes de crear nuevos
        for cursor_attr in ['cursor_x1', 'cursor_x2', 'cursor_y1', 'cursor_y2']:
            cursor = getattr(self, cursor_attr)
            if cursor:
                try:
                    if cursor in self.ax.lines:
                        self.ax.lines.remove(cursor)
                except Exception as e:
                    print(f"Error al intentar eliminar cursor {cursor_attr}: {e}")
                setattr(self, cursor_attr, None)


        # Posiciones predeterminadas si no se especifican
        if posiciones is None:
            pos_x1 = x_min + (x_max - x_min) * 0.25
            pos_x2 = x_min + (x_max - x_min) * 0.75
            pos_y1 = y_min + (y_max - y_min) * 0.25
            pos_y2 = y_min + (y_max - y_min) * 0.75
        else:
            # Usa posiciones guardadas, asegurándose de que estén dentro de los límites
            dx_range = (x_max - x_min)
            dy_range = (y_max - y_min)
            
            pos_x1 = x_min + max(0, min(1, posiciones.get('x1', 0.25))) * dx_range
            pos_x2 = x_min + max(0, min(1, posiciones.get('x2', 0.75))) * dx_range
            pos_y1 = y_min + max(0, min(1, posiciones.get('y1', 0.25))) * dy_range
            pos_y2 = y_min + max(0, min(1, posiciones.get('y2', 0.75))) * dy_range

        self.cursor_x1 = self.ax.axvline(pos_x1, color=self.current_colors["cursor_x"], linestyle='--', picker=5)
        self.cursor_x2 = self.ax.axvline(pos_x2, color=self.current_colors["cursor_x"], linestyle='--', picker=5)
        self.cursor_y1 = self.ax.axhline(pos_y1, color=self.current_colors["cursor_y"], linestyle='--', picker=5)
        self.cursor_y2 = self.ax.axhline(pos_y2, color=self.current_colors["cursor_y"], linestyle='--', picker=5)

        self._actualizar_tracking_cursores()
        self.canvas.draw_idle()


    def _medicion_en_posicion(self, event):
        """Devuelve el índice de canal cuyo bloque de mediciones fue clickeado (según bbox), o None."""
        for idx, artista in getattr(self, '_medicion_text_artists', {}).items():
            try:
                contains, _ = artista.contains(event)
            except Exception:
                contains = False
            if contains:
                return idx
        return None

    def on_press(self, event):
        """
        Maneja el evento de presionar el botón del mouse. Primero chequea si
        se clickeó un bloque de mediciones sobre la gráfica (para arrastrarlo
        libremente, funciona siempre, esté o no activo "Use cursors"); si no,
        procede con la selección de cursores (solo si "Use cursors" está
        activo).
        """
        if event.inaxes != self.ax:
            return

        idx_medicion = self._medicion_en_posicion(event)
        if idx_medicion is not None:
            self._dragging_medicion_idx = idx_medicion
            self.canvas.mpl_disconnect('motion_notify_event')
            self.canvas.mpl_connect('motion_notify_event', self.on_motion)
            return

        if not self.var_cursores.get():
            return

        # Iterar sobre los cursores para ver cuál fue seleccionado
        for cursor_name, cursor_obj in [('cursor_x1', self.cursor_x1), ('cursor_x2', self.cursor_x2),
                                         ('cursor_y1', self.cursor_y1), ('cursor_y2', self.cursor_y2)]:
            # Con el tracking activo para ESE cursor puntual, Y1 o Y2 sigue la
            # señal automáticamente y no se puede arrastrar a mano.
            if cursor_name == 'cursor_y1' and self.var_cursor_track_y1.get():
                continue
            if cursor_name == 'cursor_y2' and self.var_cursor_track_y2.get():
                continue
            if cursor_obj is not None:
                contains, _ = cursor_obj.contains(event)
                if contains:
                    self.selected_cursor = cursor_obj
                    self._selected_cursor_name = cursor_name
                    # Guarda la posición inicial de los 4 cursores, para el modo "Move cursors together"
                    self._drag_inicio = {
                        'x1': self.cursor_x1.get_xdata()[0] if self.cursor_x1 is not None else None,
                        'x2': self.cursor_x2.get_xdata()[0] if self.cursor_x2 is not None else None,
                        'y1': self.cursor_y1.get_ydata()[0] if self.cursor_y1 is not None else None,
                        'y2': self.cursor_y2.get_ydata()[0] if self.cursor_y2 is not None else None,
                    }
                    self.canvas.mpl_disconnect('motion_notify_event') # Desconecta temporalmente para evitar que se mueva durante on_press
                    self.canvas.mpl_connect('motion_notify_event', self.on_motion) # Reconecta para mover
                    break

    def on_release(self, event):
        """Maneja el evento de soltar el botón del mouse."""
        if getattr(self, '_dragging_medicion_idx', None) is not None:
            self._dragging_medicion_idx = None
            return

        if not self.var_cursores.get():
            return
        self.selected_cursor = None # Desselecciona el cursor
        self._selected_cursor_name = None
        self._drag_inicio = None
        self.actualizar_deltas_cursores() # Recalcular deltas al soltar el cursor


    def on_motion(self, event):
        """
        Maneja el evento de mover el mouse para arrastrar un cursor o un
        bloque de mediciones. Si "Move cursors together" está activo,
        arrastrar X1 (o Y1) mueve también X2 (o Y2) preservando la distancia
        entre ambos — igual que mover el par de cursores de un osciloscopio
        real.
        """
        if getattr(self, '_dragging_medicion_idx', None) is not None:
            idx = self._dragging_medicion_idx
            artista = self._medicion_text_artists.get(idx)
            if artista is not None and event.x is not None and event.y is not None:
                try:
                    x_frac, y_frac = self.ax.transAxes.inverted().transform((event.x, event.y))
                    x_frac = min(max(x_frac, 0.0), 1.0)
                    y_frac = min(max(y_frac, 0.0), 1.0)
                    artista.set_position((x_frac, y_frac))
                    self._medicion_pos[idx] = (x_frac, y_frac)
                    self.canvas.draw_idle()
                except Exception:
                    pass
            return

        if not self.var_cursores.get() or self.selected_cursor is None or event.inaxes != self.ax:
            return

        clave = (self._selected_cursor_name or '').replace('cursor_', '')  # 'x1' / 'x2' / 'y1' / 'y2'
        link = self.var_cursor_link.get()
        inicio = self._drag_inicio

        if clave in ('x1', 'x2') and event.xdata is not None:
            self.selected_cursor.set_xdata([event.xdata, event.xdata])
            if link and inicio is not None and inicio.get(clave) is not None:
                clave_par = 'x2' if clave == 'x1' else 'x1'
                cursor_par = self.cursor_x2 if clave == 'x1' else self.cursor_x1
                if cursor_par is not None and inicio.get(clave_par) is not None:
                    delta = event.xdata - inicio[clave]
                    nueva_pos = inicio[clave_par] + delta
                    cursor_par.set_xdata([nueva_pos, nueva_pos])
            self._actualizar_tracking_cursores()

        elif clave in ('y1', 'y2') and event.ydata is not None:
            self.selected_cursor.set_ydata([event.ydata, event.ydata])
            if link and inicio is not None and inicio.get(clave) is not None:
                clave_par = 'y2' if clave == 'y1' else 'y1'
                cursor_par = self.cursor_y2 if clave == 'y1' else self.cursor_y1
                if cursor_par is not None and inicio.get(clave_par) is not None:
                    delta = event.ydata - inicio[clave]
                    nueva_pos = inicio[clave_par] + delta
                    cursor_par.set_ydata([nueva_pos, nueva_pos])

        self.canvas.draw_idle() # Actualiza solo el área afectada

    def calcular_deltas(self):
        pass

    def actualizar_deltas_cursores(self):
        """Calcula y muestra las posiciones absolutas (X1,X2,Y1,Y2) y los deltas (ΔX, ΔY) de los cursores."""
        # Si el tracking está activo, recalcula Y1/Y2 antes de medir (por si
        # se cambió el canal de referencia sin mover los cursores X).
        self._actualizar_tracking_cursores()

        if not all([self.cursor_x1, self.cursor_x2, self.cursor_y1, self.cursor_y2]):
            self.actualizar_label_deltas(0, 0, show_channel=False) # No hay cursores, resetear
            if hasattr(self, 'label_cursor_pos'):
                self.label_cursor_pos.config(text="X1 = —   X2 = —   Y1 = —   Y2 = —")
            return

        try:
            # Posiciones de los cursores en coordenadas de PANTALLA (divisiones)
            x1_div = self.cursor_x1.get_xdata()[0]
            x2_div = self.cursor_x2.get_xdata()[0]
            y1_div = self.cursor_y1.get_ydata()[0]
            y2_div = self.cursor_y2.get_ydata()[0]

            unidad_t, _ = self.obtener_unidad_tiempo_actual()
            x1_real = self._tiempo_real_desde_div(x1_div)
            x2_real = self._tiempo_real_desde_div(x2_div)

            # Cada cursor Y se interpreta con SU PROPIO canal de referencia
            # (el elegido en "Track Y1 on:" / "Track Y2 on:"), esté o no el
            # tracking activo para ese cursor — así un cursor fijo también se
            # puede leer en volts reales de un canal (ej. como referencia y0).
            canal_idx1 = self.canal_track_y1.get() - 1
            canal_idx2 = self.canal_track_y2.get() - 1
            y1_real = self._valor_real_desde_div(y1_div, canal_idx1)
            y2_real = self._valor_real_desde_div(y2_div, canal_idx2)

            # --- Posiciones absolutas de cada cursor ---
            texto_x1 = self.formatear_valor(x1_real, unidad_t)
            texto_x2 = self.formatear_valor(x2_real, unidad_t)
            texto_y1 = f"{self.formatear_valor(y1_real, 'V')} (Ch{canal_idx1 + 1})"
            texto_y2 = f"{self.formatear_valor(y2_real, 'V')} (Ch{canal_idx2 + 1})"
            if hasattr(self, 'label_cursor_pos'):
                self.label_cursor_pos.config(
                    text=f"X1 = {texto_x1}   X2 = {texto_x2}   Y1 = {texto_y1}   Y2 = {texto_y2}"
                )

            # --- Deltas ---
            delta_x_mostrado = abs(x2_real - x1_real)
            delta_y_real = abs(y2_real - y1_real)

            if canal_idx1 == canal_idx2:
                self.actualizar_label_deltas(delta_x_mostrado, delta_y_real, channel_num=canal_idx1 + 1)
            else:
                # Y1 e Y2 están referenciados a canales distintos: el delta
                # sigue siendo válido en volts reales, pero no se le asigna
                # un único "canal" ya que mezcla ambas escalas.
                self.actualizar_label_deltas(delta_x_mostrado, delta_y_real, show_channel=False)

        except Exception:
            self.actualizar_label_deltas(0, 0, show_channel=False)
            if hasattr(self, 'label_cursor_pos'):
                self.label_cursor_pos.config(text="X1 = —   X2 = —   Y1 = —   Y2 = —")

        if hasattr(self, 'canvas'):
            self.canvas.draw_idle()


    def formatear_valor(self, valor, unidad_referencia):
        """Formatea un valor numérico a una cadena con la unidad adecuada."""
        if unidad_referencia == "ns":
            return f"{valor:.3g} ns"
        elif unidad_referencia == "µs":
            return f"{valor:.3g} µs"
        elif unidad_referencia == "ms":
            return f"{valor:.3g} ms"
        elif unidad_referencia == "s":
            return f"{valor:.3g} s"
        elif unidad_referencia == "mV":
            return f"{valor:.3g} mV"
        elif unidad_referencia == "µV":
            return f"{valor:.3g} µV"
        elif unidad_referencia == "V":
            return f"{valor:.3g} V"
        else:
            return f"{valor:.3g} {unidad_referencia}"


    def actualizar_label_deltas(self, dx, dy, channel_num=None, show_channel=True):
        """Actualiza la etiqueta que muestra los deltas de los cursores."""
        texto_dx = self.formatear_valor(dx, self.unidad_tiempo)
        texto_dy = self.formatear_valor(dy, "V") # Mostrar siempre en V para los deltas reales

        if show_channel and channel_num is not None:
            self.label_deltas.config(text=f"ΔX = {texto_dx}, ΔY = {texto_dy} (Canal {channel_num})")
        else:
            self.label_deltas.config(text=f"ΔX = {texto_dx}, ΔY = {texto_dy}")
    
    def plot_bode(self):
        """Dibuja el diagrama de Bode (Gain dB y Phase ° vs Frequency) respetando el tema."""
        # Limpio la figura y creo dos ejes apilados
        self.fig.clear()
        ax1 = self.fig.add_subplot(211)
        ax2 = self.fig.add_subplot(212)

        # Columnas esperadas
        f = self.df["Frequency (Hz)"].values
        g = self.df["Gain (dB)"].values
        p = self.df["Phase ()"].values

        # Aplico colores del tema a ambos ejes
        for ax in (ax1, ax2):
            ax.set_facecolor(self.current_colors["plot_bg"])
            for spine in ax.spines.values():
                spine.set_edgecolor(self.current_colors["fg"])
            ax.tick_params(axis='x', colors=self.current_colors["fg"])
            ax.tick_params(axis='y', colors=self.current_colors["fg"])
            ax.xaxis.label.set_color(self.current_colors["fg"])
            ax.yaxis.label.set_color(self.current_colors["fg"])

        # Ganancia (dB)
        ax1.semilogx(f, g, linestyle='-', marker='o', markersize=4,
                     color=self.current_colors["line_colors"][0])
        ax1.set_title("BODE Diagram", color=self.current_colors["fg"])
        ax1.set_ylabel("Gain (dB)", color=self.current_colors["fg"])
        ax1.grid(True, which='both', linestyle='--', linewidth=0.5,
                 color=self.current_colors["grid"])

        # Fase (°)
        ax2.semilogx(f, p, linestyle='-', marker='o', markersize=4,
                     color=self.current_colors["line_colors"][1])
        ax2.set_xlabel("Frequency (Hz)", color=self.current_colors["fg"])
        ax2.set_ylabel("Phase (°)", color=self.current_colors["fg"])
        ax2.grid(True, which='both', linestyle='--', linewidth=0.5,
                 color=self.current_colors["grid"])

        # Fondo de figura
        self.fig.set_facecolor(self.current_colors["plot_bg"])
        self.canvas.draw_idle()
    def obtener_posiciones_absolutas(self):
        """
        Captura las posiciones actuales de los cursores en coordenadas de datos.
        """
        if not all([self.cursor_x1, self.cursor_x2, self.cursor_y1, self.cursor_y2]):
            return None
        try:
            return {
                'x1': self.cursor_x1.get_xdata()[0],
                'x2': self.cursor_x2.get_xdata()[0],
                'y1': self.cursor_y1.get_ydata()[0],
                'y2': self.cursor_y2.get_ydata()[0]
            }
        except Exception:
            return None

    def crear_cursores_absoluto(self, posiciones, recomputar_tracking=True, marcadores_previos=None):
        """
        Vuelve a colocar los cursores en posiciones absolutas de datos, sin cambiar su valor.

        recomputar_tracking:
            - True (comportamiento normal): si el tracking está activo, Y1/Y2
              se recalculan sobre la curva actual en la posición X del cursor
              (p. ej. al arrastrar un cursor, activar/cambiar el tracking, o
              cargar un CSV nuevo).
            - False: NO se recalcula nada; los cursores (incluido el punto
              marcador del tracking) se dejan exactamente donde estaban antes
              del redibujado. Se usa cuando el redibujado es consecuencia de
              mover un offset (de tiempo o de tensión): el offset es solo un
              desplazamiento de visualización y no debe mover los cursores.
        """
        # Eliminar cursores existentes
        for attr in ['cursor_x1','cursor_x2','cursor_y1','cursor_y2']:
            cur = getattr(self, attr)
            if cur and cur in self.ax.lines:
                self.ax.lines.remove(cur)
            setattr(self, attr, None)
        # Dibujar en coordenadas de datos sin escalar
        self.cursor_x1 = self.ax.axvline(posiciones['x1'], color=self.current_colors['cursor_x'], linestyle='--', picker=5)
        self.cursor_x2 = self.ax.axvline(posiciones['x2'], color=self.current_colors['cursor_x'], linestyle='--', picker=5)
        self.cursor_y1 = self.ax.axhline(posiciones['y1'], color=self.current_colors['cursor_y'], linestyle='--', picker=5)
        self.cursor_y2 = self.ax.axhline(posiciones['y2'], color=self.current_colors['cursor_y'], linestyle='--', picker=5)

        if recomputar_tracking:
            self._actualizar_tracking_cursores()
        else:
            # Mantener el/los marcador(es) de tracking exactamente donde
            # estaban, sin re-trackear sobre la curva desplazada.
            if self.var_cursor_track_y1.get() and marcadores_previos and 1 in marcadores_previos:
                xm, ym = marcadores_previos[1]
                self._dibujar_marcador_cursor(1, xm, ym, self.canal_track_y1.get() - 1)
            else:
                self._quitar_marcador_cursor(1)
            if self.var_cursor_track_y2.get() and marcadores_previos and 2 in marcadores_previos:
                xm, ym = marcadores_previos[2]
                self._dibujar_marcador_cursor(2, xm, ym, self.canal_track_y2.get() - 1)
            else:
                self._quitar_marcador_cursor(2)

    def update_voltage_offset_range(self):
        """
        Ajusta el rango del slider de offset de tensión para que la onda completa
        quepa en pantalla (± mitad del rango global de Y / Volt/div).
        """
        # Necesitamos un rango global válido
        if self.df is None or self.ymin_global is None or self.ymax_global is None:
            return

        total_range = self.ymax_global - self.ymin_global
        if total_range <= 0:
            return

        # Canal seleccionado para offset (0-index)
        ch = self.canal_offset.get() - 1
        if 0 <= ch < len(self.volt_div_vars):
            # factor volt/div
            vd_str = self.volt_div_vars[ch].get()
            vd_val = dict(self.voltajes_por_div).get(vd_str, 1)
            if vd_val <= 0:
                return
            # cuántas divisiones necesitamos para cubrir ± half_range
            half_divs = (total_range / vd_val) / 2
            # reconfiguramos el slider
            self.scl_tension_offset.config(from_=-half_divs, to=half_divs)

    # --- Mediciones automáticas ---

    def calcular_mediciones_canal(self, canal_idx):
        """
        Calcula las mediciones automáticas típicas de un osciloscopio (Max, Min,
        Pk-Pk, Mean, RMS, Frequency, Period) para el canal dado (0-based),
        usando TODA la señal cargada (no solo la ventana visible en pantalla).
        Devuelve un dict; los valores que no se puedan calcular (p. ej. la
        frecuencia de una señal no periódica) quedan en None.
        """
        resultado = {'max': None, 'min': None, 'pkpk': None, 'mean': None,
                     'rms': None, 'freq': None, 'period': None}
        if self.df is None or self.is_bode:
            return resultado
        if canal_idx < 0 or canal_idx + 1 >= self.df.shape[1]:
            return resultado

        tiempo = self.df.iloc[:, 0].values.astype(float)
        valores = self.df.iloc[:, canal_idx + 1].values.astype(float)
        if len(valores) == 0:
            return resultado

        v_max = float(np.max(valores))
        v_min = float(np.min(valores))
        resultado['max'] = v_max
        resultado['min'] = v_min
        resultado['pkpk'] = v_max - v_min
        resultado['mean'] = float(np.mean(valores))
        resultado['rms'] = float(np.sqrt(np.mean(np.square(valores))))

        # --- Estimación de Frecuencia / Período por cruces ascendentes por cero ---
        try:
            señal_centrada = valores - resultado['mean']
            cruces = np.where((señal_centrada[:-1] <= 0) & (señal_centrada[1:] > 0))[0]
            if len(cruces) >= 2:
                t_cruces = []
                for i in cruces:
                    y0, y1 = señal_centrada[i], señal_centrada[i + 1]
                    t0, t1 = tiempo[i], tiempo[i + 1]
                    if y1 != y0:
                        frac = -y0 / (y1 - y0)
                        t_cruces.append(t0 + frac * (t1 - t0))
                if len(t_cruces) >= 2:
                    periodo_medio = float(np.mean(np.diff(t_cruces)))
                    if periodo_medio > 0:
                        resultado['period'] = periodo_medio
                        resultado['freq'] = 1.0 / periodo_medio
        except Exception:
            pass

        return resultado

    def _fmt_medida_v(self, valor):
        """Formatea un valor en volts con la unidad más adecuada (µV/mV/V)."""
        if valor is None:
            return "—"
        escalado, unidad = self.ajustar_unidades_valor(np.array([valor], dtype=float))
        return f"{escalado[0]:.4g} {unidad}"

    def _fmt_medida_t(self, valor):
        """Formatea un valor de tiempo con la unidad más adecuada (ns/µs/ms/s)."""
        if valor is None:
            return "—"
        escalado, unidad = self.ajustar_unidades_tiempo(np.array([valor], dtype=float))
        return f"{escalado[0]:.4g} {unidad}"

    def _fmt_medida_freq(self, valor):
        """Formatea una frecuencia con la unidad más adecuada (Hz/kHz/MHz)."""
        if valor is None:
            return "—"
        abs_v = abs(valor)
        if abs_v >= 1e6:
            return f"{valor / 1e6:.4g} MHz"
        elif abs_v >= 1e3:
            return f"{valor / 1e3:.4g} kHz"
        else:
            return f"{valor:.4g} Hz"

    def actualizar_mediciones(self):
        """Recalcula y muestra en cada bloque de canal sus mediciones automáticas."""
        if not hasattr(self, 'measurement_vars'):
            return
        for i, stats_vars in enumerate(self.measurement_vars):
            medidas = self.calcular_mediciones_canal(i)
            stats_vars['max'].set(self._fmt_medida_v(medidas['max']))
            stats_vars['min'].set(self._fmt_medida_v(medidas['min']))
            stats_vars['pkpk'].set(self._fmt_medida_v(medidas['pkpk']))
            stats_vars['mean'].set(self._fmt_medida_v(medidas['mean']))
            stats_vars['rms'].set(self._fmt_medida_v(medidas['rms']))
            stats_vars['freq'].set(self._fmt_medida_freq(medidas['freq']))
            stats_vars['period'].set(self._fmt_medida_t(medidas['period']))

    def resetear_posicion_mediciones(self):
        """Vuelve los bloques de mediciones superpuestos en la gráfica V(t) a su posición por defecto (2 columnas: Ch1 izquierda, Ch2 derecha)."""
        self._medicion_pos = {}
        self.actualizar_grafica()

    def _dibujar_medidas_en_grafica(self):
        """
        Dibuja, como texto sobre la propia gráfica V(t), las mediciones
        automáticas que el usuario haya marcado con el checkbox correspondiente
        en el panel "Channels & Measurements". Las mediciones de cada canal se
        agrupan en UN solo bloque (una columna por canal: Ch1 a la izquierda,
        Ch2 a la derecha, y así sucesivamente si hay más canales), en vez de
        una lista mezclada — así queda prolijo también al exportar a PDF.

        Cada bloque se puede arrastrar con el mouse (ver on_press/on_motion/
        on_release) a cualquier posición dentro de la gráfica; la posición
        elegida se recuerda entre redibujados hasta que se resetea con el
        botón "Reset Measurement Pos.".
        """
        self._medicion_text_artists = {}

        if not getattr(self, 'measurement_show_vars', None):
            return

        etiquetas_stats = [
            ('max', 'Max'), ('min', 'Min'), ('pkpk', 'Pk-Pk'), ('mean', 'Mean'),
            ('rms', 'RMS'), ('freq', 'Freq'), ('period', 'Period')
        ]

        for i, show_vars in enumerate(self.measurement_show_vars):
            # Solo canales visibles (mismo criterio que al graficar la curva)
            if i == 0 and not self.mostrar_ch1.get():
                continue
            if i == 1 and not self.mostrar_ch2.get():
                continue
            if not any(var.get() for var in show_vars.values()):
                continue

            medidas = self.calcular_mediciones_canal(i)
            etiqueta = self.channel_label_vars[i].get().strip() if i < len(self.channel_label_vars) else ""
            if not etiqueta:
                etiqueta = f"CH{i + 1}"
            color = self._color_actual_canal(i)

            lineas_canal = [etiqueta]
            for clave, texto_stat in etiquetas_stats:
                if not show_vars.get(clave) or not show_vars[clave].get():
                    continue
                valor = medidas.get(clave)
                if clave == 'freq':
                    texto_val = self._fmt_medida_freq(valor)
                elif clave == 'period':
                    texto_val = self._fmt_medida_t(valor)
                else:
                    texto_val = self._fmt_medida_v(valor)
                lineas_canal.append(f"{texto_stat}: {texto_val}")

            if len(lineas_canal) <= 1:
                continue  # este canal no tiene ninguna medición tildada

            texto_bloque = "\n".join(lineas_canal)

            # Posición: la que el usuario haya arrastrado a mano, o la
            # posición por defecto en 2 columnas (canales pares a la
            # izquierda, impares a la derecha; baja de fila cada 2 canales).
            if i in self._medicion_pos:
                x_pos, y_pos = self._medicion_pos[i]
            else:
                col = i % 2
                fila = i // 2
                x_pos = 0.015 + col * 0.35
                y_pos = 0.985 - fila * 0.34

            artista = self.ax.text(
                x_pos, y_pos, texto_bloque,
                transform=self.ax.transAxes,
                fontsize=7.5, color=color, va='top', ha='left',
                family='monospace', zorder=6, picker=True,
                bbox=dict(boxstyle='round,pad=0.3', facecolor=self.current_colors["plot_bg"],
                          edgecolor=color, linewidth=0.8, alpha=0.85)
            )
            self._medicion_text_artists[i] = artista


if __name__ == "__main__":
    root = tk.Tk()
    app = TC1ScopeApp(root)
    root.mainloop()
"""
Punto de entrada de LSG GUI (osciloscopio virtual).

Se ejecuta igual que antes:

    py -3.13 GUI.py

Todo el código de la aplicación vive ahora organizado por tema dentro de la
carpeta `lsg_gui/` (ver ese paquete para el detalle de cada módulo). Este
archivo se mantiene chico a propósito: solo crea la ventana principal y
arranca el loop de eventos de Tkinter.
"""
import tkinter as tk

from lsg_gui.gui_app import TC1ScopeApp


def main():
    root = tk.Tk()
    app = TC1ScopeApp(root)  # noqa: F841 (referencia viva mientras corre la app)
    root.mainloop()


if __name__ == "__main__":
    main()

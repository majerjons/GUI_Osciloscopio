# LSG GUI — estructura del proyecto

## Qué cambió

El código funcional es **exactamente el mismo** (se verificó automáticamente
que los 63 métodos son texto idéntico al original, y que la app carga CSV,
grafica, calcula mediciones, cursores y modo oscuro sin diferencias). Lo
único que se reorganizó fue el "dónde vive cada cosa":

- Antes: un solo archivo `GUI.py` de ~2000 líneas con una única clase gigante.
- Ahora: `GUI.py` es solo el punto de entrada (20 líneas) y la lógica está
  repartida por tema dentro de la carpeta `lsg_gui/`:

```
GUI.py                          <- punto de entrada, ejecutar este archivo
lsg_gui/
  constants.py                  <- colores y dimensiones de pantalla
  gui_app.py                    <- clase TC1ScopeApp (el __init__) que junta todos los mixins
  theme_mixin.py                <- modo claro/oscuro
  widgets_mixin.py              <- construcción de botones, sliders, bloques por canal
  scale_mixin.py                <- listas de Time/div y Volt/div, parseo de valores a mano
  data_mixin.py                 <- abrir CSV, exportar a PDF
  offsets_mixin.py              <- sliders de offset de tiempo/tensión
  plot_mixin.py                 <- grilla, redibujado de la gráfica V(t), modo Bode
  cursors_mixin.py              <- los 4 cursores, tracking, arrastre con mouse, deltas
  measurements_mixin.py         <- mediciones automáticas (Max, Min, RMS, Freq, etc.)
```

Cada archivo tiene una clase `...Mixin` chica, y `gui_app.py` las combina
todas en `TC1ScopeApp`. Python permite que todos estos mixins compartan el
mismo `self` (el mismo estado de la app), así que **no cambia nada en tiempo
de ejecución** — es puramente organización del código fuente.

### Por qué así (y no "de una")
Elegí no tocar ninguna línea de lógica adentro de los métodos: solo se
movieron de lugar. Eso hace que el riesgo de introducir un bug sea
prácticamente cero (lo verifiqué comparando el texto de cada método contra
el original). Las únicas dos líneas eliminadas fueron una asignación
duplicada e inofensiva en `__init__` (`self.df = None` y
`self.primera_grafica = True` estaban repetidas dos veces seguidas).

### Ventaja para vos como docente / para escalar
- Si a futuro querés agregar, por ejemplo, un modo FFT, creás
  `fft_mixin.py` y lo sumás a la lista de herencia en `gui_app.py`, sin
  tocar el resto.
- Si un alumno pregunta "¿dónde está la lógica de los cursores?", la
  respuesta es directamente `cursors_mixin.py`, en vez de buscar en 2000
  líneas.
- El archivo original completo (por si algo no convence y querés volver
  atrás) queda guardado como `GUI_original_backup.py`.

## Cómo correrlo (igual que antes)

```
py -3.13 GUI.py
```

## Cómo generar el ejecutable (.exe)

Esto **tenés que correrlo vos en tu Windows**, porque PyInstaller genera el
ejecutable para el sistema operativo en el que se ejecuta (no se puede
generar un .exe de Windows desde este entorno, que es Linux).

Pasos:

1. Asegurate de tener toda la carpeta (`GUI.py`, `lsg_gui/`,
   `requirements.txt`, `build_exe.bat`) junta en tu PC.
2. Doble clic en `build_exe.bat` (o corré esas mismas líneas a mano desde
   una consola).
3. El ejecutable queda en `dist\LSG_GUI.exe`. Es standalone: se lo podés
   pasar a tus alumnos sin que necesiten instalar Python.

Si preferís no usar el .bat, los comandos son:

```
py -3.13 -m pip install -r requirements.txt pyinstaller
py -3.13 -m PyInstaller --noconfirm --onefile --windowed --name "LSG_GUI" GUI.py
```

Notas:
- `--windowed` evita que se abra una consola negra atrás de la GUI.
- `--onefile` empaqueta todo en un solo .exe (tarda un poco más en abrir la
  primera vez, pero es más cómodo para repartir).
- La primera compilación puede tardar unos minutos.

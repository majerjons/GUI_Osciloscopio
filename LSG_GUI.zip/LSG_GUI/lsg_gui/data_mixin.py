"""
Carga de archivos CSV y exportacion de la grafica actual a PDF.

Estos metodos se mezclan (mixin) dentro de TC1ScopeApp en gui_app.py.
"""
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, colorchooser
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import re
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.collections import LineCollection
import matplotlib.backends.backend_pdf  # noqa: F401 (fig.savefig(format="pdf") lo necesita en tiempo de ejecución;
# se importa acá explícitamente porque PyInstaller no lo detecta solo, ya que
# matplotlib lo carga de forma dinámica según el "format" pedido)
from .constants import *  # noqa: F401,F403 (colores y dimensiones de pantalla)


class DataMixin:
    # --- Formato 2: CSV de osciloscopio con bloque de metadatos ---
    # (Channel, Frequency, Period, PK-PK, Probe attenuation, Voltage per ADC
    # value, Time interval) seguido de una tabla "index,CH1_Voltage(mV),...".
    # A diferencia del formato "genérico" (una columna de tiempo + columnas
    # de canal), acá el tiempo no viene en el archivo: hay que reconstruirlo
    # a partir de "Time interval" (tiempo entre muestras) y el voltaje viene
    # en milivolts, hay que pasarlo a Volts.
    _PREFIJOS_UNIDAD = {'p': 1e-12, 'n': 1e-9, 'u': 1e-6, 'µ': 1e-6, 'm': 1e-3, '': 1.0, 'k': 1e3}

    @classmethod
    def _parsear_tiempo_con_unidad(cls, cadena):
        """Convierte p.ej. '40.00000uS' -> 4e-05 (segundos). None si no matchea."""
        m = re.match(r'^\s*([-+0-9.eE]+)\s*([a-zA-Zµ]*)\s*$', str(cadena).strip())
        if not m:
            return None
        valor = float(m.group(1))
        unidad = m.group(2)
        prefijo = unidad[:-1] if unidad[-1:].lower() == 's' else unidad
        factor = cls._PREFIJOS_UNIDAD.get(prefijo, cls._PREFIJOS_UNIDAD.get(prefijo.lower()))
        if factor is None:
            return None
        return valor * factor

    @classmethod
    def _factor_unidad_voltaje(cls, nombre_columna):
        """Busca una unidad de voltaje entre paréntesis en el nombre de columna, p.ej. '(mV)' -> 0.001. Sin unidad explícita: 1.0 (ya en Volts)."""
        m = re.search(r'\(([a-zA-Zµ]*)V\)', str(nombre_columna))
        if not m:
            return 1.0
        prefijo = m.group(1)
        return cls._PREFIJOS_UNIDAD.get(prefijo, cls._PREFIJOS_UNIDAD.get(prefijo.lower(), 1.0))

    def _leer_csv_formato_metadata(self, ruta):
        """
        Intenta leer un CSV con el formato "bloque de metadatos + tabla de
        muestras" (ver comentario de clase). Si el archivo no tiene pinta de
        ser este formato (p. ej. es el formato genérico "Time,CH1,CH2..."),
        devuelve None sin lanzar error, para que abrir_csv() siga con el
        parseo genérico de toda la vida.
        """
        try:
            with open(ruta, 'r', encoding='latin1', errors='ignore') as f:
                lineas = f.readlines()
        except OSError:
            return None

        if not lineas or not lineas[0].strip().lower().startswith('channel'):
            return None

        metadata = {}
        fin_metadata = None
        for i, linea in enumerate(lineas):
            limpia = linea.strip()
            if not limpia or ':' not in limpia:
                fin_metadata = i
                break
            clave, _, resto = limpia.partition(':')
            metadata[clave.strip().lower()] = [v.strip() for v in resto.lstrip(',').split(',')]
        else:
            return None  # el archivo terminó sin llegar a la tabla de datos

        if fin_metadata is None or 'channel' not in metadata or 'time interval' not in metadata:
            return None

        canales = metadata['channel']  # ej. ['CH1', 'CH2']
        intervalo_txt = metadata['time interval'][0] if metadata['time interval'] else None
        intervalo_seg = self._parsear_tiempo_con_unidad(intervalo_txt) if intervalo_txt else None
        if not intervalo_seg:
            return None

        idx_header = fin_metadata
        while idx_header < len(lineas) and not lineas[idx_header].strip():
            idx_header += 1
        if idx_header >= len(lineas):
            return None

        try:
            datos = pd.read_csv(ruta, sep=',', engine='python', encoding='latin1',
                                 skiprows=idx_header, on_bad_lines='skip')
        except Exception:
            return None
        if datos.shape[1] < 2:
            return None

        columnas_canal = list(datos.columns[1:])  # todo menos el índice de muestra
        n_canales = min(len(canales), len(columnas_canal))
        if n_canales == 0:
            return None

        resultado = pd.DataFrame()
        resultado['Time'] = np.arange(len(datos)) * intervalo_seg
        for i in range(n_canales):
            col_original = columnas_canal[i]
            factor = self._factor_unidad_voltaje(col_original)
            resultado[canales[i]] = pd.to_numeric(datos[col_original], errors='coerce') * factor

        resultado = resultado.dropna()
        return resultado if not resultado.empty else None

    def abrir_csv(self):
        """
        Abre un CSV, limpia nombres de columna de símbolos no ASCII (°, θ, etc.),
        convierte todo a numérico descartando columnas vacías, detecta Bode
        por regex y renombra sus columnas, o inicializa osciloscopio en caso contrario.

        Soporta dos formatos de entrada (dos osciloscopios distintos):
          1) Genérico: una fila de encabezado, primera columna = tiempo,
             columnas siguientes = canales, todo ya en Volts/segundos.
          2) Con bloque de metadatos (Channel, Time interval, etc.) seguido
             de una tabla "index,CH1_Voltage(mV),...": ver
             _leer_csv_formato_metadata().
        Se intenta primero el formato 2; si el archivo no matchea ese
        formato, se sigue con el parseo genérico de toda la vida.
        """
        ruta = filedialog.askopenfilename(filetypes=DEFAULT_FILE_TYPES)
        if not ruta:
            return

        try:
            df = self._leer_csv_formato_metadata(ruta)

            if df is None:
                # 1) detecta separador
                with open(ruta, 'r', encoding='latin1', errors='ignore') as f:
                    primera = f.readline()
                sep = '\t' if '\t' in primera else ','

                # 2) lee CSV (saltando líneas malformadas)
                df = pd.read_csv(ruta,
                                 sep=sep,
                                 encoding='latin1',
                                 engine='python',
                                 on_bad_lines='skip')

            # 3) limpia caracteres: quitar todo lo que no sea ASCII
            df.columns = [
                re.sub(r'[^\x20-\x7E]+', '', col).strip()
                for col in df.columns
            ]

            # 4) convertie todo a numérico (coerce), luego descarta columnas totalmente
            df = df.apply(pd.to_numeric, errors='coerce')
            df = df.loc[:, df.notna().any(axis=0)]
            if df.shape[1] < 2:
                messagebox.showwarning(
                    "Formato Inválido",
                    "No quedan al menos dos columnas numéricas tras la limpieza."
                )
                return

            # 5) elimina filas con cualquier
            df = df.dropna()
            if df.empty:
                messagebox.showwarning(
                    "Archivo Vacío",
                    "No quedan filas con datos completos tras la limpieza."
                )
                return

            
            self.df = df

            # Detectar si es Bode por regex sobre nombres
            freq = next((c for c in df.columns
                         if re.search(r'frequency', c, re.I) and re.search(r'hz', c, re.I)), None)
            gain = next((c for c in df.columns
                         if re.search(r'gain', c, re.I) and re.search(r'db', c, re.I)), None)
            phase = next((c for c in df.columns
                          if re.search(r'phase', c, re.I)), None)

            if freq and gain and phase:
                self.is_bode = True
                # renombra para plot_bode
                self.df = df.rename(columns={
                    freq: 'Frequency (Hz)',
                    gain: 'Gain (dB)',
                    phase: 'Phase ()'
                })
            else:
                self.is_bode = False

                # --- FIX: la señal siempre debe empezar en t=0s ---
                tcol = self.df.columns[0]
                self.df = self.df.sort_values(by=tcol).reset_index(drop=True)
                self.df[tcol] = self.df[tcol] - self.df[tcol].min()

                # Resetea offsets de un archivo previamente cargado
                self.offset_tension_ch1 = 0.0
                self.offset_tension_ch2 = 0.0
                self.scl_tension_offset.set(0)
                self._sincronizar_entry_offset_tension()

                # Prepara la vista como un osciloscopio.
                self.inicializar_volt_div()
                self.actualizar_rango_y_global()
                self.update_voltage_offset_range()
                self.t_min = self.df.iloc[:, 0].min()
                self.t_max = self.df.iloc[:, 0].max()
                self.ajustar_escala_tiempo()

            # 7) refresca la gráfica
            self.actualizar_grafica()

        except pd.errors.EmptyDataError:
            messagebox.showwarning("Error de Lectura", "El archivo CSV está vacío.")
        except Exception as e:
            messagebox.showerror(
                "Error Inesperado",
                f"Ocurrió un error al procesar el CSV:\n{e}"
            )

    def exportar_pdf(self):
        """Exporta la gráfica tal como se ve en pantalla (grilla, señales, cursores) a un PDF."""
        if self.df is None:
            messagebox.showwarning(
                "Sin datos",
                "Primero abrí un archivo CSV para poder exportar la gráfica."
            )
            return

        ruta = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("Archivo PDF", "*.pdf")],
            title="Guardar gráfica como PDF"
        )
        if not ruta:
            return

        try:
            self.fig.savefig(
                ruta,
                format="pdf",
                facecolor=self.fig.get_facecolor(),
                edgecolor="none",
                bbox_inches="tight"
            )
            messagebox.showinfo("Exportado", f"Gráfica guardada correctamente en:\n{ruta}")
        except Exception as e:
            messagebox.showerror("Error al exportar", f"No se pudo guardar el PDF:\n{e}")

    def actualizar_rango_y_global(self):
        """
        Calcula el rango global Y (min y max) de todos los datos
        sin considerar offset ni escala por división, para el auto-escalado inicial.
        """
        if self.df is None:
            self.ymin_global = None
            self.ymax_global = None
            return
        
        columnas_datos = self.df.columns[1:] 
        if not columnas_datos.empty:
            self.ymin_global = self.df[columnas_datos].min().min()
            self.ymax_global = self.df[columnas_datos].max().max()
        else:
            self.ymin_global = None
            self.ymax_global = None


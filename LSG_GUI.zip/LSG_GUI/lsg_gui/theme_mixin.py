"""
Aplicacion del tema claro/oscuro a toda la interfaz (ttk + matplotlib).

Estos metodos se mezclan (mixin) dentro de TC1ScopeApp en gui_app.py.
"""
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, colorchooser
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import re
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.collections import LineCollection
from .constants import *  # noqa: F401,F403 (colores y dimensiones de pantalla)


class ThemeMixin:
    def apply_theme(self):
        """Aplica el tema (claro/oscuro) a la interfaz y el gráfico."""
        self.current_colors = DARK_MODE_COLORS if self.var_modo_oscuro.get() else LIGHT_MODE_COLORS

        # Configurar estilo de ttk
        self.style.theme_use("clam") # Un tema base que se puede personalizar

        # Configurar colores de fondo de Tkinter y ttk frames/widgets
        self.root.configure(bg=self.current_colors["bg"])
        self.style.configure("TFrame", background=self.current_colors["frame_bg"])
        self.style.configure("TLabelframe", background=self.current_colors["frame_bg"],
                             foreground=self.current_colors["label_fg"])
        self.style.configure("TLabelframe.Label", background=self.current_colors["frame_bg"],
                     foreground=self.current_colors["label_fg"])

        self.style.configure("TLabel", background=self.current_colors["frame_bg"],
                             foreground=self.current_colors["label_fg"])
        self.style.configure("TButton", background=self.current_colors["button_bg"],
                             foreground=self.current_colors["button_fg"])
        self.style.map("TButton",
                       background=[('active', self.current_colors["button_bg"])]
                       )
        self.style.configure("TCheckbutton", background=self.current_colors["frame_bg"],
                             foreground=self.current_colors["label_fg"])
        self.style.configure("TRadiobutton", background=self.current_colors["frame_bg"],
                             foreground=self.current_colors["label_fg"])
        texto_color_combo = "white" if self.var_modo_oscuro.get() else "black"
        fondo_combo = self.current_colors["plot_bg"]

        combo_text_color = "white" if self.var_modo_oscuro.get() else "black"
        combo_bg_color = "#2e2e2e" if self.var_modo_oscuro.get() else "white"
        combo_field_bg = "#3c3c3c" if self.var_modo_oscuro.get() else "white"

        self.style.configure("TCombobox",
            background=combo_bg_color,
            fieldbackground=combo_field_bg,
            foreground=combo_text_color,
            arrowcolor=combo_text_color
        )

        self.style.map("TCombobox",
            fieldbackground=[("readonly", combo_field_bg)],
            foreground=[("readonly", combo_text_color)],
            background=[("readonly", combo_bg_color)],
            arrowcolor=[("readonly", combo_text_color)]
        )

        # Estilo para los Entry de etiquetas de canal (nombre editable)
        self.style.configure("TEntry",
            fieldbackground=combo_field_bg,
            foreground=combo_text_color,
            insertcolor=combo_text_color
        )


        



        # Configurar colores de Matplotlib
        if hasattr(self, 'ax') and hasattr(self, 'fig'):
            self.fig.set_facecolor(self.current_colors["plot_bg"])
            self.ax.set_facecolor(self.current_colors["plot_bg"])
            self.ax.spines['bottom'].set_color(self.current_colors["fg"])
            self.ax.spines['top'].set_color(self.current_colors["fg"])
            self.ax.spines['right'].set_color(self.current_colors["fg"])
            self.ax.spines['left'].set_color(self.current_colors["fg"])
            self.ax.tick_params(axis='x', colors=self.current_colors["fg"])
            self.ax.tick_params(axis='y', colors=self.current_colors["fg"])
            self.ax.xaxis.label.set_color(self.current_colors["fg"])
            self.ax.yaxis.label.set_color(self.current_colors["fg"])
            self.ax.title.set_color(self.current_colors["fg"])

            # Actualiza el grid si ya existe
            for line in self.ax.get_xgridlines() + self.ax.get_ygridlines():
                line.set_color(self.current_colors["grid"])
            
            # Re-dibuja líneas de datos y cursores con los nuevos colores si ya existen
            self.actualizar_grafica() 

        # Actualiza el estilo de los checkboxes personalizados según el modo
        if hasattr(self, 'chk_ch1') and hasattr(self, 'chk_ch2'):
            texto_color = "white" if self.var_modo_oscuro.get() else "black"
            self.chk_ch1.config(
                bg=self.current_colors["bg"],
                fg=texto_color,
                selectcolor=self.current_colors["bg"],
                activebackground=self.current_colors["bg"],
                activeforeground=texto_color
            )
            self.chk_ch2.config(
                bg=self.current_colors["bg"],
                fg=texto_color,
                selectcolor=self.current_colors["bg"],
                activebackground=self.current_colors["bg"],
                activeforeground=texto_color
            )

    def toggle_dark_mode(self):
        """Cambia entre modo claro y oscuro."""
        self.var_modo_oscuro.set(not self.var_modo_oscuro.get())
        self.apply_theme()


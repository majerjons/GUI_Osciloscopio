"""
Constantes de configuración de la aplicación: tipos de archivo, dimensiones
de la pantalla del osciloscopio y paletas de colores (modo claro/oscuro).

Centralizar estos valores acá facilita ajustarlos sin tener que buscar
"números mágicos" repartidos por todo el código.
"""

# --- Tipos de archivo para los diálogos de Abrir/Guardar ---
CSV_FILE_TYPES_DESCRIPTION = "Archivos CSV"
CSV_FILE_EXTENSION_PATTERN = "*.csv"
DEFAULT_FILE_TYPES = [(CSV_FILE_TYPES_DESCRIPTION, CSV_FILE_EXTENSION_PATTERN)]

# --- Dimensiones de la pantalla del osciloscopio (en cm) ---
OSCILLOSCOPE_SCREEN_WIDTH_CM = 32
OSCILLOSCOPE_SCREEN_HEIGHT_CM = 12
SCREEN_DIVISIONS_X = 10
SCREEN_DIVISIONS_Y = 8

# --- Colores para el modo claro ---
LIGHT_MODE_COLORS = {
    "bg": "lightgray",
    "fg": "black",
    "plot_bg": "#F0F0F0",
    "grid": "gray",
    "line_colors": ['blue', 'orange', 'green', 'red', 'purple', 'brown', 'pink', 'gray'],
    "cursor_x": "darkgreen",
    "cursor_y": "darkmagenta",
    "frame_bg": "lightgray",
    "label_fg": "black",
    "button_bg": "SystemButtonFace",
    "button_fg": "black"
}

# --- Colores para el modo oscuro ---
DARK_MODE_COLORS = {
    "bg": "#2e2e2e",
    "fg": "white",
    "plot_bg": "#1e1e1e",
    "grid": "#444444",
    "line_colors": ['cyan', 'lime', 'magenta', 'yellow', 'orange', 'white', 'purple', 'lightgray'],
    "cursor_x": "lightblue",
    "cursor_y": "lightcoral",
    "frame_bg": "#3c3c3c",
    "label_fg": "white",
    "button_bg": "#4a4a4a",
    "button_fg": "white"
}

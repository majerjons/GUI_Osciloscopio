"""Paquete de la aplicacion LSG GUI (osciloscopio virtual)."""

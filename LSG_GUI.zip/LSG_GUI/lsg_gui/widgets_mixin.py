"""
Construccion de los widgets de la ventana principal: botones, sliders,
y los bloques por canal (etiqueta, Volt/div, color, mediciones).

Estos metodos se mezclan (mixin) dentro de TC1ScopeApp en gui_app.py.
"""
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, colorchooser
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import re
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.collections import LineCollection
from .constants import *  # noqa: F401,F403 (colores y dimensiones de pantalla)


class WidgetsMixin:
    def create_widgets(self):
        """Crea y organiza todos los widgets de la interfaz."""
        # Frame superior para botones principales y cursores
        top_frame = ttk.Frame(self.root)
        top_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=5)

        # Botón Abrir CSV
        self.btn_abrir = ttk.Button(top_frame, text="Open CSV", command=self.abrir_csv)
        self.btn_abrir.pack(side=tk.LEFT, padx=5)

        # Botón Exportar a PDF
        self.btn_exportar_pdf = ttk.Button(top_frame, text="Export to PDF", command=self.exportar_pdf)
        self.btn_exportar_pdf.pack(side=tk.LEFT, padx=5)

        # Botón para resetear la posición de los bloques de mediciones
        # arrastrados sobre la gráfica V(t) (vuelven a las 2 columnas por defecto)
        self.btn_reset_medidas_pos = ttk.Button(
            top_frame, text="Reset Measurement Pos.", command=self.resetear_posicion_mediciones
        )
        self.btn_reset_medidas_pos.pack(side=tk.LEFT, padx=5)

        # Checkbox Usar Cursores
        self.chk_cursores = ttk.Checkbutton(top_frame, text="Use cursors", variable=self.var_cursores, command=self.actualizar_grafica)
        self.chk_cursores.pack(side=tk.LEFT, padx=10)

        # Checkbox Mover cursores en par (X1+X2 juntos, Y1+Y2 juntos)
        self.chk_cursor_link = ttk.Checkbutton(
            top_frame, text="Move cursors together", variable=self.var_cursor_link
        )
        self.chk_cursor_link.pack(side=tk.LEFT, padx=5)

        # Botón Default Setup y Modo Oscuro
        self.btn_default_setup = ttk.Button(top_frame, text="Default Setup", command=self.default_setup)
        self.btn_default_setup.pack(side=tk.RIGHT, padx=5)
        
        self.btn_toggle_mode = ttk.Button(top_frame, text="Dark Mode", command=self.toggle_dark_mode)
        self.btn_toggle_mode.pack(side=tk.RIGHT, padx=5)

        # --- Frame de Tracking independiente por cursor + posiciones/deltas ---
        cursor_frame = ttk.Frame(self.root)
        cursor_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=(0, 5))

        # Tracking de Y1 (sigue a X1) en un canal elegido
        frame_track_y1 = ttk.Frame(cursor_frame)
        frame_track_y1.pack(side=tk.LEFT, padx=(0, 10))
        self.chk_cursor_track_y1 = ttk.Checkbutton(
            frame_track_y1, text="Track Y1 on:", variable=self.var_cursor_track_y1,
            command=self.actualizar_grafica
        )
        self.chk_cursor_track_y1.pack(side="left")
        ttk.Radiobutton(frame_track_y1, text="Ch1", variable=self.canal_track_y1, value=1, command=self.actualizar_grafica).pack(side="left")
        ttk.Radiobutton(frame_track_y1, text="Ch2", variable=self.canal_track_y1, value=2, command=self.actualizar_grafica).pack(side="left")

        # Tracking de Y2 (sigue a X2), totalmente independiente del de Y1:
        # se puede dejar sin marcar para usar Y2 (junto con X2) como una
        # referencia fija (x0, y0) mientras Y1 sigue una señal.
        frame_track_y2 = ttk.Frame(cursor_frame)
        frame_track_y2.pack(side=tk.LEFT, padx=(0, 10))
        self.chk_cursor_track_y2 = ttk.Checkbutton(
            frame_track_y2, text="Track Y2 on:", variable=self.var_cursor_track_y2,
            command=self.actualizar_grafica
        )
        self.chk_cursor_track_y2.pack(side="left")
        ttk.Radiobutton(frame_track_y2, text="Ch1", variable=self.canal_track_y2, value=1, command=self.actualizar_grafica).pack(side="left")
        ttk.Radiobutton(frame_track_y2, text="Ch2", variable=self.canal_track_y2, value=2, command=self.actualizar_grafica).pack(side="left")

        # Etiqueta con la posición absoluta de cada uno de los 4 cursores
        self.label_cursor_pos = ttk.Label(cursor_frame, text="X1 = —   X2 = —   Y1 = —   Y2 = —")
        self.label_cursor_pos.pack(side=tk.LEFT, padx=15)

        # Etiqueta de Deltas
        self.label_deltas = ttk.Label(cursor_frame, text="ΔX = 0, ΔY = 0")
        self.label_deltas.pack(side=tk.RIGHT, padx=5)


        # Frame para controles de tiempo (Time/div y Offset de tiempo)
        time_control_frame = ttk.Frame(self.root)
        time_control_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=5)

        ttk.Label(time_control_frame, text="Time/div:").pack(side=tk.LEFT)
        # --- Escala en progresión 1-2-5 por década (estándar de osciloscopio: 1,2,5,10,20,50...) ---
        # Pasos mucho más finos que una lista fija, de 1 ns/div a 1 s/div.
        self.tiempos_por_div = self._generar_escala_tiempo()
        self.var_tiempo_div = tk.StringVar()
        self.combo_tiempo_div = ttk.Combobox(
            time_control_frame, values=[v[0] for v in self.tiempos_por_div],
            state="normal", width=12, textvariable=self.var_tiempo_div
        )
        # Default a 1 ms/div (busca el índice más cercano, ya que la lista es generada)
        self.combo_tiempo_div.current(self._indice_mas_cercano(self.tiempos_por_div, 1e-3))
        self.combo_tiempo_div.pack(side=tk.LEFT, padx=5)
        self.combo_tiempo_div.bind("<<ComboboxSelected>>", self.actualizar_grafica)
        # --- FIX: además de elegir un preset, el usuario puede escribir su
        # propio valor a mano (ej. "3.3 ms/div") y confirmarlo con Enter ---
        self.combo_tiempo_div.bind("<Return>", self.actualizar_grafica)
        self.combo_tiempo_div.bind("<FocusOut>", self.actualizar_grafica)

        # Slider de Offset de Tiempo
        self.scl_toffset = ttk.Scale(
            master=time_control_frame,
            from_=-SCREEN_DIVISIONS_X, # Rango inicial; se reajusta al cargar un CSV
            to=SCREEN_DIVISIONS_X,
            orient='horizontal',
            command=self.on_slider_offset,
            variable=self.var_offset_tiempo
        )
        self.scl_toffset.set(0)
        self.scl_toffset.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Label(time_control_frame, text="Time Offset").pack(side=tk.LEFT)

        self.btn_reset_toffset = ttk.Button(time_control_frame, text="Reset", command=self.reset_offset)
        self.btn_reset_toffset.pack(side=tk.LEFT, padx=5)


        # Frame para controles de voltaje (Volt/div y Offset de tensión)
        volt_control_frame = ttk.Frame(self.root)
        volt_control_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=5)

        # Selector de canal para offset
        ttk.Label(volt_control_frame, text="Voltage Offset Ch:").pack(side="left")
        ttk.Radiobutton(volt_control_frame, text="Ch1", variable=self.canal_offset, value=1, command=self.actualizar_slider_offset).pack(side="left")
        ttk.Radiobutton(volt_control_frame, text="Ch2", variable=self.canal_offset, value=2, command=self.actualizar_slider_offset).pack(side="left")

        # Slider de Offset de Tensión
        self.scl_tension_offset = ttk.Scale(
            master=volt_control_frame,
            from_=-5 * SCREEN_DIVISIONS_Y, # Offset de 5 divisiones hacia abajo
            to=5 * SCREEN_DIVISIONS_Y,     # Offset de 5 divisiones hacia arriba
            orient='horizontal',
            command=self.on_slider_offset_volt
        )
        self.scl_tension_offset.set(0)
        self.scl_tension_offset.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Label(volt_control_frame, text="Voltage Offset").pack(side=tk.LEFT)

        self.btn_reset_voffset = ttk.Button(volt_control_frame, text="Reset", command=self.reset_offset_volt)
        self.btn_reset_voffset.pack(side=tk.LEFT, padx=5)


        # Fila que agrupa, lado a lado: los bloques por canal (izquierda) y
        # las opciones de qué mostrar superpuesto en la gráfica V(t) (derecha).
        fila_canales = ttk.Frame(self.root)
        fila_canales.pack(side=tk.TOP, fill=tk.X, padx=10, pady=5)

        # Frame combinado: personalización de canal (etiqueta/volt-div/color)
        # + mediciones automáticas, lado a lado por canal, para no restarle
        # altura al gráfico V(t) (antes eran dos LabelFrames apilados).
        self.frame_voltdiv = ttk.LabelFrame(fila_canales, text="Channels & Measurements")
        self.frame_voltdiv.pack(side=tk.LEFT, fill=tk.Y)

        # Panel "Show on Graph": en paralelo (al costado) del anterior,
        # elige qué bloques de texto opcionales se superponen y se pueden
        # arrastrar sobre la gráfica V(t): coordenadas de los cursores y
        # offset de tensión aplicado. Cada medición por canal ya tiene su
        # propio checkbox en "Channels & Measurements"; estos dos son
        # generales (no por canal).
        self.frame_mostrar_en_grafica = ttk.LabelFrame(fila_canales, text="Show on Graph")
        self.frame_mostrar_en_grafica.pack(side=tk.LEFT, padx=(10, 0), fill=tk.Y)

        self.chk_mostrar_coords_cursores = ttk.Checkbutton(
            self.frame_mostrar_en_grafica, text="Cursor coordinates",
            variable=self.var_mostrar_coords_cursores, command=self.actualizar_grafica
        )
        self.chk_mostrar_coords_cursores.pack(side=tk.TOP, anchor="w", padx=8, pady=(4, 2))

        self.chk_mostrar_offset_tension = ttk.Checkbutton(
            self.frame_mostrar_en_grafica, text="Voltage offset",
            variable=self.var_mostrar_offset_tension, command=self.actualizar_grafica
        )
        self.chk_mostrar_offset_tension.pack(side=tk.TOP, anchor="w", padx=8, pady=(2, 4))

        # Panel "Manual Offset": al costado de "Show on Graph". Permite
        # escribir a mano un offset de tiempo y de tensión (valor numérico +
        # unidad), sin la limitación del rango del slider correspondiente
        # (p. ej. pedir un offset de 3 V cuando el slider solo llega a
        # ±1.04 V con la escala Volt/div actual: el slider se agranda solo).
        self.frame_offset_manual = ttk.LabelFrame(fila_canales, text="Manual Offset")
        self.frame_offset_manual.pack(side=tk.LEFT, padx=(10, 0), fill=tk.Y)

        fila_toffset_manual = ttk.Frame(self.frame_offset_manual)
        fila_toffset_manual.pack(side=tk.TOP, anchor="w", padx=8, pady=(4, 2))
        ttk.Label(fila_toffset_manual, text="Time:").pack(side=tk.LEFT)
        self.entry_toffset_num = ttk.Entry(fila_toffset_manual, width=8, textvariable=self.var_toffset_num)
        self.entry_toffset_num.pack(side=tk.LEFT, padx=(4, 2))
        self.entry_toffset_num.bind("<Return>", self.aplicar_offset_tiempo_manual)
        self.entry_toffset_num.bind("<FocusOut>", self.aplicar_offset_tiempo_manual)
        self.combo_toffset_unidad = ttk.Combobox(
            fila_toffset_manual, values=["s", "ms", "µs", "ns"], width=4,
            state="readonly", textvariable=self.var_toffset_unidad
        )
        self.combo_toffset_unidad.pack(side=tk.LEFT)
        # Cambiar solo la unidad re-muestra el mismo offset ya aplicado
        # convertido a esa unidad (no reinterpreta el número tipeado).
        self.combo_toffset_unidad.bind("<<ComboboxSelected>>", lambda e: self._sincronizar_entry_offset_tiempo())

        fila_voffset_manual = ttk.Frame(self.frame_offset_manual)
        fila_voffset_manual.pack(side=tk.TOP, anchor="w", padx=8, pady=(2, 4))
        ttk.Label(fila_voffset_manual, text="Voltage:").pack(side=tk.LEFT)
        self.entry_voffset_num = ttk.Entry(fila_voffset_manual, width=8, textvariable=self.var_voffset_num)
        self.entry_voffset_num.pack(side=tk.LEFT, padx=(4, 2))
        self.entry_voffset_num.bind("<Return>", self.aplicar_offset_tension_manual)
        self.entry_voffset_num.bind("<FocusOut>", self.aplicar_offset_tension_manual)
        self.combo_voffset_unidad = ttk.Combobox(
            fila_voffset_manual, values=["V", "mV"], width=4,
            state="readonly", textvariable=self.var_voffset_unidad
        )
        self.combo_voffset_unidad.pack(side=tk.LEFT)
        self.combo_voffset_unidad.bind("<<ComboboxSelected>>", lambda e: self._sincronizar_entry_offset_tension())

        ttk.Label(
            self.frame_offset_manual, text="(voltage: applies to Ch\nselected above)",
            font=("TkDefaultFont", 7)
        ).pack(side=tk.TOP, anchor="w", padx=8, pady=(0, 4))

        self.voltajes_por_div = self._generar_escala_voltaje()

        self.channel_frames = []
        self.channel_label_vars = []
        self.volt_div_vars = []
        self.volt_div_combos = []
        self.channel_color_buttons = []
        self.canal_colores = []  # color hex elegido por el usuario (None = usa color del tema)
        self.measurement_vars = []  # lista de dicts {clave: StringVar} de mediciones, por canal
        self.measurement_show_vars = []  # lista de dicts {clave: BooleanVar}: qué mediciones mostrar como label en la gráfica

        # Inicialmente, crea el bloque para los 2 canales más comunes.
        # Se recrea dinámicamente en inicializar_volt_div si se carga un CSV con más/menos canales.
        for i in range(2):
            self._crear_bloque_canal(i, f"CH{i + 1}")

    def _color_actual_canal(self, index):
        """Devuelve el color hex a usar para el canal 'index': el elegido por el usuario, o si no eligió ninguno, el del tema actual."""
        if index < len(self.canal_colores) and self.canal_colores[index]:
            return self.canal_colores[index]
        colores_tema = self.current_colors["line_colors"]
        return colores_tema[index % len(colores_tema)]

    def _actualizar_swatch_boton(self, index):
        """Pinta el botón de color del canal con el color que está usando actualmente."""
        if index < len(self.channel_color_buttons):
            try:
                self.channel_color_buttons[index].config(bg=self._color_actual_canal(index))
            except Exception:
                pass

    def elegir_color_canal(self, index):
        """Abre el selector de color de Tk y asigna el color elegido a la curva del canal."""
        color_inicial = self._color_actual_canal(index)
        try:
            resultado = colorchooser.askcolor(color=color_inicial, title=f"Color del Canal {index + 1}")
        except Exception:
            resultado = colorchooser.askcolor(title=f"Color del Canal {index + 1}")
        if resultado and resultado[1] and index < len(self.canal_colores):
            self.canal_colores[index] = resultado[1]
            self._actualizar_swatch_boton(index)
            self.actualizar_grafica()

    def _crear_bloque_canal(self, index, nombre_default):
        """
        Crea, para un canal, un único bloque horizontal que combina:
        - a la izquierda: personalización (etiqueta editable, Volt/div, color)
        - a la derecha: mediciones automáticas (Max, Min, Pk-Pk, Mean, RMS, Freq, Period)
        en una grilla compacta de 2 filas, para aprovechar mejor el espacio
        vertical y dejarle más lugar al gráfico V(t).
        """
        bloque = ttk.LabelFrame(self.frame_voltdiv, text=nombre_default)
        bloque.pack(side=tk.LEFT, padx=8, pady=5, fill=tk.Y)

        # --- Izquierda: etiqueta / Volt-div / color ---
        subframe = ttk.Frame(bloque)
        subframe.pack(side=tk.LEFT, padx=(6, 6), pady=4)

        label_var = tk.StringVar(value=nombre_default)
        entry = ttk.Entry(subframe, textvariable=label_var, width=10, justify="center")
        entry.pack(side=tk.TOP)
        entry.bind("<Return>", self.actualizar_grafica)
        entry.bind("<FocusOut>", self.actualizar_grafica)

        volt_var = tk.StringVar(value="1 V/div")
        combo = ttk.Combobox(
            subframe, values=[v[0] for v in self.voltajes_por_div],
            textvariable=volt_var, state="normal", width=10
        )
        combo.pack(side=tk.TOP, pady=2)
        combo.bind("<<ComboboxSelected>>", self.actualizar_grafica)
        # --- FIX: permite escribir un Volt/div a mano (ej. "0.3 V/div") ---
        combo.bind("<Return>", self.actualizar_grafica)
        combo.bind("<FocusOut>", self.actualizar_grafica)

        color_btn = tk.Button(subframe, text="Color", width=9, command=lambda idx=index: self.elegir_color_canal(idx))
        color_btn.pack(side=tk.TOP)

        self.channel_frames.append(bloque)
        self.channel_label_vars.append(label_var)
        self.volt_div_vars.append(volt_var)
        self.volt_div_combos.append(combo)
        self.channel_color_buttons.append(color_btn)
        self.canal_colores.append(None)
        self._actualizar_swatch_boton(index)

        # --- Separador vertical ---
        ttk.Separator(bloque, orient='vertical').pack(side=tk.LEFT, fill='y', padx=4, pady=2)

        # --- Derecha: mediciones automáticas, en grilla compacta 2x4 ---
        stats_frame = ttk.Frame(bloque)
        stats_frame.pack(side=tk.LEFT, padx=(4, 8), pady=4)

        etiquetas_stats = [
            ('max', 'Max'), ('min', 'Min'), ('pkpk', 'Pk-Pk'), ('mean', 'Mean'),
            ('rms', 'RMS'), ('freq', 'Freq'), ('period', 'Period')
        ]
        stats_vars = {}
        show_vars = {}
        columnas = 4  # 4 mediciones por fila (2 filas: 4 + 3)
        for idx_stat, (clave, texto) in enumerate(etiquetas_stats):
            fila = idx_stat // columnas
            col = (idx_stat % columnas) * 3

            # Checkbox para elegir si esta medición se muestra como label en la gráfica V(t)
            show_var = tk.BooleanVar(value=False)
            chk = ttk.Checkbutton(
                stats_frame, variable=show_var, command=self.actualizar_grafica
            )
            chk.grid(row=fila, column=col, sticky='e', padx=(4, 0), pady=1)

            ttk.Label(stats_frame, text=f"{texto}:", font=('TkDefaultFont', 8)).grid(
                row=fila, column=col + 1, sticky='e', padx=(0, 2), pady=1
            )
            var = tk.StringVar(value="—")
            ttk.Label(stats_frame, textvariable=var, font=('TkDefaultFont', 8)).grid(
                row=fila, column=col + 2, sticky='w', padx=(0, 10), pady=1
            )
            stats_vars[clave] = var
            show_vars[clave] = show_var

        self.measurement_vars.append(stats_vars)
        self.measurement_show_vars.append(show_vars)

    def setup_plot(self):
        """Configura el área de trazado de Matplotlib."""
        ancho_in = OSCILLOSCOPE_SCREEN_WIDTH_CM / 2.54
        alto_in = OSCILLOSCOPE_SCREEN_HEIGHT_CM / 2.54
        self.fig, self.ax = plt.subplots(figsize=(ancho_in, alto_in))
        self.fig.subplots_adjust(left=0.05, right=0.95, top=0.9, bottom=0.1) # Ajustar para título y labels
        
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.root)
        canvas_widget = self.canvas.get_tk_widget()
        canvas_widget.pack(fill=tk.BOTH, expand=True)

        # Agrega la barra de herramientas de navegación de Matplotlib (zoom, pan, save)
        self.toolbar = NavigationToolbar2Tk(self.canvas, self.root)
        self.toolbar.update()
        self.canvas._tkcanvas.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        self.ax.set_title("Load a CSV file", color=self.current_colors["fg"])
        self.ax.set_xlabel("Time", color=self.current_colors["fg"])
        self.ax.set_ylabel("Voltage", color=self.current_colors["fg"])
        self.ax.legend()
        self.ax.grid(True)
        self.apply_theme() # Aplicar el tema inicial
        self.canvas.draw()

    def default_setup(self):
        """Restablece la configuración de visualización a valores por defecto."""
        # Restablecer sliders de offset
        self.scl_toffset.set(0.0)
        self.offset_divisiones = 0.0
        self.scl_tension_offset.set(0.0)
        self.offset_tension_ch1 = 0.0
        self.offset_tension_ch2 = 0.0
        self.canal_offset.set(1) # Canal de offset por defecto

        # Restablecer combobox de tiempo/div
        self.combo_tiempo_div.current(self._indice_mas_cercano(self.tiempos_por_div, 1e-3)) # Default a 1ms/div

        # Restablecer comboboxes de volt/div
        for var in self.volt_div_vars:
            var.set("1 V/div") 

        # Desactiva cursores y tracking
        self.var_cursores.set(False)
        self.var_cursor_track_y1.set(False)
        self.var_cursor_track_y2.set(False)
        self.var_mostrar_coords_cursores.set(False)
        self.var_mostrar_offset_tension.set(False)

        # Restablecer cajas numéricas de offset manual
        self.var_toffset_num.set("0")
        self.var_voffset_num.set("0")

        # Actualiza la gráfica con la nueva configuración
        self.actualizar_grafica()

    def inicializar_volt_div(self):
        """
        Destruye y recrea los bloques por canal (personalización + mediciones,
        combinados en un solo bloque horizontal) según el número de columnas
        de datos del CSV cargado.
        """
        # Elimina los bloques existentes (cada uno agrupa personalización + mediciones)
        for frame in self.channel_frames:
            frame.destroy()
        self.channel_frames = []
        self.channel_label_vars = []
        self.volt_div_vars = []
        self.volt_div_combos = []
        self.channel_color_buttons = []
        self.canal_colores = []
        self.measurement_vars = []
        self.measurement_show_vars = []

        if self.df is None or self.df.shape[1] < 2:
            return # No hay datos o solo columna de tiempo

        # Crea un bloque por cada columna de datos (excluyendo la primera de tiempo)
        for i in range(self.df.shape[1] - 1):
            nombre_col = str(self.df.columns[i + 1])
            self._crear_bloque_canal(i, nombre_col)

        self.apply_theme() # Reaplica el tema a los nuevos controles
        self.actualizar_mediciones()


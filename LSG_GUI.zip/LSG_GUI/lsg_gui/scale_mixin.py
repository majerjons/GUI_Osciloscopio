"""
Helpers de escala: generacion y formateo de las listas de Time/div y
Volt/div, parseo de valores escritos a mano, y conversion div <-> unidad real.

Estos metodos se mezclan (mixin) dentro de TC1ScopeApp en gui_app.py.
"""
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, colorchooser
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import re
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.collections import LineCollection
from .constants import *  # noqa: F401,F403 (colores y dimensiones de pantalla)


class ScaleMixin:
    def _generar_escala_tiempo(self):
        """
        Genera la lista de Time/div en progresión 1-2-5 por década (1, 2, 5,
        10, 20, 50, 100...), el estándar de los osciloscopios reales. Da pasos
        mucho más finos que una lista fija, de 1 ns/div a 1 s/div.
        """
        valores = set()
        for exp in range(-9, 1):  # 1e-9 s (1 ns) a 1e0 s (1 s)
            for mult in (1, 2, 5):
                v = round(mult * (10 ** exp), 15)
                if v <= 1.0 + 1e-12:
                    valores.add(v)
        return [(self._formatear_escala_tiempo(v), v) for v in sorted(valores)]

    def _generar_escala_voltaje(self):
        """
        Genera la lista de Volt/div en progresión 1-2-5 por década, de
        1 mV/div a 10 V/div (el rango típico de un osciloscopio de banco).
        """
        valores = set()
        for exp in range(-3, 2):  # 1e-3 V (1 mV) a 1e1 V (10 V)
            for mult in (1, 2, 5):
                v = round(mult * (10 ** exp), 12)
                if v <= 10.0 + 1e-9:
                    valores.add(v)
        return [(self._formatear_escala_voltaje(v), v) for v in sorted(valores)]

    @staticmethod
    def _formatear_escala_tiempo(v_segundos):
        if v_segundos < 1e-6 - 1e-18:
            return f"{v_segundos * 1e9:.3g} ns/div"
        elif v_segundos < 1e-3 - 1e-18:
            return f"{v_segundos * 1e6:.3g} μs/div"
        elif v_segundos < 1 - 1e-18:
            return f"{v_segundos * 1e3:.3g} ms/div"
        else:
            return f"{v_segundos:.3g} s/div"

    @staticmethod
    def _formatear_escala_voltaje(v_volts):
        if v_volts < 1 - 1e-9:
            return f"{v_volts * 1e3:.3g} mV/div"
        else:
            return f"{v_volts:.3g} V/div"

    @staticmethod
    def _indice_mas_cercano(lista_pares, valor_objetivo):
        """Devuelve el índice de 'lista_pares' (lista de (texto, valor)) cuyo valor está más cerca de valor_objetivo."""
        mejor_idx, mejor_diff = 0, float('inf')
        for i, (_, v) in enumerate(lista_pares):
            diff = abs(v - valor_objetivo)
            if diff < mejor_diff:
                mejor_diff, mejor_idx = diff, i
        return mejor_idx

    def _parsear_escala_manual(self, texto, tipo):
        """
        Interpreta un valor de escala escrito a mano por el usuario, ej.
        '3.3 ms/div', '3.3ms', '250 mV', '0.5' (usa la unidad por defecto).
        tipo: 'tiempo' -> devuelve segundos; 'voltaje' -> devuelve volts.
        Devuelve (valor_base, unidad_texto) o None si no se pudo interpretar.
        """
        if not texto:
            return None
        texto = texto.strip()
        m = re.match(r'^([0-9]*\.?[0-9]+)\s*([a-zA-Zµμ]*)', texto)
        if not m or not m.group(1):
            return None
        try:
            numero = float(m.group(1))
        except ValueError:
            return None

        unidad = m.group(2).replace("/div", "").replace("/Div", "").strip()

        if tipo == "tiempo":
            factores = {"ns": 1e-9, "μs": 1e-6, "µs": 1e-6, "us": 1e-6, "ms": 1e-3, "s": 1.0}
            if not unidad:
                unidad = "ms"  # unidad por defecto razonable si el usuario solo escribe un número
        else:
            factores = {"mv": 1e-3, "v": 1.0}
            if not unidad:
                unidad = "V"

        factor = factores.get(unidad) if tipo == "tiempo" else factores.get(unidad.lower())
        if factor is None or numero <= 0:
            return None
        if tipo == "voltaje":
            unidad = "mV" if unidad.lower() == "mv" else "V"
        return numero * factor, unidad

    def obtener_factor_tiempo_div(self):
        """Devuelve el valor en segundos correspondiente al Time/div seleccionado (preset o escrito a mano)."""
        tiempo_div_str = self.var_tiempo_div.get()
        preset = dict(self.tiempos_por_div).get(tiempo_div_str)
        if preset is not None:
            return preset
        manual = self._parsear_escala_manual(tiempo_div_str, "tiempo")
        if manual is not None:
            return manual[0]
        return 1e-3

    def obtener_unidad_tiempo_actual(self):
        """Devuelve (unidad, factor_de_escala) según el Time/div seleccionado, ej. ('ms', 1e3)."""
        tiempo_div_str = self.var_tiempo_div.get()
        if dict(self.tiempos_por_div).get(tiempo_div_str) is not None:
            try:
                unidad = tiempo_div_str.split()[1].replace("/div", "")
            except IndexError:
                unidad = "s"
        else:
            manual = self._parsear_escala_manual(tiempo_div_str, "tiempo")
            unidad = manual[1] if manual is not None else "ms"
        factores = {"ns": 1e9, "μs": 1e6, "µs": 1e6, "us": 1e6, "ms": 1e3, "s": 1}
        return unidad, factores.get(unidad, 1)

    def obtener_factor_volt_div(self, canal_idx):
        """Devuelve el valor en volts correspondiente al Volt/div del canal dado (0-based; preset o escrito a mano)."""
        if 0 <= canal_idx < len(self.volt_div_vars):
            volt_div_str = self.volt_div_vars[canal_idx].get()
        else:
            volt_div_str = "1 V/div"
        preset = dict(self.voltajes_por_div).get(volt_div_str)
        if preset is not None:
            return preset
        manual = self._parsear_escala_manual(volt_div_str, "voltaje")
        if manual is not None:
            return manual[0]
        return 1

    def _tiempo_real_desde_div(self, x_div):
        """Convierte una posición X de cursor (divisiones de pantalla) al tiempo real de la señal (segundos)."""
        tiempo_div_segs = self.obtener_factor_tiempo_div()
        return (x_div - self.offset_divisiones) * tiempo_div_segs

    def _valor_real_desde_div(self, y_div, canal_idx):
        """Convierte una posición Y de cursor (divisiones de pantalla del canal dado) al valor real en volts."""
        factor_volt_div = self.obtener_factor_volt_div(canal_idx)
        offset = 0.0
        if canal_idx == 0:
            offset = self.offset_tension_ch1
        elif canal_idx == 1:
            offset = self.offset_tension_ch2
        return y_div * factor_volt_div - offset

    def obtener_unidad_valor(self, canal_idx):
        """Devuelve (unidad, factor_de_escala) según el Volt/div del canal dado (preset o escrito a mano)."""
        if 0 <= canal_idx < len(self.volt_div_vars):
            volt_div_str = self.volt_div_vars[canal_idx].get()
        else:
            volt_div_str = "1 V/div"
        if dict(self.voltajes_por_div).get(volt_div_str) is not None:
            try:
                unidad = volt_div_str.split()[1].replace("/div", "")
            except IndexError:
                unidad = "V"
        else:
            manual = self._parsear_escala_manual(volt_div_str, "voltaje")
            unidad = manual[1] if manual is not None else "V"
        factores = {"mV": 1e3, "V": 1}
        return unidad, factores.get(unidad, 1)

    def obtener_canal_referencia(self):
        """Índice (0-based) del primer canal visible; se usa para calibrar el eje Y en volts."""
        if self.mostrar_ch1.get():
            return 0
        elif self.mostrar_ch2.get():
            return 1
        return 0


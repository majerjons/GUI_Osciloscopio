"""
Clase principal de la aplicación: TC1ScopeApp.

La clase en sí es apenas un __init__ que arma el estado inicial y arranca
la interfaz; toda la lógica está organizada por tema en los distintos
"mixins" (theme_mixin, widgets_mixin, scale_mixin, data_mixin,
offsets_mixin, plot_mixin, cursors_mixin, measurements_mixin) que se
combinan acá abajo. Esto permite ir a buscar directamente el archivo del
tema que se necesita tocar (p. ej. todo lo de cursores está en
cursors_mixin.py) en vez de recorrer un único archivo de 2000 líneas.

Agregar una funcionalidad nueva y grande (p. ej. un modo FFT) es tan simple
como sumar un mixin más a la lista de herencia de TC1ScopeApp.
"""
import tkinter as tk
from tkinter import ttk

from .constants import LIGHT_MODE_COLORS
from .theme_mixin import ThemeMixin
from .widgets_mixin import WidgetsMixin
from .scale_mixin import ScaleMixin
from .data_mixin import DataMixin
from .offsets_mixin import OffsetsMixin
from .plot_mixin import PlotMixin
from .cursors_mixin import CursorsMixin
from .measurements_mixin import MeasurementsMixin


class TC1ScopeApp(
    ThemeMixin,
    WidgetsMixin,
    ScaleMixin,
    DataMixin,
    OffsetsMixin,
    PlotMixin,
    CursorsMixin,
    MeasurementsMixin,
):
    """Aplicación de osciloscopio virtual (visualización de CSV de TC1/LSG)."""

    def __init__(self, root):
        self.is_bode = False
        self.root = root
        self.df = None
        self.primera_grafica = True
        self.unidad_tiempo = "s"
        self.unidad_valor = "V"
        self.lineas = []
        self._canal_visible_data = {}
        self.selected_cursor = None
        self._selected_cursor_name = None  # 'cursor_x1' / 'cursor_x2' / 'cursor_y1' / 'cursor_y2'
        self._drag_inicio = None           # posiciones iniciales de los 4 cursores al empezar a arrastrar
        self.cursor_marker1 = None         # marca sobre la curva cuando el tracking está activo
        self.cursor_marker2 = None
        # Mediciones superpuestas en la gráfica V(t): posición (arrastrable) por canal
        self._medicion_pos = {}              # {canal_idx: (x_frac, y_frac)} posiciones elegidas a mano
        self._medicion_text_artists = {}     # {canal_idx: Text} artistas del último redibujado
        self._dragging_medicion_idx = None   # canal cuyo bloque de mediciones se está arrastrando
        self.cursor_x1 = None
        self.cursor_x2 = None
        self.cursor_y1 = None
        self.cursor_y2 = None
        self.ymin_global = None
        self.ymax_global = None
        self._actualizando_slider = False  # Flag para evitar recursión en sliders
        self.offset_divisiones = 0.0  # Offset de tiempo en número de divisiones
        self.offset_tension_ch1 = 0.0
        self.offset_tension_ch2 = 0.0
        self.canal_offset = tk.IntVar(value=1)
        self.canal_cursores = tk.IntVar(value=1)  # (legado, ya no se usa para elegir un único canal de ΔY)
        self.var_cursores = tk.BooleanVar(value=False)
        # Tracking independiente por par de cursores: Y1 (junto a X1) puede
        # seguir una señal mientras Y2 (junto a X2) queda fijo, o viceversa,
        # para poder usarlo como referencia manual (x0, y0).
        self.var_cursor_track_y1 = tk.BooleanVar(value=False)
        self.var_cursor_track_y2 = tk.BooleanVar(value=False)
        self.canal_track_y1 = tk.IntVar(value=1)  # Canal de referencia (volts/div) para Y1
        self.canal_track_y2 = tk.IntVar(value=1)  # Canal de referencia (volts/div) para Y2
        self.var_cursor_link = tk.BooleanVar(value=False)  # Mover X1+X2 / Y1+Y2 en par
        # Bloques de texto opcionales, arrastrables, superpuestos en la
        # gráfica V(t) (panel "Show on Graph", al costado de "Channels &
        # Measurements"): coordenadas de los cursores y offset de tensión.
        self.var_mostrar_coords_cursores = tk.BooleanVar(value=False)
        self.var_mostrar_offset_tension = tk.BooleanVar(value=False)
        # Cajas numéricas para ingresar el offset a mano (valor + unidad),
        # para poder pedir un offset más grande de lo que el slider permite
        # (el slider tiene un rango acotado; escribir el número no).
        self.var_toffset_num = tk.StringVar(value="0")
        self.var_toffset_unidad = tk.StringVar(value="ms")
        self.var_voffset_num = tk.StringVar(value="0")
        self.var_voffset_unidad = tk.StringVar(value="V")
        self.var_offset_tiempo = tk.DoubleVar(value=0.0)
        self.var_modo_oscuro = tk.BooleanVar(value=False)
        self.current_colors = LIGHT_MODE_COLORS  # Colores actuales
        # Variables de control de visibilidad
        self.mostrar_ch1 = tk.BooleanVar(value=True)
        self.mostrar_ch2 = tk.BooleanVar(value=True)

        # Checkboxes para mostrar/ocultar canales
        self.chk_ch1 = tk.Checkbutton(self.root, text="View Channel 1", variable=self.mostrar_ch1,
                                       command=self.actualizar_grafica)
        self.chk_ch2 = tk.Checkbutton(self.root, text="View Channel 2", variable=self.mostrar_ch2,
                                       command=self.actualizar_grafica)
        self.chk_ch1.pack()
        self.chk_ch2.pack()

        self.root.title("LSG GUI")

        # Ajuste de resolución de la ventana
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        width = int(screen_width * 0.9)
        height = int(screen_height * 0.9)
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        self.root.geometry(f"{width}x{height}+{x}+{y}")

        # Configuración de los estilos para ttk (para modo oscuro)
        self.style = ttk.Style()
        self.apply_theme()

        self.create_widgets()
        self.setup_plot()

        # Conectar eventos de Matplotlib para los cursores
        self.canvas.mpl_connect('button_press_event', self.on_press)
        self.canvas.mpl_connect('button_release_event', self.on_release)
        self.canvas.mpl_connect('motion_notify_event', self.on_motion)
        self.canvas.mpl_connect('resize_event', self.on_resize)  # Capturar evento de redimensionado de figura

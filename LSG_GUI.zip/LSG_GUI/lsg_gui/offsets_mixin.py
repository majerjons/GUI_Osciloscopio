"""
Sliders de offset de tiempo/tension y ajuste automatico de escala y unidades.

Estos metodos se mezclan (mixin) dentro de TC1ScopeApp en gui_app.py.
"""
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, colorchooser
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import re
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.collections import LineCollection
from .constants import *  # noqa: F401,F403 (colores y dimensiones de pantalla)


class OffsetsMixin:
    # Factores de conversión a la unidad base (segundos / Volts)
    _UNIDADES_TIEMPO = {'s': 1.0, 'ms': 1e-3, 'µs': 1e-6, 'us': 1e-6, 'ns': 1e-9}
    _UNIDADES_VOLTAJE = {'V': 1.0, 'mV': 1e-3, 'µV': 1e-6, 'uV': 1e-6}

    def on_slider_offset(self, valor_offset):
        """Maneja el evento del slider de offset de tiempo."""
        if self.df is None:
            return
        # El valor del slider es el número de divisiones que se quiere mover.
        self.offset_divisiones = float(valor_offset)
        self._sincronizar_entry_offset_tiempo()
        self.actualizar_grafica()

    def reset_offset(self):
        self.var_offset_tiempo.set(0.0)
        self.offset_divisiones = 0.0
        self._sincronizar_entry_offset_tiempo()
        self.actualizar_grafica()

    def _sincronizar_entry_offset_tiempo(self):
        """Refleja el offset de tiempo actual en la caja numérica, expresado en la unidad elegida en su combobox."""
        if not hasattr(self, 'var_toffset_num'):
            return
        tiempo_div_segs = self.obtener_factor_tiempo_div()
        valor_seg = self.offset_divisiones * tiempo_div_segs if tiempo_div_segs else 0.0
        factor = self._UNIDADES_TIEMPO.get(self.var_toffset_unidad.get(), 1e-3)
        self.var_toffset_num.set(f"{valor_seg / factor:.4g}" if factor else "0")

    def aplicar_offset_tiempo_manual(self, event=None):
        """
        Aplica el offset de tiempo escrito a mano (valor numérico + unidad
        del combobox de al lado), sin la limitación del rango del slider:
        si hace falta, el rango del slider se agranda para representarlo.
        """
        if self.df is None:
            return
        try:
            valor = float(str(self.var_toffset_num.get()).strip().replace(',', '.'))
        except (ValueError, tk.TclError):
            return  # el usuario todavía está escribiendo / valor inválido: no hacemos nada

        tiempo_div_segs = self.obtener_factor_tiempo_div()
        if not tiempo_div_segs:
            return

        factor = self._UNIDADES_TIEMPO.get(self.var_toffset_unidad.get(), 1e-3)
        nuevas_divisiones = (valor * factor) / tiempo_div_segs

        # Agranda el rango del slider si el valor pedido no entra.
        limite_actual = float(self.scl_toffset.cget('to'))
        if abs(nuevas_divisiones) > limite_actual:
            nuevo_limite = abs(nuevas_divisiones) * 1.1
            self.scl_toffset.config(from_=-nuevo_limite, to=nuevo_limite)

        self.offset_divisiones = nuevas_divisiones
        self.var_offset_tiempo.set(nuevas_divisiones)  # sincroniza la posición visual del slider
        self.actualizar_grafica()

    def on_slider_offset_volt(self, valor_offset_entero):
        """Maneja el evento del slider de offset de tensión para el canal seleccionado."""
        # No hacemos nada si todavía estamos actualizando o no hay datos
        if self._actualizando_slider or self.df is None:
            return
        # Ignorar el slider si el canal está oculto
        canal = self.canal_offset.get()
        if (canal == 1 and not self.mostrar_ch1.get()) or (canal == 2 and not self.mostrar_ch2.get()):
            return
        self._actualizando_slider = True
        try:
            # Obteniene factor de volt/div del canal
            volt_div_str = self.volt_div_vars[canal-1].get() if canal-1 < len(self.volt_div_vars) else "1 V/div"
            volt_div_value = dict(self.voltajes_por_div).get(volt_div_str, 1)
            # Convertierte divisiones a volts
            offset_real = float(valor_offset_entero) * volt_div_value
            # Asigna al atributo correcto
            if canal == 1:
                self.offset_tension_ch1 = offset_real
            else:
                self.offset_tension_ch2 = offset_real
            self._sincronizar_entry_offset_tension()
            self.actualizar_grafica()
        finally:
            self._actualizando_slider = False

    def actualizar_slider_offset(self):
        """
        Sincroniza la posición del slider con el valor real de offset de tensión
        solo si el canal está visible.
        """
        if self._actualizando_slider:  # Evita recursión
            return
        canal = self.canal_offset.get()
        # Si el canal está oculto, ponemos slider en cero y no hacemos nada
        if (canal == 1 and not self.mostrar_ch1.get()) or (canal == 2 and not self.mostrar_ch2.get()):
            self.scl_tension_offset.set(0)
            return
        self._actualizando_slider = True
        try:
            # Convertierte el offset real a divisiones
            if canal == 1:
                volt_div_str = self.volt_div_vars[0].get() if len(self.volt_div_vars) > 0 else "1 V/div"
                factor = dict(self.voltajes_por_div).get(volt_div_str, 1)
                self.scl_tension_offset.set(self.offset_tension_ch1 / factor if factor else 0)
            else:
                volt_div_str = self.volt_div_vars[1].get() if len(self.volt_div_vars) > 1 else "1 V/div"
                factor = dict(self.voltajes_por_div).get(volt_div_str, 1)
                self.scl_tension_offset.set(self.offset_tension_ch2 / factor if factor else 0)
        finally:
            self._actualizando_slider = False
            self.update_voltage_offset_range()
            self._sincronizar_entry_offset_tension()

    def reset_offset_volt(self):
        """Restablece los offsets de tensión de ambos canales a cero."""
        self.scl_tension_offset.set(0) # Reinicia el slider visualmente
        self.offset_tension_ch1 = 0.0
        self.offset_tension_ch2 = 0.0
        self._sincronizar_entry_offset_tension()
        self.actualizar_grafica()

    def _sincronizar_entry_offset_tension(self):
        """Refleja el offset de tensión del canal seleccionado en la caja numérica, expresado en la unidad elegida en su combobox."""
        if not hasattr(self, 'var_voffset_num'):
            return
        canal = self.canal_offset.get()
        valor_v = self.offset_tension_ch1 if canal == 1 else self.offset_tension_ch2
        factor = self._UNIDADES_VOLTAJE.get(self.var_voffset_unidad.get(), 1.0)
        self.var_voffset_num.set(f"{valor_v / factor:.4g}" if factor else "0")

    def aplicar_offset_tension_manual(self, event=None):
        """
        Aplica el offset de tensión escrito a mano (valor numérico + unidad
        del combobox de al lado) al canal actualmente seleccionado (Ch1/Ch2,
        radio buttons de "Voltage Offset Ch"), sin la limitación del rango
        del slider: si hace falta, el rango del slider se agranda solo.
        """
        if self.df is None:
            return
        try:
            valor = float(str(self.var_voffset_num.get()).strip().replace(',', '.'))
        except (ValueError, tk.TclError):
            return  # el usuario todavía está escribiendo / valor inválido: no hacemos nada

        factor = self._UNIDADES_VOLTAJE.get(self.var_voffset_unidad.get(), 1.0)
        offset_real = valor * factor

        canal = self.canal_offset.get()
        if canal == 1:
            self.offset_tension_ch1 = offset_real
        else:
            self.offset_tension_ch2 = offset_real

        # Agranda el rango del slider ANTES de reposicionarlo (ver el fix en
        # update_voltage_offset_range: ya no achica el rango por debajo del
        # offset actualmente aplicado), para que no recorte este valor.
        self.update_voltage_offset_range()
        self.actualizar_slider_offset()
        self.actualizar_grafica()

    def ajustar_escala_tiempo(self):
        """
        Ajusta el combobox de tiempo/div para que muestre una escala
        apropiada para la duración total de los datos.
        """
        if self.df is None:
            return

        t_min_data = self.df.iloc[:, 0].min()
        t_max_data = self.df.iloc[:, 0].max()
        duracion_total = t_max_data - t_min_data

        # Si el rango de tiempo es 0 (ej. un solo punto o datos inválidos)
        if duracion_total == 0:
            self.var_tiempo_div.set(self.tiempos_por_div[self._indice_mas_cercano(self.tiempos_por_div, 1e-3)][0]) # Default a 1ms/div
            self.var_offset_tiempo.set(0.0)
            self.offset_divisiones = 0.0
            self.scl_toffset.config(from_=-SCREEN_DIVISIONS_X, to=SCREEN_DIVISIONS_X)
            self._sincronizar_entry_offset_tiempo()
            return

        # Calcula el tiempo por división necesario para mostrar toda la duración en 10 divisiones
        # Usamos 8 divisiones para que la señal no ocupe todo el ancho
        tiempo_por_div_necesario = duracion_total / (SCREEN_DIVISIONS_X * 0.8) # Deja un poco de margen

        # Encuentra la mejor escala de tiempo por división
        best_match_idx = 0
        min_diff = float('inf')
        for i, (label, val) in enumerate(self.tiempos_por_div):
            diff = abs(val - tiempo_por_div_necesario)
            if diff < min_diff:
                min_diff = diff
                best_match_idx = i

        self.var_tiempo_div.set(self.tiempos_por_div[best_match_idx][0])
        tiempo_div_segs_elegido = self.tiempos_por_div[best_match_idx][1]

        # --- FIX: rango del slider de offset de tiempo ---
        # Debe permitir recorrer (pan) toda la duración de la señal, además de
        # poder llevarla completamente fuera de pantalla en cualquier dirección.
        duracion_en_divisiones = duracion_total / tiempo_div_segs_elegido if tiempo_div_segs_elegido else 0
        margen = max(duracion_en_divisiones, SCREEN_DIVISIONS_X) + SCREEN_DIVISIONS_X
        self.scl_toffset.config(from_=-margen, to=margen)

        # --- FIX: offset por defecto para centrar toda la señal en pantalla ---
        # (con offset=0 el t=0 de la señal queda en el centro de la pantalla,
        # igual que la referencia de disparo/trigger de un osciloscopio real)
        offset_defecto = -(duracion_en_divisiones / 2.0)
        self.var_offset_tiempo.set(offset_defecto)
        self.offset_divisiones = offset_defecto
        self._sincronizar_entry_offset_tiempo()

    def ajustar_unidades_tiempo(self, tiempo_s):
        """Ajusta la escala y unidad de tiempo para visualización (ns, us, ms, s)."""
        max_abs = np.max(np.abs(tiempo_s))
        if max_abs < 1e-8: # Si los valores son extremadamente pequeños, usar ns
            return tiempo_s * 1e9, "ns"
        elif max_abs < 1e-5: # < 10 us
            return tiempo_s * 1e6, "µs"
        elif max_abs < 1e-2: # < 10 ms
            return tiempo_s * 1e3, "ms"
        else:
            return tiempo_s, "s"

    def ajustar_unidades_valor(self, valores):
        """Ajusta la escala y unidad de valor para visualización (µV, mV, V)."""
        max_abs = np.max(np.abs(valores))
        if max_abs < 1e-4: # < 100 µV
            return valores * 1e6, "µV"
        elif max_abs < 1: # < 1 V
            return valores * 1e3, "mV"
        else:
            return valores, "V"

    def _dibujar_offset_tension_en_grafica(self):
        """
        Muestra, como bloque de texto arrastrable sobre la propia gráfica
        V(t) (mismo mecanismo que los bloques de mediciones por canal), el
        offset de tensión aplicado a cada canal visible.

        Solo se dibuja si el checkbox "Voltage offset" (panel "Show on
        Graph", al costado de "Channels & Measurements") está tildado. Se
        puede arrastrar con el mouse a cualquier posición.
        """
        if not getattr(self, 'var_mostrar_offset_tension', None) or not self.var_mostrar_offset_tension.get():
            return
        if self.df is None or self.is_bode:
            return

        lineas = ['Voltage Offset']
        if self.mostrar_ch1.get():
            lineas.append(f"Ch1: {self._fmt_medida_v(self.offset_tension_ch1)}")
        if self.mostrar_ch2.get():
            lineas.append(f"Ch2: {self._fmt_medida_v(self.offset_tension_ch2)}")

        if len(lineas) <= 1:
            return  # ningún canal visible

        texto_bloque = "\n".join(lineas)

        if 'voffset' in self._medicion_pos:
            x_pos, y_pos = self._medicion_pos['voffset']
        else:
            x_pos, y_pos = 0.70, 0.60  # a media altura, lado derecho, por defecto

        artista = self.ax.text(
            x_pos, y_pos, texto_bloque,
            transform=self.ax.transAxes,
            fontsize=7.5, color=self.current_colors["fg"], va='top', ha='left',
            family='monospace', zorder=6, picker=True,
            bbox=dict(boxstyle='round,pad=0.3', facecolor=self.current_colors["plot_bg"],
                      edgecolor=self.current_colors["fg"], linewidth=0.8, alpha=0.85)
        )
        self._medicion_text_artists['voffset'] = artista

    def update_voltage_offset_range(self):
        """
        Ajusta el rango del slider de offset de tensión para que la onda completa
        quepa en pantalla (± mitad del rango global de Y / Volt/div).

        El rango nunca se achica por debajo de lo necesario para representar
        el offset ACTUALMENTE aplicado al canal seleccionado: si se cargó un
        valor grande con la caja numérica (offset manual), el slider tiene
        que poder mostrarlo, no recortarlo en el próximo redibujado.
        """
        # Necesitamos un rango global válido
        if self.df is None or self.ymin_global is None or self.ymax_global is None:
            return

        total_range = self.ymax_global - self.ymin_global
        if total_range <= 0:
            return

        # Canal seleccionado para offset (0-index)
        ch = self.canal_offset.get() - 1
        if 0 <= ch < len(self.volt_div_vars):
            # factor volt/div
            vd_str = self.volt_div_vars[ch].get()
            vd_val = dict(self.voltajes_por_div).get(vd_str, 1)
            if vd_val <= 0:
                return
            # cuántas divisiones necesitamos para cubrir ± half_range
            half_divs = (total_range / vd_val) / 2
            # ...pero como mínimo, las que hagan falta para el offset ya aplicado
            offset_actual = self.offset_tension_ch1 if ch == 0 else self.offset_tension_ch2
            divs_offset_actual = abs(offset_actual / vd_val)
            half_divs = max(half_divs, divs_offset_actual * 1.05)
            # reconfiguramos el slider
            self.scl_tension_offset.config(from_=-half_divs, to=half_divs)


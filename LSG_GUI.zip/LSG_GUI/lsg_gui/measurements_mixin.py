"""
Mediciones automaticas por canal (Max, Min, Pk-Pk, Mean, RMS, Freq,
Period) y su dibujado superpuesto sobre la grafica V(t).

Estos metodos se mezclan (mixin) dentro de TC1ScopeApp en gui_app.py.
"""
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, colorchooser
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import re
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.collections import LineCollection
from .constants import *  # noqa: F401,F403 (colores y dimensiones de pantalla)


class MeasurementsMixin:
    def calcular_mediciones_canal(self, canal_idx):
        """
        Calcula las mediciones automáticas típicas de un osciloscopio (Max, Min,
        Pk-Pk, Mean, RMS, Frequency, Period) para el canal dado (0-based),
        usando TODA la señal cargada (no solo la ventana visible en pantalla).
        Devuelve un dict; los valores que no se puedan calcular (p. ej. la
        frecuencia de una señal no periódica) quedan en None.
        """
        resultado = {'max': None, 'min': None, 'pkpk': None, 'mean': None,
                     'rms': None, 'freq': None, 'period': None}
        if self.df is None or self.is_bode:
            return resultado
        if canal_idx < 0 or canal_idx + 1 >= self.df.shape[1]:
            return resultado

        tiempo = self.df.iloc[:, 0].values.astype(float)
        valores = self.df.iloc[:, canal_idx + 1].values.astype(float)
        if len(valores) == 0:
            return resultado

        v_max = float(np.max(valores))
        v_min = float(np.min(valores))
        resultado['max'] = v_max
        resultado['min'] = v_min
        resultado['pkpk'] = v_max - v_min
        resultado['mean'] = float(np.mean(valores))
        resultado['rms'] = float(np.sqrt(np.mean(np.square(valores))))

        # --- Estimación de Frecuencia / Período por cruces ascendentes por cero ---
        try:
            señal_centrada = valores - resultado['mean']
            cruces = np.where((señal_centrada[:-1] <= 0) & (señal_centrada[1:] > 0))[0]
            if len(cruces) >= 2:
                t_cruces = []
                for i in cruces:
                    y0, y1 = señal_centrada[i], señal_centrada[i + 1]
                    t0, t1 = tiempo[i], tiempo[i + 1]
                    if y1 != y0:
                        frac = -y0 / (y1 - y0)
                        t_cruces.append(t0 + frac * (t1 - t0))
                if len(t_cruces) >= 2:
                    periodo_medio = float(np.mean(np.diff(t_cruces)))
                    if periodo_medio > 0:
                        resultado['period'] = periodo_medio
                        resultado['freq'] = 1.0 / periodo_medio
        except Exception:
            pass

        return resultado

    def _fmt_medida_v(self, valor):
        """Formatea un valor en volts con la unidad más adecuada (µV/mV/V)."""
        if valor is None:
            return "—"
        escalado, unidad = self.ajustar_unidades_valor(np.array([valor], dtype=float))
        return f"{escalado[0]:.4g} {unidad}"

    def _fmt_medida_t(self, valor):
        """Formatea un valor de tiempo con la unidad más adecuada (ns/µs/ms/s)."""
        if valor is None:
            return "—"
        escalado, unidad = self.ajustar_unidades_tiempo(np.array([valor], dtype=float))
        return f"{escalado[0]:.4g} {unidad}"

    def _fmt_medida_freq(self, valor):
        """Formatea una frecuencia con la unidad más adecuada (Hz/kHz/MHz)."""
        if valor is None:
            return "—"
        abs_v = abs(valor)
        if abs_v >= 1e6:
            return f"{valor / 1e6:.4g} MHz"
        elif abs_v >= 1e3:
            return f"{valor / 1e3:.4g} kHz"
        else:
            return f"{valor:.4g} Hz"

    def actualizar_mediciones(self):
        """Recalcula y muestra en cada bloque de canal sus mediciones automáticas."""
        if not hasattr(self, 'measurement_vars'):
            return
        for i, stats_vars in enumerate(self.measurement_vars):
            medidas = self.calcular_mediciones_canal(i)
            stats_vars['max'].set(self._fmt_medida_v(medidas['max']))
            stats_vars['min'].set(self._fmt_medida_v(medidas['min']))
            stats_vars['pkpk'].set(self._fmt_medida_v(medidas['pkpk']))
            stats_vars['mean'].set(self._fmt_medida_v(medidas['mean']))
            stats_vars['rms'].set(self._fmt_medida_v(medidas['rms']))
            stats_vars['freq'].set(self._fmt_medida_freq(medidas['freq']))
            stats_vars['period'].set(self._fmt_medida_t(medidas['period']))

    def resetear_posicion_mediciones(self):
        """Vuelve los bloques de mediciones superpuestos en la gráfica V(t) a su posición por defecto (2 columnas: Ch1 izquierda, Ch2 derecha)."""
        self._medicion_pos = {}
        self.actualizar_grafica()

    def _dibujar_medidas_en_grafica(self):
        """
        Dibuja, como texto sobre la propia gráfica V(t), las mediciones
        automáticas que el usuario haya marcado con el checkbox correspondiente
        en el panel "Channels & Measurements". Las mediciones de cada canal se
        agrupan en UN solo bloque (una columna por canal: Ch1 a la izquierda,
        Ch2 a la derecha, y así sucesivamente si hay más canales), en vez de
        una lista mezclada — así queda prolijo también al exportar a PDF.

        Cada bloque se puede arrastrar con el mouse (ver on_press/on_motion/
        on_release) a cualquier posición dentro de la gráfica; la posición
        elegida se recuerda entre redibujados hasta que se resetea con el
        botón "Reset Measurement Pos.".
        """
        self._medicion_text_artists = {}

        if not getattr(self, 'measurement_show_vars', None):
            return

        etiquetas_stats = [
            ('max', 'Max'), ('min', 'Min'), ('pkpk', 'Pk-Pk'), ('mean', 'Mean'),
            ('rms', 'RMS'), ('freq', 'Freq'), ('period', 'Period')
        ]

        for i, show_vars in enumerate(self.measurement_show_vars):
            # Solo canales visibles (mismo criterio que al graficar la curva)
            if i == 0 and not self.mostrar_ch1.get():
                continue
            if i == 1 and not self.mostrar_ch2.get():
                continue
            if not any(var.get() for var in show_vars.values()):
                continue

            medidas = self.calcular_mediciones_canal(i)
            etiqueta = self.channel_label_vars[i].get().strip() if i < len(self.channel_label_vars) else ""
            if not etiqueta:
                etiqueta = f"CH{i + 1}"
            color = self._color_actual_canal(i)

            lineas_canal = [etiqueta]
            for clave, texto_stat in etiquetas_stats:
                if not show_vars.get(clave) or not show_vars[clave].get():
                    continue
                valor = medidas.get(clave)
                if clave == 'freq':
                    texto_val = self._fmt_medida_freq(valor)
                elif clave == 'period':
                    texto_val = self._fmt_medida_t(valor)
                else:
                    texto_val = self._fmt_medida_v(valor)
                lineas_canal.append(f"{texto_stat}: {texto_val}")

            if len(lineas_canal) <= 1:
                continue  # este canal no tiene ninguna medición tildada

            texto_bloque = "\n".join(lineas_canal)

            # Posición: la que el usuario haya arrastrado a mano, o la
            # posición por defecto en 2 columnas (canales pares a la
            # izquierda, impares a la derecha; baja de fila cada 2 canales).
            if i in self._medicion_pos:
                x_pos, y_pos = self._medicion_pos[i]
            else:
                col = i % 2
                fila = i // 2
                x_pos = 0.015 + col * 0.35
                y_pos = 0.985 - fila * 0.34

            artista = self.ax.text(
                x_pos, y_pos, texto_bloque,
                transform=self.ax.transAxes,
                fontsize=7.5, color=color, va='top', ha='left',
                family='monospace', zorder=6, picker=True,
                bbox=dict(boxstyle='round,pad=0.3', facecolor=self.current_colors["plot_bg"],
                          edgecolor=color, linewidth=0.8, alpha=0.85)
            )
            self._medicion_text_artists[i] = artista


"""
Logica de los 4 cursores (X1, X2, Y1, Y2): posicionamiento, tracking
sobre una señal, arrastre con el mouse y calculo de deltas.

Estos metodos se mezclan (mixin) dentro de TC1ScopeApp en gui_app.py.
"""
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, colorchooser
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import re
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.collections import LineCollection
from .constants import *  # noqa: F401,F403 (colores y dimensiones de pantalla)


class CursorsMixin:
    def obtener_posiciones_relativas(self):
        """
        Calcula las posiciones relativas (0 a 1) de los cursores
        dentro de los límites actuales del gráfico.
        """
        posiciones = {}
        # Solo si todos los cursores están instanciados
        if not all([self.cursor_x1, self.cursor_x2, self.cursor_y1, self.cursor_y2]):
            return None

        x_min, x_max = self.ax.get_xlim()
        y_min, y_max = self.ax.get_ylim()

        if (x_max - x_min) == 0 or (y_max - y_min) == 0:
            return None

        try:
            posiciones['x1'] = (self.cursor_x1.get_xdata()[0] - x_min) / (x_max - x_min)
            posiciones['x2'] = (self.cursor_x2.get_xdata()[0] - x_min) / (x_max - x_min)
            posiciones['y1'] = (self.cursor_y1.get_ydata()[0] - y_min) / (y_max - y_min)
            posiciones['y2'] = (self.cursor_y2.get_ydata()[0] - y_min) / (y_max - y_min)
            return posiciones
        except Exception:
            return None

    def _valor_interpolado_canal(self, canal_idx, x_screen):
        """
        Interpola el valor (en divisiones de pantalla del canal) de la señal
        graficada en la posición x_screen (coordenadas de pantalla/divisiones).
        Devuelve None si no hay datos visibles de ese canal.
        """
        datos = self._canal_visible_data.get(canal_idx)
        if not datos:
            return None
        tiempo_screen, datos_div, _ = datos
        if len(tiempo_screen) < 2:
            return None
        orden = np.argsort(tiempo_screen)
        return float(np.interp(x_screen, tiempo_screen[orden], datos_div[orden]))

    def _actualizar_tracking_cursores(self):
        """
        Modo 'Track': reubica Y1 y/o Y2 automáticamente sobre la curva del
        canal elegido para CADA cursor, en la posición X actual del cursor
        correspondiente (X1 para Y1, X2 para Y2) — igual que el modo de
        cursores de seguimiento ('tracking cursors') de un osciloscopio real.
        El tracking de Y1 y de Y2 es completamente independiente: se puede
        dejar uno de los dos sin marcar para usarlo como referencia manual
        fija (x0, y0) mientras el otro sigue una señal.
        """
        if not all([self.cursor_x1, self.cursor_x2, self.cursor_y1, self.cursor_y2]):
            return

        x1 = self.cursor_x1.get_xdata()[0]
        x2 = self.cursor_x2.get_xdata()[0]

        # --- Y1 (sigue a X1) ---
        if self.var_cursor_track_y1.get():
            canal_idx1 = self.canal_track_y1.get() - 1
            y1 = self._valor_interpolado_canal(canal_idx1, x1)
            if y1 is not None:
                self.cursor_y1.set_ydata([y1, y1])
                self._dibujar_marcador_cursor(1, x1, y1, canal_idx1)
        else:
            self._quitar_marcador_cursor(1)

        # --- Y2 (sigue a X2), independiente de Y1 ---
        if self.var_cursor_track_y2.get():
            canal_idx2 = self.canal_track_y2.get() - 1
            y2 = self._valor_interpolado_canal(canal_idx2, x2)
            if y2 is not None:
                self.cursor_y2.set_ydata([y2, y2])
                self._dibujar_marcador_cursor(2, x2, y2, canal_idx2)
        else:
            self._quitar_marcador_cursor(2)

    def _dibujar_marcador_cursor(self, indice, x, y, canal_idx):
        """
        Crea o reubica el punto marcador (círculo) del cursor Y1 (indice=1) o
        Y2 (indice=2) exactamente en (x, y), SIN recalcular nada. Se usa tanto
        desde el tracking automático (que sí recalcula y luego llama a esto)
        como para restaurar un marcador tal cual estaba, sin re-trackearlo
        (p. ej. al mover un offset, para que el cursor no "salte").
        """
        color_marca = self._color_actual_canal(canal_idx) if canal_idx is not None and canal_idx >= 0 else self.current_colors["cursor_y"]
        attr = 'cursor_marker1' if indice == 1 else 'cursor_marker2'
        marcador = getattr(self, attr)
        if marcador is not None and marcador in self.ax.lines:
            marcador.set_data([x], [y])
        else:
            marcador, = self.ax.plot(
                [x], [y], marker='o', markersize=6, linestyle='None',
                markerfacecolor=color_marca, markeredgecolor=self.current_colors["fg"], zorder=5
            )
            setattr(self, attr, marcador)

    def _quitar_marcador_cursor(self, indice):
        """Elimina el marcador visual de tracking (círculo) del cursor Y1 (1) o Y2 (2), si existe."""
        attr = 'cursor_marker1' if indice == 1 else 'cursor_marker2'
        marcador = getattr(self, attr)
        if marcador is not None:
            try:
                if marcador in self.ax.lines:
                    self.ax.lines.remove(marcador)
            except Exception:
                pass
            setattr(self, attr, None)

    def crear_cursores(self, posiciones=None):
        """
        Crea o actualiza los cursores X e Y.
        Si 'posiciones' es None, los inicializa en el centro de la vista actual.
        """
        x_min, x_max = self.ax.get_xlim()
        y_min, y_max = self.ax.get_ylim()

        # Eliminar cursores existentes antes de crear nuevos
        for cursor_attr in ['cursor_x1', 'cursor_x2', 'cursor_y1', 'cursor_y2']:
            cursor = getattr(self, cursor_attr)
            if cursor:
                try:
                    if cursor in self.ax.lines:
                        self.ax.lines.remove(cursor)
                except Exception as e:
                    print(f"Error al intentar eliminar cursor {cursor_attr}: {e}")
                setattr(self, cursor_attr, None)


        # Posiciones predeterminadas si no se especifican
        if posiciones is None:
            pos_x1 = x_min + (x_max - x_min) * 0.25
            pos_x2 = x_min + (x_max - x_min) * 0.75
            pos_y1 = y_min + (y_max - y_min) * 0.25
            pos_y2 = y_min + (y_max - y_min) * 0.75
        else:
            # Usa posiciones guardadas, asegurándose de que estén dentro de los límites
            dx_range = (x_max - x_min)
            dy_range = (y_max - y_min)
            
            pos_x1 = x_min + max(0, min(1, posiciones.get('x1', 0.25))) * dx_range
            pos_x2 = x_min + max(0, min(1, posiciones.get('x2', 0.75))) * dx_range
            pos_y1 = y_min + max(0, min(1, posiciones.get('y1', 0.25))) * dy_range
            pos_y2 = y_min + max(0, min(1, posiciones.get('y2', 0.75))) * dy_range

        self.cursor_x1 = self.ax.axvline(pos_x1, color=self.current_colors["cursor_x"], linestyle='--', picker=5)
        self.cursor_x2 = self.ax.axvline(pos_x2, color=self.current_colors["cursor_x"], linestyle='--', picker=5)
        self.cursor_y1 = self.ax.axhline(pos_y1, color=self.current_colors["cursor_y"], linestyle='--', picker=5)
        self.cursor_y2 = self.ax.axhline(pos_y2, color=self.current_colors["cursor_y"], linestyle='--', picker=5)

        self._actualizar_tracking_cursores()
        self._actualizar_etiquetas_cursores()
        self.canvas.draw_idle()

    def _actualizar_etiquetas_cursores(self):
        """
        Crea o reposiciona las pequeñas etiquetas "X1"/"X2"/"Y1"/"Y2" pegadas
        a cada línea de cursor, para poder identificarlas de un vistazo sin
        tener que leer las coordenadas. Se llama cada vez que los cursores
        se (re)crean y también durante el arrastre (on_motion), para que la
        etiqueta acompañe a la línea en tiempo real.
        """
        if not hasattr(self, '_cursor_label_artists'):
            self._cursor_label_artists = {}

        if not all([self.cursor_x1, self.cursor_x2, self.cursor_y1, self.cursor_y2]):
            for artista in self._cursor_label_artists.values():
                try:
                    if artista in self.ax.texts:
                        artista.remove()
                except Exception:
                    pass
            self._cursor_label_artists = {}
            return

        x_half = SCREEN_DIVISIONS_X / 2.0
        y_half = SCREEN_DIVISIONS_Y / 2.0

        info = {
            'x1': (self.cursor_x1.get_xdata()[0], y_half - 0.3, self.current_colors['cursor_x'], 'X1', 'center', 'top'),
            'x2': (self.cursor_x2.get_xdata()[0], y_half - 0.3, self.current_colors['cursor_x'], 'X2', 'center', 'top'),
            'y1': (-x_half + 0.15, self.cursor_y1.get_ydata()[0], self.current_colors['cursor_y'], 'Y1', 'left', 'center'),
            'y2': (-x_half + 0.15, self.cursor_y2.get_ydata()[0], self.current_colors['cursor_y'], 'Y2', 'left', 'center'),
        }

        for clave, (xp, yp, color, texto, ha, va) in info.items():
            artista = self._cursor_label_artists.get(clave)
            if artista is not None and artista in self.ax.texts:
                artista.set_position((xp, yp))
            else:
                artista = self.ax.text(
                    xp, yp, texto, color=color, fontsize=8, fontweight='bold',
                    ha=ha, va=va, zorder=7,
                    bbox=dict(boxstyle='round,pad=0.15', facecolor=self.current_colors['plot_bg'],
                              edgecolor='none', alpha=0.75)
                )
                self._cursor_label_artists[clave] = artista

    def _medicion_en_posicion(self, event):
        """Devuelve el índice de canal cuyo bloque de mediciones fue clickeado (según bbox), o None."""
        for idx, artista in getattr(self, '_medicion_text_artists', {}).items():
            try:
                contains, _ = artista.contains(event)
            except Exception:
                contains = False
            if contains:
                return idx
        return None

    def on_press(self, event):
        """
        Maneja el evento de presionar el botón del mouse. Primero chequea si
        se clickeó un bloque de mediciones sobre la gráfica (para arrastrarlo
        libremente, funciona siempre, esté o no activo "Use cursors"); si no,
        procede con la selección de cursores (solo si "Use cursors" está
        activo).
        """
        if event.inaxes != self.ax:
            return

        idx_medicion = self._medicion_en_posicion(event)
        if idx_medicion is not None:
            self._dragging_medicion_idx = idx_medicion
            self.canvas.mpl_disconnect('motion_notify_event')
            self.canvas.mpl_connect('motion_notify_event', self.on_motion)
            return

        if not self.var_cursores.get():
            return

        # Iterar sobre los cursores para ver cuál fue seleccionado
        for cursor_name, cursor_obj in [('cursor_x1', self.cursor_x1), ('cursor_x2', self.cursor_x2),
                                         ('cursor_y1', self.cursor_y1), ('cursor_y2', self.cursor_y2)]:
            # Con el tracking activo para ESE cursor puntual, Y1 o Y2 sigue la
            # señal automáticamente y no se puede arrastrar a mano.
            if cursor_name == 'cursor_y1' and self.var_cursor_track_y1.get():
                continue
            if cursor_name == 'cursor_y2' and self.var_cursor_track_y2.get():
                continue
            if cursor_obj is not None:
                contains, _ = cursor_obj.contains(event)
                if contains:
                    self.selected_cursor = cursor_obj
                    self._selected_cursor_name = cursor_name
                    # Guarda la posición inicial de los 4 cursores, para el modo "Move cursors together"
                    self._drag_inicio = {
                        'x1': self.cursor_x1.get_xdata()[0] if self.cursor_x1 is not None else None,
                        'x2': self.cursor_x2.get_xdata()[0] if self.cursor_x2 is not None else None,
                        'y1': self.cursor_y1.get_ydata()[0] if self.cursor_y1 is not None else None,
                        'y2': self.cursor_y2.get_ydata()[0] if self.cursor_y2 is not None else None,
                    }
                    self.canvas.mpl_disconnect('motion_notify_event') # Desconecta temporalmente para evitar que se mueva durante on_press
                    self.canvas.mpl_connect('motion_notify_event', self.on_motion) # Reconecta para mover
                    break

    def on_release(self, event):
        """Maneja el evento de soltar el botón del mouse."""
        if getattr(self, '_dragging_medicion_idx', None) is not None:
            self._dragging_medicion_idx = None
            return

        if not self.var_cursores.get():
            return
        self.selected_cursor = None # Desselecciona el cursor
        self._selected_cursor_name = None
        self._drag_inicio = None
        self.actualizar_deltas_cursores() # Recalcular deltas al soltar el cursor

    def on_motion(self, event):
        """
        Maneja el evento de mover el mouse para arrastrar un cursor o un
        bloque de mediciones. Si "Move cursors together" está activo,
        arrastrar X1 (o Y1) mueve también X2 (o Y2) preservando la distancia
        entre ambos — igual que mover el par de cursores de un osciloscopio
        real.
        """
        if getattr(self, '_dragging_medicion_idx', None) is not None:
            idx = self._dragging_medicion_idx
            artista = self._medicion_text_artists.get(idx)
            if artista is not None and event.x is not None and event.y is not None:
                try:
                    x_frac, y_frac = self.ax.transAxes.inverted().transform((event.x, event.y))
                    x_frac = min(max(x_frac, 0.0), 1.0)
                    y_frac = min(max(y_frac, 0.0), 1.0)
                    artista.set_position((x_frac, y_frac))
                    self._medicion_pos[idx] = (x_frac, y_frac)
                    self.canvas.draw_idle()
                except Exception:
                    pass
            return

        if not self.var_cursores.get() or self.selected_cursor is None or event.inaxes != self.ax:
            return

        clave = (self._selected_cursor_name or '').replace('cursor_', '')  # 'x1' / 'x2' / 'y1' / 'y2'
        link = self.var_cursor_link.get()
        inicio = self._drag_inicio

        if clave in ('x1', 'x2') and event.xdata is not None:
            self.selected_cursor.set_xdata([event.xdata, event.xdata])
            if link and inicio is not None and inicio.get(clave) is not None:
                clave_par = 'x2' if clave == 'x1' else 'x1'
                cursor_par = self.cursor_x2 if clave == 'x1' else self.cursor_x1
                if cursor_par is not None and inicio.get(clave_par) is not None:
                    delta = event.xdata - inicio[clave]
                    nueva_pos = inicio[clave_par] + delta
                    cursor_par.set_xdata([nueva_pos, nueva_pos])
            self._actualizar_tracking_cursores()

        elif clave in ('y1', 'y2') and event.ydata is not None:
            self.selected_cursor.set_ydata([event.ydata, event.ydata])
            if link and inicio is not None and inicio.get(clave) is not None:
                clave_par = 'y2' if clave == 'y1' else 'y1'
                cursor_par = self.cursor_y2 if clave == 'y1' else self.cursor_y1
                if cursor_par is not None and inicio.get(clave_par) is not None:
                    delta = event.ydata - inicio[clave]
                    nueva_pos = inicio[clave_par] + delta
                    cursor_par.set_ydata([nueva_pos, nueva_pos])

        self._actualizar_etiquetas_cursores()  # la etiqueta X1/X2/Y1/Y2 acompaña a la línea
        self._actualizar_texto_coords_cursores_en_vivo()  # coordenadas en tiempo real, si están visibles
        self.canvas.draw_idle() # Actualiza solo el área afectada

    def calcular_deltas(self):
        pass

    def actualizar_deltas_cursores(self):
        """Calcula y muestra las posiciones absolutas (X1,X2,Y1,Y2) y los deltas (ΔX, ΔY) de los cursores."""
        # Si el tracking está activo, recalcula Y1/Y2 antes de medir (por si
        # se cambió el canal de referencia sin mover los cursores X).
        self._actualizar_tracking_cursores()

        if not all([self.cursor_x1, self.cursor_x2, self.cursor_y1, self.cursor_y2]):
            self.actualizar_label_deltas(0, 0, show_channel=False) # No hay cursores, resetear
            if hasattr(self, 'label_cursor_pos'):
                self.label_cursor_pos.config(text="X1 = —   X2 = —   Y1 = —   Y2 = —")
            return

        try:
            # Posiciones de los cursores en coordenadas de PANTALLA (divisiones)
            x1_div = self.cursor_x1.get_xdata()[0]
            x2_div = self.cursor_x2.get_xdata()[0]
            y1_div = self.cursor_y1.get_ydata()[0]
            y2_div = self.cursor_y2.get_ydata()[0]

            unidad_t, _ = self.obtener_unidad_tiempo_actual()
            x1_real = self._tiempo_real_desde_div(x1_div)
            x2_real = self._tiempo_real_desde_div(x2_div)

            # Cada cursor Y se interpreta con SU PROPIO canal de referencia
            # (el elegido en "Track Y1 on:" / "Track Y2 on:"), esté o no el
            # tracking activo para ese cursor — así un cursor fijo también se
            # puede leer en volts reales de un canal (ej. como referencia y0).
            canal_idx1 = self.canal_track_y1.get() - 1
            canal_idx2 = self.canal_track_y2.get() - 1
            y1_real = self._valor_real_desde_div(y1_div, canal_idx1)
            y2_real = self._valor_real_desde_div(y2_div, canal_idx2)

            # --- Posiciones absolutas de cada cursor ---
            texto_x1 = self.formatear_valor(x1_real, unidad_t)
            texto_x2 = self.formatear_valor(x2_real, unidad_t)
            texto_y1 = f"{self.formatear_valor(y1_real, 'V')} (Ch{canal_idx1 + 1})"
            texto_y2 = f"{self.formatear_valor(y2_real, 'V')} (Ch{canal_idx2 + 1})"
            if hasattr(self, 'label_cursor_pos'):
                self.label_cursor_pos.config(
                    text=f"X1 = {texto_x1}   X2 = {texto_x2}   Y1 = {texto_y1}   Y2 = {texto_y2}"
                )

            # --- Deltas ---
            delta_x_mostrado = abs(x2_real - x1_real)
            delta_y_real = abs(y2_real - y1_real)

            if canal_idx1 == canal_idx2:
                self.actualizar_label_deltas(delta_x_mostrado, delta_y_real, channel_num=canal_idx1 + 1)
            else:
                # Y1 e Y2 están referenciados a canales distintos: el delta
                # sigue siendo válido en volts reales, pero no se le asigna
                # un único "canal" ya que mezcla ambas escalas.
                self.actualizar_label_deltas(delta_x_mostrado, delta_y_real, show_channel=False)

        except Exception:
            self.actualizar_label_deltas(0, 0, show_channel=False)
            if hasattr(self, 'label_cursor_pos'):
                self.label_cursor_pos.config(text="X1 = —   X2 = —   Y1 = —   Y2 = —")

        if hasattr(self, 'canvas'):
            self.canvas.draw_idle()

    def formatear_valor(self, valor, unidad_referencia):
        """Formatea un valor numérico a una cadena con la unidad adecuada."""
        if unidad_referencia == "ns":
            return f"{valor:.3g} ns"
        elif unidad_referencia == "µs":
            return f"{valor:.3g} µs"
        elif unidad_referencia == "ms":
            return f"{valor:.3g} ms"
        elif unidad_referencia == "s":
            return f"{valor:.3g} s"
        elif unidad_referencia == "mV":
            return f"{valor:.3g} mV"
        elif unidad_referencia == "µV":
            return f"{valor:.3g} µV"
        elif unidad_referencia == "V":
            return f"{valor:.3g} V"
        else:
            return f"{valor:.3g} {unidad_referencia}"

    def actualizar_label_deltas(self, dx, dy, channel_num=None, show_channel=True):
        """Actualiza la etiqueta que muestra los deltas de los cursores."""
        texto_dx = self.formatear_valor(dx, self.unidad_tiempo)
        texto_dy = self.formatear_valor(dy, "V") # Mostrar siempre en V para los deltas reales

        if show_channel and channel_num is not None:
            self.label_deltas.config(text=f"ΔX = {texto_dx}, ΔY = {texto_dy} (Canal {channel_num})")
        else:
            self.label_deltas.config(text=f"ΔX = {texto_dx}, ΔY = {texto_dy}")

    def obtener_posiciones_absolutas(self):
        """
        Captura las posiciones actuales de los cursores en coordenadas de datos.
        """
        if not all([self.cursor_x1, self.cursor_x2, self.cursor_y1, self.cursor_y2]):
            return None
        try:
            return {
                'x1': self.cursor_x1.get_xdata()[0],
                'x2': self.cursor_x2.get_xdata()[0],
                'y1': self.cursor_y1.get_ydata()[0],
                'y2': self.cursor_y2.get_ydata()[0]
            }
        except Exception:
            return None

    def _texto_bloque_coords_cursores(self):
        """
        Arma el texto del bloque de coordenadas de cursores, recalculando
        antes las etiquetas de la barra superior (X1=..., ΔX=...) para
        reusar exactamente el mismo texto ya formateado en ambos lugares.
        """
        self.actualizar_deltas_cursores()
        texto_pos = self.label_cursor_pos.cget('text') if hasattr(self, 'label_cursor_pos') else ''
        texto_delta = self.label_deltas.cget('text') if hasattr(self, 'label_deltas') else ''
        lineas = ['Cursors'] + texto_pos.split('   ') + [texto_delta]
        return "\n".join(linea for linea in lineas if linea)

    def _actualizar_texto_coords_cursores_en_vivo(self):
        """
        Actualiza en el momento el TEXTO del bloque de coordenadas de
        cursores ya dibujado en la gráfica (sin recrearlo ni tocar la
        posición donde el usuario lo haya arrastrado), para que se vea en
        tiempo real mientras se arrastra un cursor. Si el bloque no está
        dibujado actualmente (checkbox apagado, o cursores desactivados),
        no hace nada: se dibujará solo (si corresponde) en el próximo
        redibujado completo.
        """
        artista = self._medicion_text_artists.get('cursores')
        if artista is None or artista not in self.ax.texts:
            return
        artista.set_text(self._texto_bloque_coords_cursores())

    def _dibujar_coords_cursores_en_grafica(self):
        """
        Muestra, como bloque de texto arrastrable sobre la propia gráfica
        V(t) (mismo mecanismo que los bloques de mediciones por canal), las
        coordenadas absolutas de los 4 cursores y sus deltas (ΔX, ΔY) — la
        misma información que ya se ve en la barra superior, pero encima del
        gráfico, para que quede visible también al exportar a PDF.

        Solo se dibuja si "Use cursors" y el checkbox "Cursor coordinates"
        (panel "Show on Graph") están tildados. Se puede arrastrar con el
        mouse a cualquier posición, igual que un bloque de mediciones. El
        texto se mantiene al día en tiempo real mientras se arrastra un
        cursor (ver _actualizar_texto_coords_cursores_en_vivo, llamado desde
        on_motion).
        """
        if not self.var_cursores.get():
            return
        if not getattr(self, 'var_mostrar_coords_cursores', None) or not self.var_mostrar_coords_cursores.get():
            return
        if not all([self.cursor_x1, self.cursor_x2, self.cursor_y1, self.cursor_y2]):
            return

        texto_bloque = self._texto_bloque_coords_cursores()

        if 'cursores' in self._medicion_pos:
            x_pos, y_pos = self._medicion_pos['cursores']
        else:
            x_pos, y_pos = 0.70, 0.985  # esquina superior derecha, por defecto

        artista = self.ax.text(
            x_pos, y_pos, texto_bloque,
            transform=self.ax.transAxes,
            fontsize=7.5, color=self.current_colors["fg"], va='top', ha='left',
            family='monospace', zorder=6, picker=True,
            bbox=dict(boxstyle='round,pad=0.3', facecolor=self.current_colors["plot_bg"],
                      edgecolor=self.current_colors["fg"], linewidth=0.8, alpha=0.85)
        )
        self._medicion_text_artists['cursores'] = artista

    def crear_cursores_absoluto(self, posiciones):
        """
        Vuelve a colocar los cursores en posiciones absolutas de datos, sin cambiar su valor.

        Los cursores X1/X2/Y1/Y2 en sí quedan exactamente donde estaban (en
        coordenadas de pantalla/divisiones): un offset es solo un
        desplazamiento de visualización y no debe mover los cursores.

        El tracking (Y1/Y2 "pegado" a una curva) es la excepción: si está
        activo, SIEMPRE se recalcula acá, sobre los datos ya actualizados de
        `self._canal_visible_data`. Si no se hiciera así, un cursor en modo
        Track quedaría con su punto marcador "congelado" (fuera de la curva)
        cada vez que se mueve un offset, hasta que el usuario lo arrastrara a
        mano — que es precisamente lo que NO debe pasar: un cursor en modo
        Track tiene que seguir la señal en todo momento, offset incluido.
        """
        # Eliminar cursores existentes
        for attr in ['cursor_x1','cursor_x2','cursor_y1','cursor_y2']:
            cur = getattr(self, attr)
            if cur and cur in self.ax.lines:
                self.ax.lines.remove(cur)
            setattr(self, attr, None)
        # Dibujar en coordenadas de datos sin escalar
        self.cursor_x1 = self.ax.axvline(posiciones['x1'], color=self.current_colors['cursor_x'], linestyle='--', picker=5)
        self.cursor_x2 = self.ax.axvline(posiciones['x2'], color=self.current_colors['cursor_x'], linestyle='--', picker=5)
        self.cursor_y1 = self.ax.axhline(posiciones['y1'], color=self.current_colors['cursor_y'], linestyle='--', picker=5)
        self.cursor_y2 = self.ax.axhline(posiciones['y2'], color=self.current_colors['cursor_y'], linestyle='--', picker=5)

        self._actualizar_tracking_cursores()
        self._actualizar_etiquetas_cursores()


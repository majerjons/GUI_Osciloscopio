"""
Dibujado principal de la grafica V(t): grilla tipo osciloscopio,
redibujado de curvas/cursores, resize y modo Bode.

Estos metodos se mezclan (mixin) dentro de TC1ScopeApp en gui_app.py.
"""
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, colorchooser
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import re
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.collections import LineCollection
from .constants import *  # noqa: F401,F403 (colores y dimensiones de pantalla)


class PlotMixin:
    def _segmentos_grilla(self):
        """
        Calcula (una sola vez, y los cachea) los segmentos geométricos de la
        cuadrícula principal y de subdivisión. Como el sistema de coordenadas
        de pantalla es siempre fijo (-N/2 a +N/2 divisiones), esta geometría
        nunca cambia entre redibujados: solo cambian los colores/etiquetas.
        """
        if getattr(self, '_grid_segments_cache', None) is not None:
            return self._grid_segments_cache

        x_half = SCREEN_DIVISIONS_X / 2.0
        y_half = SCREEN_DIVISIONS_Y / 2.0

        x_major = np.arange(-x_half, x_half + 1e-9, 1.0)
        y_major = np.arange(-y_half, y_half + 1e-9, 1.0)
        x_minor = np.arange(-x_half, x_half + 1e-9, 0.2)
        y_minor = np.arange(-y_half, y_half + 1e-9, 0.2)

        seg_major = [[(x, -y_half), (x, y_half)] for x in x_major] + \
                    [[(-x_half, y), (x_half, y)] for y in y_major]
        seg_minor = [[(x, -y_half), (x, y_half)] for x in x_minor] + \
                    [[(-x_half, y), (x_half, y)] for y in y_minor]

        self._grid_segments_cache = (seg_major, seg_minor)
        return self._grid_segments_cache

    def dibujar_divisiones(self):
        """
        Dibuja la cuadrícula del osciloscopio en un sistema de coordenadas FIJO
        (en divisiones de pantalla, -N/2 a +N/2), y agrega las etiquetas de
        escala de tiempo (eje X) y tensión (eje Y).

        La cuadrícula NUNCA se mueve: lo único que cambia con los offsets es
        la posición de las señales dentro de ella (igual que en un osciloscopio real).

        Nota de rendimiento: en vez de dibujar cada línea de la grilla como un
        objeto Line2D individual (~100 objetos por frame), se agrupan en dos
        LineCollection (principal y subdivisión), mucho más livianas de crear
        y redibujar en cada actualización.
        """
        self.ax.grid(False)  # Desactiva la cuadrícula automática de Matplotlib

        x_half = SCREEN_DIVISIONS_X / 2.0
        y_half = SCREEN_DIVISIONS_Y / 2.0

        # La cuadrícula (y los límites del gráfico) son siempre fijos
        self.ax.set_xlim(-x_half, x_half)
        self.ax.set_ylim(-y_half, y_half)

        seg_major, seg_minor = self._segmentos_grilla()
        grid_color = self.current_colors["grid"]

        self.ax.add_collection(LineCollection(seg_minor, colors=grid_color, linestyles=':', linewidths=0.4, zorder=0))
        self.ax.add_collection(LineCollection(seg_major, colors=grid_color, linestyles='-', linewidths=0.8, zorder=0))

        # Ejes centrales (referencia de disparo t=0 y GND)
        self.ax.axvline(x=0, color=self.current_colors["fg"], linewidth=1.2, zorder=1)
        self.ax.axhline(y=0, color=self.current_colors["fg"], linewidth=1.2, zorder=1)

        if self.df is None or self.is_bode:
            self.ax.set_xticks([])
            self.ax.set_yticks([])
            return

        # --- FIX: escala de TIEMPO visible en el eje X ---
        tiempo_div_segs = self.obtener_factor_tiempo_div()
        unidad_t, factor_t = self.obtener_unidad_tiempo_actual()
        self.unidad_tiempo = unidad_t

        xticks = np.arange(-x_half, x_half + 1e-9, 1.0)
        xlabels = []
        for xv in xticks:
            # El valor de tiempo real en cada línea de la cuadrícula depende del offset:
            # la cuadrícula no se mueve, pero el "cero" de tiempo sí, según el offset.
            t_real = (xv - self.offset_divisiones) * tiempo_div_segs
            xlabels.append(f"{t_real * factor_t:.3g}")
        self.ax.set_xticks(xticks)
        self.ax.set_xticklabels(xlabels, color=self.current_colors["fg"], fontsize=8)

        # --- FIX: escala de TENSIÓN visible en el eje Y (según canal de referencia) ---
        canal_ref = self.obtener_canal_referencia()
        unidad_v, factor_v = self.obtener_unidad_valor(canal_ref)
        volt_div_ref = self.obtener_factor_volt_div(canal_ref)
        self.unidad_valor = unidad_v

        yticks = np.arange(-y_half, y_half + 1e-9, 1.0)
        ylabels = [f"{(yv * volt_div_ref) * factor_v:.3g}" for yv in yticks]
        self.ax.set_yticks(yticks)
        self.ax.set_yticklabels(ylabels, color=self.current_colors["fg"], fontsize=8)

    def actualizar_grafica(self, event=None):
        self.update_voltage_offset_range()
        """
        Limpia y redibuja el gráfico, aplicando offsets, escalas,
        y actualizando cursores y cuadrícula.

        Si los cursores X1/X2/Y1/Y2 ya existían, se recrean en la MISMA
        posición de pantalla que tenían (un offset es un ajuste puramente de
        visualización y no debe reubicarlos). Los cursores en modo Track son
        la excepción: siempre se vuelven a enganchar a su curva, offset
        incluido (ver crear_cursores_absoluto).
        """
        # Si es CSV de Bode, plot_bode()
        if self.is_bode:
            self.plot_bode()
            return
        # Guardado de las posiciones de los cursores (para no perderlas al redibujar)
        abs_pos = self.obtener_posiciones_absolutas()

        # --- FIX de rendimiento: antes se hacía fig.clear()+add_subplot DOS veces
        # (y encima un ax.clear() extra) en cada redibujado. Con una sola vez alcanza.
        self.fig.clear()
        self.ax = self.fig.add_subplot(1, 1, 1)
        self.lineas.clear() # Limpia las referencias a las líneas antiguas

        # Establece el color de fondo del eje y la figura
        self.fig.set_facecolor(self.current_colors["plot_bg"])
        self.ax.set_facecolor(self.current_colors["plot_bg"])
        
        # Configura colores de los bordes del grafico y ticks
        for spine in self.ax.spines.values():
            spine.set_edgecolor(self.current_colors["fg"])
        self.ax.tick_params(axis='x', colors=self.current_colors["fg"])
        self.ax.tick_params(axis='y', colors=self.current_colors["fg"])
        self.ax.xaxis.label.set_color(self.current_colors["fg"])
        self.ax.yaxis.label.set_color(self.current_colors["fg"])
        self.ax.title.set_color(self.current_colors["fg"])
        
        if self.df is None:
            self._canal_visible_data = {}
            self.ax.set_title("Load a CSV file", color=self.current_colors["fg"])
            self.ax.set_xlabel("Time", color=self.current_colors["fg"])
            self.ax.set_ylabel("Voltage", color=self.current_colors["fg"])
            self.canvas.draw_idle()
            return

        tiempo_col = self.df.columns[0]
        tiempo_original = self.df[tiempo_col].values

        tiempo_div_segs = self.obtener_factor_tiempo_div()

        # --- FIX: sistema de coordenadas de pantalla FIJO (en divisiones) ---
        # La cuadrícula siempre ocupa de -x_half a +x_half divisiones; lo único
        # que cambia con el offset de tiempo es DÓNDE cae cada muestra dentro
        # de esa cuadrícula fija (igual que en un osciloscopio real).
        x_half = SCREEN_DIVISIONS_X / 2.0
        y_half = SCREEN_DIVISIONS_Y / 2.0

        # Rango de tiempo (en segundos, coordenadas originales del CSV) que
        # cae dentro de la ventana visible, dado el offset actual.
        t_start_visible = (-x_half - self.offset_divisiones) * tiempo_div_segs
        t_end_visible = (x_half - self.offset_divisiones) * tiempo_div_segs

        # Filtra los datos para la ventana de tiempo actual
        idx_visible = np.where((tiempo_original >= t_start_visible) & (tiempo_original <= t_end_visible))[0]

        num_canales = len(self.df.columns) - 1

        # Actualiza el panel de mediciones automáticas (usa toda la señal
        # cargada, no solo la ventana visible en pantalla)
        self.actualizar_mediciones()

        if len(idx_visible) < 2 and num_canales > 0:
            self._canal_visible_data = {}
            self.ax.set_title("No hay suficientes datos en el rango visible.", color=self.current_colors["fg"])
            self.dibujar_divisiones()
            self.ax.set_xlabel(f"Time ({self.unidad_tiempo})", color=self.current_colors["fg"])
            self.ax.set_ylabel(f"Voltage ({self.unidad_valor})", color=self.current_colors["fg"])
            self.canvas.draw_idle()
            return

        # Convierte el tiempo real a coordenadas de pantalla (divisiones),
        # aplicando el offset de tiempo directamente a la señal (no a la cuadrícula)
        tiempo_screen = tiempo_original[idx_visible] / tiempo_div_segs + self.offset_divisiones

        # Límites del gráfico: SIEMPRE fijos (la cuadrícula nunca se mueve)
        self.ax.set_xlim(-x_half, x_half)
        self.ax.set_ylim(-y_half, y_half)

        # Dibujar las líneas de datos (sin duplicación y con visibilidad controlada)
        # Guarda los datos visibles de cada canal para poder usarlos en el
        # tracking de cursores (interpolar el valor de la señal en un x dado).
        self._canal_visible_data = {}

        for i in range(num_canales):
            # Chequea si el canal está habilitado por los checkboxes
            if (i == 0 and not self.mostrar_ch1.get()) or (i == 1 and not self.mostrar_ch2.get()):
                continue  # Salta canal oculto

            datos_originales = self.df[self.df.columns[i + 1]].values[idx_visible]

            volt_div_str = self.volt_div_vars[i].get() if i < len(self.volt_div_vars) else "1 V/div"
            factor_volt_div = self.obtener_factor_volt_div(i)

            # --- FIX: cada canal se expresa en SUS PROPIAS divisiones ---
            # (valor / volts_por_div), y el offset de tensión de ESE canal
            # se le suma en esas mismas divisiones. La cuadrícula (fija) y el
            # otro canal no se ven afectados por este offset.
            datos_div = datos_originales / factor_volt_div
            if i == 0:
                datos_div = datos_div + (self.offset_tension_ch1 / factor_volt_div)
            elif i == 1:
                datos_div = datos_div + (self.offset_tension_ch2 / factor_volt_div)

            etiqueta = self.channel_label_vars[i].get() if i < len(self.channel_label_vars) else self.df.columns[i + 1]
            if not etiqueta.strip():
                etiqueta = str(self.df.columns[i + 1])

            linea, = self.ax.plot(
                tiempo_screen, datos_div,
                color=self._color_actual_canal(i),
                label=f"{etiqueta} ({volt_div_str})"
            )
            self.lineas.append(linea)
            self._canal_visible_data[i] = (tiempo_screen, datos_div, datos_originales)


        # Redibuja las divisiones de la cuadrícula (y actualiza self.unidad_tiempo/self.unidad_valor)
        self.dibujar_divisiones()

        self.ax.set_xlabel(f"Time ({self.unidad_tiempo})", color=self.current_colors["fg"])
        self.ax.set_ylabel(f"Voltage ({self.unidad_valor})", color=self.current_colors["fg"])
        if self.lineas:
            self.ax.legend(loc='upper right', facecolor=self.current_colors["plot_bg"], edgecolor=self.current_colors["fg"], labelcolor=self.current_colors["fg"])

        # Dibuja como texto, sobre la propia gráfica, las mediciones que el
        # usuario haya elegido mostrar (checkboxes junto a cada medición) —
        # así quedan visibles también al exportar a PDF.
        self._dibujar_medidas_en_grafica()

        # Actualiza cursores si están activados
        if self.var_cursores.get() and abs_pos:
            self.crear_cursores_absoluto(abs_pos)
        elif self.var_cursores.get():
            self.crear_cursores()  # posiciones por defecto
        else:
            # Remover cursores: el fig.clear() de más arriba ya destruyó los
            # objetos Line2D viejos (pertenecían al Axes anterior), así que
            # alcanza con soltar las referencias en Python. (Antes se
            # comprobaba "cur in self.ax.lines" para decidir si poner en
            # None, pero eso comparaba contra el Axes NUEVO -recién creado
            # más arriba en esta misma función- así que nunca daba True: los
            # cursores quedaban "vivos" en self.cursor_x1/x2/y1/y2 aunque ya
            # no se vieran, y por eso las etiquetas X1/X2/Y1/Y2 seguían
            # dibujándose después de desactivar "Use cursors".)
            for attr in ['cursor_x1', 'cursor_x2', 'cursor_y1', 'cursor_y2']:
                setattr(self, attr, None)
            self._actualizar_etiquetas_cursores()  # limpia las etiquetas X1/X2/Y1/Y2
            self._medicion_pos.pop('cursores', None)

        # Bloques de texto arrastrables opcionales sobre la gráfica V(t):
        # coordenadas de los cursores y offset de tensión (checkboxes en el
        # panel "Show on Graph", al costado de "Channels & Measurements").
        self._dibujar_coords_cursores_en_grafica()
        self._dibujar_offset_tension_en_grafica()

        self.canvas.draw_idle()

    def on_resize(self, event):
        """Maneja el evento de redimensionamiento de la figura para actualizar la cuadrícula."""
        self.actualizar_grafica()

    def plot_bode(self):
        """Dibuja el diagrama de Bode (Gain dB y Phase ° vs Frequency) respetando el tema."""
        # Limpio la figura y creo dos ejes apilados
        self.fig.clear()
        ax1 = self.fig.add_subplot(211)
        ax2 = self.fig.add_subplot(212)

        # Columnas esperadas
        f = self.df["Frequency (Hz)"].values
        g = self.df["Gain (dB)"].values
        p = self.df["Phase ()"].values

        # Aplico colores del tema a ambos ejes
        for ax in (ax1, ax2):
            ax.set_facecolor(self.current_colors["plot_bg"])
            for spine in ax.spines.values():
                spine.set_edgecolor(self.current_colors["fg"])
            ax.tick_params(axis='x', colors=self.current_colors["fg"])
            ax.tick_params(axis='y', colors=self.current_colors["fg"])
            ax.xaxis.label.set_color(self.current_colors["fg"])
            ax.yaxis.label.set_color(self.current_colors["fg"])

        # Ganancia (dB)
        ax1.semilogx(f, g, linestyle='-', marker='o', markersize=4,
                     color=self.current_colors["line_colors"][0])
        ax1.set_title("BODE Diagram", color=self.current_colors["fg"])
        ax1.set_ylabel("Gain (dB)", color=self.current_colors["fg"])
        ax1.grid(True, which='both', linestyle='--', linewidth=0.5,
                 color=self.current_colors["grid"])

        # Fase (°)
        ax2.semilogx(f, p, linestyle='-', marker='o', markersize=4,
                     color=self.current_colors["line_colors"][1])
        ax2.set_xlabel("Frequency (Hz)", color=self.current_colors["fg"])
        ax2.set_ylabel("Phase (°)", color=self.current_colors["fg"])
        ax2.grid(True, which='both', linestyle='--', linewidth=0.5,
                 color=self.current_colors["grid"])

        # Fondo de figura
        self.fig.set_facecolor(self.current_colors["plot_bg"])
        self.canvas.draw_idle()


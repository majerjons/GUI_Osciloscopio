@echo off
REM ============================================================
REM  Genera el ejecutable LSG_GUI.exe (Windows) usando PyInstaller.
REM  Ejecutar este archivo (doble clic o desde una consola) parado
REM  en la carpeta del proyecto, la misma donde esta GUI.py.
REM ============================================================

echo Instalando/actualizando dependencias con Python 3.13...
py -3.13 -m pip install --upgrade pip
py -3.13 -m pip install -r requirements.txt
py -3.13 -m pip install pyinstaller

echo.
echo Compilando el ejecutable...
REM --collect-submodules matplotlib.backends asegura que se incluyan TODOS
REM los backends de matplotlib (por ejemplo backend_pdf), ya que matplotlib
REM los carga de forma dinamica y PyInstaller no los detecta solo con su
REM analisis estatico de imports.
py -3.13 -m PyInstaller --noconfirm --onefile --windowed ^
    --name "LSG_GUI" ^
    --collect-submodules matplotlib.backends ^
    --hidden-import matplotlib.backends.backend_pdf ^
    GUI.py

echo.
echo Listo. El ejecutable esta en dist\LSG_GUI.exe
pause
